"""Backend-neutral slot-mounted retrieval boundary."""

from .slot_runtime import (
    SlotRuntime,
    SlotRuntimeSpec,
    build_slot_runtime,
    load_slot_runtime_spec,
)

__all__ = [
    "SlotRuntime",
    "SlotRuntimeSpec",
    "build_slot_runtime",
    "load_slot_runtime_spec",
]
