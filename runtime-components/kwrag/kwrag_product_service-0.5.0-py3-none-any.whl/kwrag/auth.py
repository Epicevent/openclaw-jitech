"""Strict slot-token projection loading.

The projection is a derived artifact. It mirrors the authoritative grant/mount
state but never becomes an independently edited authorization database.
"""

from __future__ import annotations

import hashlib
import re
import stat
import threading
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Mapping

from .jsonutil import is_sha256, loads_canonical_json_bytes

_SAFE_ID = re.compile(r"^[A-Za-z0-9._-]+$")
_MIN_PROJECTION_LIFETIME_SECONDS = 300
_MAX_PROJECTION_LIFETIME_SECONDS = 3600
_MAX_CLOCK_SKEW_SECONDS = 30


class ProjectionError(ValueError):
    pass


@dataclass(frozen=True)
class SlotGrant:
    instance_id: str
    slot_id: str
    corpora: frozenset[str]


@dataclass(frozen=True)
class TokenProjection:
    index_manifest: str
    source_digest: str
    projection_digest: str
    generated_at: datetime
    expires_at: datetime
    grants: Mapping[str, SlotGrant]

    def authorize(self, token: str) -> SlotGrant | None:
        return self.grants.get(token)

    def is_stale(self, now: datetime | None = None) -> bool:
        current = now or datetime.now(timezone.utc)
        if current.tzinfo is None or current.utcoffset() is None:
            raise ProjectionError("projection freshness check requires a timezone-aware time")
        return current.astimezone(timezone.utc) >= self.expires_at


def _utc_timestamp(value: object, field: str) -> datetime:
    text = str(value or "").strip()
    try:
        parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ProjectionError(f"token projection {field} is invalid") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ProjectionError(f"token projection {field} must be timezone-aware")
    return parsed.astimezone(timezone.utc)


def load_projection(path: Path, expected_index_manifest: str) -> TokenProjection:
    try:
        raw_bytes = Path(path).read_bytes()
        raw = loads_canonical_json_bytes(raw_bytes)
    except (OSError, UnicodeDecodeError, ValueError) as exc:
        raise ProjectionError("token projection bytes are not canonical") from exc
    if not isinstance(raw, dict) or raw.get("version") != 1:
        raise ProjectionError("token projection version must be 1")
    unknown = set(raw) - {
        "version",
        "index_manifest",
        "source_digest",
        "generated_at",
        "expires_at",
        "tokens",
    }
    if unknown:
        raise ProjectionError("token projection has unknown fields")
    index_manifest = str(raw.get("index_manifest") or "")
    if index_manifest != expected_index_manifest:
        raise ProjectionError("token projection does not target the active index manifest")
    source_digest = str(raw.get("source_digest") or "")
    if not is_sha256(source_digest):
        raise ProjectionError("token projection source_digest is missing")
    generated_at = _utc_timestamp(raw.get("generated_at"), "generated_at")
    expires_at = _utc_timestamp(raw.get("expires_at"), "expires_at")
    lifetime = (expires_at - generated_at).total_seconds()
    if (
        lifetime < _MIN_PROJECTION_LIFETIME_SECONDS
        or lifetime > _MAX_PROJECTION_LIFETIME_SECONDS
    ):
        raise ProjectionError("token projection validity must be between 300 and 3600 seconds")
    now = datetime.now(timezone.utc)
    if generated_at > now + timedelta(seconds=_MAX_CLOCK_SKEW_SECONDS):
        raise ProjectionError("token projection generated_at is in the future")
    if now >= expires_at:
        raise ProjectionError("token projection is expired")
    token_entries = raw.get("tokens")
    if not isinstance(token_entries, dict):
        raise ProjectionError("token projection tokens must be an object")

    grants: dict[str, SlotGrant] = {}
    instance_grants: dict[str, tuple[str, frozenset[str]]] = {}
    slot_instances: dict[str, str] = {}
    for token, value in token_entries.items():
        if (
            not isinstance(token, str)
            or len(token) < 32
            or token.strip() != token
            or any(character.isspace() for character in token)
        ):
            raise ProjectionError("token projection contains an invalid token key")
        if not isinstance(value, dict):
            raise ProjectionError("token projection entry must be an object")
        if set(value) != {"instance_id", "slot_id", "corpora"}:
            raise ProjectionError("token projection entry fields are invalid")
        instance_id = str(value.get("instance_id") or "").strip().lower()
        try:
            if str(uuid.UUID(instance_id)) != instance_id:
                raise ValueError
        except ValueError as exc:
            raise ProjectionError("token projection entry has invalid instance_id") from exc
        slot_id = str(value.get("slot_id") or "").strip()
        corpora = value.get("corpora")
        if (
            not _SAFE_ID.fullmatch(slot_id)
            or not isinstance(corpora, list)
            or not corpora
        ):
            raise ProjectionError("token projection entry needs slot_id and corpora")
        if any(not isinstance(item, str) for item in corpora):
            raise ProjectionError("token projection entry has no valid corpora")
        corpus_input = [item.strip() for item in corpora]
        normalized = frozenset(corpus_input)
        if (
            not normalized
            or corpus_input != sorted(normalized)
            or any(not _SAFE_ID.fullmatch(item) for item in normalized)
        ):
            raise ProjectionError("token projection entry has no valid corpora")
        identity = (slot_id, normalized)
        previous = instance_grants.get(instance_id)
        if previous is not None:
            raise ProjectionError("token projection contains a duplicate instance")
        previous_instance = slot_instances.get(slot_id)
        if previous_instance is not None and previous_instance != instance_id:
            raise ProjectionError("token projection contains a duplicate slot")
        if token in grants:
            raise ProjectionError("token projection contains a duplicate token")
        grants[token] = SlotGrant(
            instance_id=instance_id,
            slot_id=slot_id,
            corpora=normalized,
        )
        instance_grants[instance_id] = identity
        slot_instances[slot_id] = instance_id

    return TokenProjection(
        index_manifest=index_manifest,
        source_digest=source_digest,
        projection_digest="sha256:" + hashlib.sha256(raw_bytes).hexdigest(),
        generated_at=generated_at,
        expires_at=expires_at,
        grants=grants,
    )


class ProjectionStore:
    """Reload an atomically replaced projection without retaining revoked grants.

    A changed file is authoritative immediately.  If the replacement cannot be
    validated, ``current`` fails closed instead of falling back to the previously
    cached projection.  The identity check around the load also rejects a refresh
    racing with a request.
    """

    def __init__(self, path: Path, expected_index_manifest: str):
        self.path = Path(path)
        self.expected_index_manifest = expected_index_manifest
        self._lock = threading.Lock()
        self._identity: tuple[int, int, int, int] | None = None
        self._projection: TokenProjection | None = None

    def _file_identity(self) -> tuple[int, int, int, int]:
        try:
            info = self.path.lstat()
        except OSError as exc:
            raise ProjectionError("token projection file is unavailable") from exc
        if stat.S_ISLNK(info.st_mode) or not stat.S_ISREG(info.st_mode):
            raise ProjectionError("token projection path must be a regular file")
        return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns)

    def current(self) -> TokenProjection:
        with self._lock:
            identity = self._file_identity()
            if identity == self._identity and self._projection is not None:
                return self._projection

            try:
                projection = load_projection(self.path, self.expected_index_manifest)
            except ProjectionError:
                raise
            except (OSError, ValueError) as exc:
                raise ProjectionError("token projection file is invalid") from exc
            if self._file_identity() != identity:
                raise ProjectionError("token projection changed while it was being loaded")
            if self._projection is not None:
                if projection.generated_at < self._projection.generated_at:
                    raise ProjectionError("token projection generation is not monotonic")
                if (
                    projection.generated_at == self._projection.generated_at
                    and projection.projection_digest
                    != self._projection.projection_digest
                ):
                    raise ProjectionError(
                        "token projection generation conflicts with the active bytes"
                    )

            self._identity = identity
            self._projection = projection
            return projection
