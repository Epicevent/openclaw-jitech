"""Validated retrieval configuration and stable fingerprints."""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from .jsonutil import load_strict_json

_KURE_REVISION = "d14c8a9423946e268a0c9952fecf3a7aabd73bd9"
_RERANKER_REVISION = "953dc6f6f85a1b2dbfca4c34a2796e7dde08d41e"


class ConfigError(ValueError):
    pass


@dataclass
class EmbeddingConfig:
    model: str = "nlpai-lab/KURE-v1"
    revision: str = _KURE_REVISION
    device: str = "cuda"
    dtype: str = "float32"
    query_max_chars: int = 2_000
    indexed_max_chars: int = 2_000
    normalize: bool = True
    local_files_only: bool = True


@dataclass
class RetrievalConfig:
    mode: str = "dense"
    pool: int = 30
    pool_by_room: dict[str, int] = field(default_factory=dict)

    def pool_for(self, room: str) -> int:
        return int(self.pool_by_room.get(room, self.pool))


@dataclass
class RerankConfig:
    enabled: bool = True
    model: str = "BAAI/bge-reranker-v2-m3"
    revision: str = _RERANKER_REVISION
    device: str = "cuda"
    dtype: str = "float32"
    max_length: int = 512
    passage_max_chars: int = 4_000
    batch_size: int = 64
    local_files_only: bool = True


@dataclass
class ReturnConfig:
    unit: str = "segment"
    k: int = 5
    max_k: int = 10
    turns: int = 20
    include_text: bool = True


def _digest(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(payload.encode("utf-8")).hexdigest()


@dataclass
class KwRagConfig:
    index_dir: Path = Path("/index")
    cache_dir: Path = Path("/cache")
    rooms: dict[str, str] = field(default_factory=dict)
    embedding: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    retrieval: RetrievalConfig = field(default_factory=RetrievalConfig)
    rerank: RerankConfig = field(default_factory=RerankConfig)
    ret: ReturnConfig = field(default_factory=ReturnConfig)
    port: int = 8899
    bind: str = "127.0.0.1"
    max_concurrent: int = 1

    def embedding_spec(self) -> dict[str, Any]:
        return asdict(self.embedding)

    def embedding_fingerprint(self) -> str:
        return _digest(self.embedding_spec())

    def pipeline_spec(self) -> dict[str, Any]:
        return {
            "embedding": self.embedding_spec(),
            "retrieval": asdict(self.retrieval),
            "rerank": asdict(self.rerank),
            "return": asdict(self.ret),
        }

    def pipeline_fingerprint(self) -> str:
        return _digest(self.pipeline_spec())

    def mode_label(self) -> str:
        base = "rerank" if self.rerank.enabled else "dense"
        return base if self.ret.unit == "segment" else f"{base}+{self.ret.unit}"

    @classmethod
    def load(cls) -> "KwRagConfig":
        cfg = cls()
        path = os.environ.get("KWRAG_CONFIG")
        if path:
            config_path = Path(path)
            if not config_path.is_file():
                raise ConfigError("KWRAG_CONFIG does not reference a file")
            raw = load_strict_json(config_path)
            if not isinstance(raw, dict):
                raise ConfigError("configuration root must be an object")
            cfg.merge(raw)
        cfg.apply_environment()
        cfg.validate()
        return cfg

    def merge(self, raw: dict[str, Any]) -> None:
        allowed = {
            "index_dir",
            "cache_dir",
            "embedding",
            "retrieval",
            "rerank",
            "return",
            "port",
            "bind",
            "max_concurrent",
        }
        unknown = set(raw) - allowed
        if unknown:
            raise ConfigError(f"unknown configuration fields: {', '.join(sorted(unknown))}")
        if "index_dir" in raw:
            self.index_dir = Path(str(raw["index_dir"]))
        if "cache_dir" in raw:
            self.cache_dir = Path(str(raw["cache_dir"]))
        self._merge_dataclass(self.embedding, raw.get("embedding"), "embedding")
        self._merge_dataclass(self.retrieval, raw.get("retrieval"), "retrieval")
        self._merge_dataclass(self.rerank, raw.get("rerank"), "rerank")
        self._merge_dataclass(self.ret, raw.get("return"), "return")
        for key in ("port", "bind", "max_concurrent"):
            if key in raw:
                setattr(self, key, raw[key])

    @staticmethod
    def _merge_dataclass(target: Any, raw: Any, section: str) -> None:
        if raw is None:
            return
        if not isinstance(raw, dict):
            raise ConfigError(f"{section} configuration must be an object")
        unknown = set(raw) - set(target.__dataclass_fields__)
        if unknown:
            raise ConfigError(f"unknown {section} fields: {', '.join(sorted(unknown))}")
        for key, value in raw.items():
            setattr(target, key, value)

    def apply_environment(self) -> None:
        env = os.environ.get
        if env("KWRAG_INDEX"):
            self.index_dir = Path(env("KWRAG_INDEX") or "")
        if env("KWRAG_CACHE"):
            self.cache_dir = Path(env("KWRAG_CACHE") or "")
        if env("KWRAG_BIND"):
            self.bind = env("KWRAG_BIND") or self.bind
        if env("KWRAG_PORT"):
            self.port = int(env("KWRAG_PORT") or "0")
        if env("KWRAG_MAX_CONCURRENT"):
            self.max_concurrent = int(env("KWRAG_MAX_CONCURRENT") or "0")
        if env("KWRAG_DTYPE"):
            self.embedding.dtype = env("KWRAG_DTYPE") or self.embedding.dtype
            self.rerank.dtype = self.embedding.dtype

    def validate(self) -> None:
        if self.embedding.dtype not in {"float32", "float16", "bfloat16"}:
            raise ConfigError("embedding dtype is not supported")
        if self.rerank.dtype not in {"float32", "float16", "bfloat16"}:
            raise ConfigError("rerank dtype is not supported")
        for name, revision in (
            ("embedding", self.embedding.revision),
            ("rerank", self.rerank.revision),
        ):
            if len(revision) != 40 or any(c not in "0123456789abcdef" for c in revision.lower()):
                raise ConfigError(f"{name} model revision must be an immutable 40-character commit")
        if self.retrieval.mode != "dense":
            raise ConfigError("only dense retrieval is implemented")
        if self.ret.unit not in {"segment", "turn", "two_stage"}:
            raise ConfigError("return unit is not supported")
        if not 1 <= int(self.ret.k) <= int(self.ret.max_k) <= 10:
            raise ConfigError("return k bounds are invalid")
        if not 1 <= int(self.retrieval.pool) <= 10_000:
            raise ConfigError("retrieval pool is invalid")
        if any(not 1 <= int(value) <= 10_000 for value in self.retrieval.pool_by_room.values()):
            raise ConfigError("per-room retrieval pool is invalid")
        if not 1 <= int(self.port) <= 65_535 or not 1 <= int(self.max_concurrent) <= 64:
            raise ConfigError("service port or concurrency is invalid")
        if int(self.embedding.query_max_chars) <= 0 or int(self.rerank.passage_max_chars) <= 0:
            raise ConfigError("text limits must be positive")
