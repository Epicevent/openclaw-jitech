"""Superseded shared-service implementation retained as technical evidence."""

from __future__ import annotations

import json
import os
from pathlib import Path

from .auth import ProjectionStore
from .config import ConfigError, KwRagConfig
from .http_api import ReceiptWriter, SearchApplication, serve
from .manifest import load_and_verify_manifest
from .pipeline import Pipeline


def _required_path(environment_name: str) -> Path:
    raw = os.environ.get(environment_name)
    if not raw:
        raise ConfigError(f"{environment_name} is required")
    path = Path(raw)
    if not path.is_file():
        raise ConfigError(f"{environment_name} does not reference a file")
    return path


def build_application(config: KwRagConfig) -> SearchApplication:
    manifest = load_and_verify_manifest(
        _required_path("KWRAG_INDEX_MANIFEST"), config.index_dir
    )
    if manifest.embedding_fingerprint != config.embedding_fingerprint():
        raise ConfigError("active index was built with a different embedding configuration")
    config.rooms = dict(manifest.rooms)
    projection_store = ProjectionStore(
        _required_path("KWRAG_TOKEN_PROJECTION"), manifest.digest
    )
    projection = projection_store.current()
    pipeline = Pipeline(config, cache_namespace=manifest.digest)
    pipeline.warm()
    receipts_path = Path(
        os.environ.get("KWRAG_RECEIPTS") or (config.cache_dir / "retrieval-receipts.jsonl")
    )
    return SearchApplication(
        pipeline=pipeline,
        projection=projection,
        projection_loader=projection_store.current,
        index_manifest=manifest,
        pipeline_fingerprint=config.pipeline_fingerprint(),
        receipt_writer=ReceiptWriter(receipts_path),
        max_concurrent=config.max_concurrent,
    )


def main() -> None:
    raise SystemExit(
        "the shared token-projection service is superseded and has no product entrypoint"
    )


def legacy_diagnostic_main() -> None:
    """Build the historical service only for explicitly isolated diagnostics."""

    config = KwRagConfig.load()
    application = build_application(config)
    print(
        "[kwrag] ready "
        + json.dumps(
            {
                "bind": config.bind,
                "port": config.port,
                "mode": config.mode_label(),
                "index_manifest": application.index_manifest.digest,
                "pipeline_fingerprint": application.pipeline_fingerprint,
            },
            sort_keys=True,
        ),
        flush=True,
    )
    serve(application, config.bind, config.port)


if __name__ == "__main__":
    main()
