"""Product-native dense-index operations for one supported product runtime.

The public seam deliberately accepts only source selection and rebuild intent.
The runtime-visible read-only mount defines the source, while the slot
Workspace defines the only writable tree.  Internal release metadata detects
torn index files; it is not a caller-supplied admission contract.
"""

from __future__ import annotations

import hashlib
import os
import re
import stat
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

from .dense_release import (
    DenseReleaseError,
    _load_pointer,
    _stable_payload,
    activate_dense_release,
    build_dense_release,
)
from .dense_source import SourceMessage
from .jsonutil import canonical_json_bytes, loads_canonical_json_bytes
from .live_kakao import LiveKakaoPackageSource, LiveKakaoSourceError
from .manifest import load_and_verify_manifest
from .operation import ReceiptWriter
from .product_contract import (
    PRODUCT_SOURCE_ADAPTERS,
    ProductContractError,
    ProductScope,
    normalize_product_scope,
    product_source_adapter,
)
from .shared_gpu_transport import (
    ContentFreeGpuJournal,
    GpuInferenceClient,
    SharedGpuTransportError,
    UnixSharedGpuClient,
)


INDEX_BUILD_SCHEMA = "kwrag-product-index-build-observation-v1"
_GPU_SOCKET_NAME = re.compile(r"([a-z0-9_-]+)\.sock\Z")
_GPU_SOCKET_ROOT = Path("/run/kwrag-gpu")
_MAX_GPU_SOCKET_DIRECTORY_ENTRIES = 128
_RUNTIME_PROFILES = {
    "hermes": (Path("/workspace/nas_docs"), Path("/workspace/.kwrag")),
    "openclaw": (
        Path("/home/node/nas_docs"),
        Path("/home/node/.openclaw/kwrag"),
    ),
}
INDEX_STATUS_SCHEMA = "kwrag-product-index-status-v1"
MAX_SOURCE_ATTEMPTS = 3
_SOURCE_NAME = re.compile(r"[a-z][a-z0-9_-]{0,63}\Z")
_RETRYABLE_SOURCE_ERRORS = frozenset(
    {
        "database_query_failed",
        "membership_changed_while_reading",
        "source_package_file_unavailable",
        "source_package_root_unavailable",
        "source_readonly_state_unavailable",
    }
)


class ProductIndexError(ValueError):
    """The product-native index operation violated a local safety boundary."""


@dataclass(frozen=True)
class _ProductIndexLayout:
    mount_root: Path
    workspace_root: Path
    socket_path: Path
    slot_namespace: str
    deadline_ms: int = 60_000
    allow_nonproduction: bool = False


@dataclass(frozen=True)
class _FrozenKakaoSource:
    messages: tuple[SourceMessage, ...]
    source_state_sha256: str
    source_kind: str = "kakao_live_package_v1"
    stale_references_are_skipped: bool = True

    def message_snapshot(self) -> list[SourceMessage]:
        return list(self.messages)

    def close(self) -> None:
        return None


def _discover_gpu_socket() -> tuple[Path, str]:
    """Observe exactly one bounded socket from the fixed broker directory."""

    root = _GPU_SOCKET_ROOT
    try:
        metadata = root.lstat()
        if (
            stat.S_ISLNK(metadata.st_mode)
            or not stat.S_ISDIR(metadata.st_mode)
            or root.resolve(strict=True) != root.absolute()
        ):
            raise ProductIndexError("gpu_socket_discovery_unavailable")
        candidates: list[tuple[Path, str]] = []
        with os.scandir(root) as entries:
            for position, entry in enumerate(entries, start=1):
                if position > _MAX_GPU_SOCKET_DIRECTORY_ENTRIES:
                    raise ProductIndexError("gpu_socket_directory_unbounded")
                match = _GPU_SOCKET_NAME.fullmatch(entry.name)
                if match is None or entry.is_symlink():
                    continue
                if stat.S_ISSOCK(entry.stat(follow_symlinks=False).st_mode):
                    candidates.append((root / entry.name, match.group(1)))
    except ProductIndexError:
        raise
    except OSError as exc:
        raise ProductIndexError("gpu_socket_discovery_unavailable") from exc
    if len(candidates) != 1:
        raise ProductIndexError("gpu_socket_discovery_ambiguous")
    return candidates[0]


def _runtime_layout() -> _ProductIndexLayout:
    """Return the profile-bound mount, Workspace, and GPU socket layout.

    These paths are runtime facts, not values supplied by a retrieval caller.
    Tests replace this private seam with disposable directories.
    """

    profile = os.environ.get("JITECH_KWRAG_RUNTIME_PROFILE", "hermes")
    try:
        mount_root, workspace_root = _RUNTIME_PROFILES[profile]
    except (KeyError, TypeError) as exc:
        raise ProductIndexError("runtime_profile_unsupported") from exc

    socket_override = os.environ.get("JITECH_KWRAG_SHARED_GPU_SOCKET")
    namespace_override = os.environ.get("JITECH_KWRAG_SLOT_NAMESPACE")
    if socket_override is not None:
        if namespace_override is None:
            raise ProductIndexError("slot_namespace_required")
        socket_path = Path(socket_override)
        slot_namespace = namespace_override
    elif namespace_override is not None:
        socket_path = _GPU_SOCKET_ROOT / f"{namespace_override}.sock"
        slot_namespace = namespace_override
    else:
        socket_path, slot_namespace = _discover_gpu_socket()

    if _SOURCE_NAME.fullmatch(slot_namespace) is None:
        raise ProductIndexError("slot_namespace_invalid")
    if not socket_path.is_absolute() or ".." in socket_path.parts:
        raise ProductIndexError("gpu_socket_path_invalid")
    return _ProductIndexLayout(
        mount_root=mount_root,
        workspace_root=workspace_root,
        socket_path=socket_path,
        slot_namespace=slot_namespace,
    )


def _real_directory(path: Path, code: str) -> Path:
    supplied = Path(path)
    if not supplied.is_absolute():
        raise ProductIndexError(code)
    try:
        info = supplied.lstat()
        resolved = supplied.resolve(strict=True)
    except OSError as exc:
        raise ProductIndexError(code) from exc
    if (
        stat.S_ISLNK(info.st_mode)
        or not stat.S_ISDIR(info.st_mode)
        or resolved != supplied.absolute()
    ):
        raise ProductIndexError(code)
    return resolved


def _validate_layout(layout: _ProductIndexLayout) -> tuple[Path, Path]:
    mount = _real_directory(layout.mount_root, "runtime_mount_unavailable")
    workspace = _real_directory(layout.workspace_root, "slot_workspace_unavailable")
    if mount == workspace or mount in workspace.parents or workspace in mount.parents:
        raise ProductIndexError("source_workspace_overlap")
    if _SOURCE_NAME.fullmatch(layout.slot_namespace) is None:
        raise ProductIndexError("slot_namespace_invalid")
    if not layout.socket_path.is_absolute():
        raise ProductIndexError("gpu_socket_path_invalid")
    if (
        isinstance(layout.deadline_ms, bool)
        or not isinstance(layout.deadline_ms, int)
        or not 1 <= layout.deadline_ms <= 120_000
        or not isinstance(layout.allow_nonproduction, bool)
    ):
        raise ProductIndexError("product_index_layout_invalid")
    return mount, workspace


def _product_scope(value: Any = None) -> ProductScope:
    try:
        return normalize_product_scope(value)
    except ProductContractError as exc:
        raise ProductIndexError(str(exc)) from exc


def _source_state_digest(messages: Sequence[SourceMessage]) -> str:
    """Hash a snapshot for observability only; never use it as admission."""

    digest = hashlib.sha256(b"kwrag-live-source-observation-v1\0")
    for message in messages:
        for value in (
            message.room,
            message.message_id,
            message.user_id,
            message.user_name,
            str(message.sent_time),
            message.text,
        ):
            payload = value.encode("utf-8")
            digest.update(len(payload).to_bytes(8, "big"))
            digest.update(payload)
    return "sha256:" + digest.hexdigest()


def _snapshot_kw_source(
    package_root: Path,
    requested_rooms: Sequence[str] | None,
) -> tuple[_FrozenKakaoSource | None, int, str | None]:
    last_code: str | None = None
    for attempt in range(1, MAX_SOURCE_ATTEMPTS + 1):
        source: LiveKakaoPackageSource | None = None
        try:
            source = LiveKakaoPackageSource(package_root)
            messages = tuple(source.message_snapshot())
            if requested_rooms is not None:
                if set(requested_rooms) - set(source.rooms):
                    raise ProductIndexError("scope_room_outside_source")
                messages = tuple(
                    message
                    for message in messages
                    if message.room in requested_rooms
                )
                if not messages:
                    return None, attempt, "source_has_no_indexable_messages"
            return (
                _FrozenKakaoSource(
                    messages=messages,
                    source_state_sha256=_source_state_digest(messages),
                ),
                attempt,
                None,
            )
        except LiveKakaoSourceError as exc:
            last_code = str(exc)
            if last_code == "source_has_no_indexable_messages":
                return None, attempt, last_code
            if last_code not in _RETRYABLE_SOURCE_ERRORS:
                raise ProductIndexError(last_code) from exc
        except OSError:
            last_code = "source_io_failed"
        finally:
            if source is not None:
                source.close()
    return None, MAX_SOURCE_ATTEMPTS, last_code or "source_unavailable"


def _principal() -> str:
    getter = getattr(os, "geteuid", None)
    if not callable(getter):
        raise ProductIndexError("product_index_requires_posix_identity")
    return f"uid:{getter()}"


def _gpu_client(layout: _ProductIndexLayout, gpu_receipt_path: Path) -> GpuInferenceClient:
    return UnixSharedGpuClient(
        socket_path=layout.socket_path,
        slot=layout.slot_namespace,
        principal=_principal(),
        journal=ContentFreeGpuJournal(gpu_receipt_path),
        deadline_ms=layout.deadline_ms,
    )


def _scope_digest(scope: ProductScope) -> str:
    return "sha256:" + hashlib.sha256(
        canonical_json_bytes(scope.observation())
    ).hexdigest()


def _slot_root(workspace: Path, layout: _ProductIndexLayout) -> Path:
    return workspace / "dense" / layout.slot_namespace


def _pointer(slot_root: Path) -> dict[str, Any] | None:
    if not slot_root.exists() and not slot_root.is_symlink():
        return None
    if slot_root.is_symlink() or not slot_root.is_dir():
        raise ProductIndexError("active_index_root_invalid")
    try:
        value = _load_pointer(slot_root / "current.json")
    except DenseReleaseError as exc:
        raise ProductIndexError("active_index_pointer_invalid") from exc
    return dict(value) if value is not None else None


def _active_index_summary(slot_root: Path, pointer: dict[str, Any]) -> dict[str, Any]:
    release_id = str(pointer["current_release_id"])
    release_root = slot_root / "releases" / release_id
    try:
        resolved_release = _real_directory(release_root, "active_index_release_invalid")
        manifest = load_and_verify_manifest(
            resolved_release / "index-manifest.json", resolved_release
        )
        extension = manifest.raw.get("kwrag_dense")
        if manifest.release_id != release_id or not isinstance(extension, dict):
            raise ProductIndexError("active_index_release_invalid")
        snapshot_relative = extension.get("source_snapshot_relative")
        if snapshot_relative != "source-snapshot.json":
            raise ProductIndexError("active_index_release_invalid")
        snapshot = loads_canonical_json_bytes(
            _stable_payload(resolved_release / snapshot_relative, maximum=256 * 1024)
        )
        if not isinstance(snapshot, dict):
            raise ProductIndexError("active_index_release_invalid")
        segment_count = extension.get("segment_count")
        production_eligible = extension.get("production_eligible")
        if (
            isinstance(segment_count, bool)
            or not isinstance(segment_count, int)
            or segment_count < 1
            or not isinstance(production_eligible, bool)
        ):
            raise ProductIndexError("active_index_release_invalid")
    except ProductIndexError:
        raise
    except (OSError, ValueError, DenseReleaseError) as exc:
        raise ProductIndexError("active_index_release_invalid") from exc
    return {
        "active_index_id": release_id,
        "previous_index_id": pointer.get("previous_release_id"),
        "activation_sequence": pointer["sequence"],
        "indexed_source_count": 1,
        "indexed_room_count": len(manifest.rooms),
        "segment_count": segment_count,
        "source_state_sha256": snapshot.get("source_state_sha256"),
        "production_eligible": production_eligible,
        "_indexed_rooms": tuple(sorted(manifest.rooms)),
    }


def _index_state(slot_root: Path) -> tuple[str, dict[str, Any] | None]:
    pointer = _pointer(slot_root)
    if pointer is None:
        return "unbuilt", None
    return "ready", _active_index_summary(slot_root, pointer)


def _source_availability(
    package_root: Path,
    requested_rooms: Sequence[str] | None,
) -> tuple[str, str | None]:
    source: LiveKakaoPackageSource | None = None
    try:
        source = LiveKakaoPackageSource(package_root)
        source.assert_available()
        if requested_rooms is not None and set(requested_rooms) - set(source.rooms):
            return "unavailable", "scope_room_outside_source"
        return "available", None
    except (LiveKakaoSourceError, OSError) as exc:
        return "unavailable", str(exc) or "source_unavailable"
    finally:
        if source is not None:
            source.close()


def _observation(
    *,
    workspace: Path,
    started_ns: int,
    status: str,
    scope: ProductScope,
    rebuild: bool,
    indexed_source_count: int,
    skipped_source_count: int,
    source_attempts: int,
    source_state_sha256: str | None,
    active: dict[str, Any] | None,
    embedding_receipt_digest: str | None,
    error_codes: Sequence[str],
) -> dict[str, Any]:
    body = {
        "schema_version": INDEX_BUILD_SCHEMA,
        "status": status,
        "selected_source_count": len(scope.sources),
        "indexed_source_count": indexed_source_count,
        "skipped_source_count": skipped_source_count,
        "source_scope_sha256": _scope_digest(scope),
        "source_attempts": source_attempts,
        "source_state_sha256": source_state_sha256,
        "rebuild_requested": rebuild,
        "active_index_id": active.get("active_index_id") if active else None,
        "previous_index_id": active.get("previous_index_id") if active else None,
        "activation_sequence": active.get("activation_sequence") if active else None,
        "segment_count": active.get("segment_count") if active else None,
        "embedding_operation_receipt_digest": embedding_receipt_digest,
        "error_codes": list(error_codes),
        "duration_ms": max(0, (time.monotonic_ns() - started_ns) // 1_000_000),
        "raw_content_present": False,
    }
    receipt = ReceiptWriter(
        workspace / "receipts" / "index-build.jsonl"
    ).write(body)
    return {
        **body,
        "receipt_status": receipt.status,
        "receipt_digest": receipt.digest,
    }


def kwrag_index_build(
    scope: ProductScope | Any = None,
    rebuild: bool = False,
) -> dict[str, Any]:
    """Ensure or explicitly rebuild the oc20 Workspace dense index.

    ``scope`` is the shared product selector. Omitting it selects all mounted
    Kakao rooms; an explicit room list builds only those exact live rooms. The
    internal package directory remains ``kw/package`` and is resolved by the
    sole real adapter. Source paths, Workspace paths, GPU identity,
    generations, and manifests are intentionally not caller inputs.
    """

    started_ns = time.monotonic_ns()
    if not isinstance(rebuild, bool):
        raise ProductIndexError("rebuild_invalid")
    normalized_scope = _product_scope(scope)
    layout = _runtime_layout()
    mount, workspace = _validate_layout(layout)
    slot_root = _slot_root(workspace, layout)
    index_status, active = _index_state(slot_root)

    adapter = product_source_adapter(normalized_scope.sources[0])
    requested_rooms = normalized_scope.room_ids(adapter.source)
    active_covers_scope = requested_rooms is None or (
        active is not None
        and set(requested_rooms) <= set(active.get("_indexed_rooms", ()))
    )
    if index_status == "ready" and not rebuild and active_covers_scope:
        return _observation(
            workspace=workspace,
            started_ns=started_ns,
            status="already_built",
            scope=normalized_scope,
            rebuild=False,
            indexed_source_count=1,
            skipped_source_count=0,
            source_attempts=0,
            source_state_sha256=active.get("source_state_sha256") if active else None,
            active=active,
            embedding_receipt_digest=None,
            error_codes=(),
        )

    package_root = adapter.package_root(mount)
    frozen, source_attempts, source_error = _snapshot_kw_source(
        package_root, requested_rooms
    )
    if frozen is None:
        return _observation(
            workspace=workspace,
            started_ns=started_ns,
            status="source_skipped",
            scope=normalized_scope,
            rebuild=rebuild,
            indexed_source_count=0,
            skipped_source_count=1,
            source_attempts=source_attempts,
            source_state_sha256=None,
            active=active,
            embedding_receipt_digest=None,
            error_codes=(source_error or "source_unavailable",),
        )

    output_root = workspace / "dense"
    gpu_receipt_path = workspace / "receipts" / "gpu.jsonl"
    expected_previous = active.get("active_index_id") if active else None
    try:
        inventory = build_dense_release(
            source=frozen,
            gpu=_gpu_client(layout, gpu_receipt_path),
            output_root=output_root,
            slot_namespace=layout.slot_namespace,
            allow_nonproduction=layout.allow_nonproduction,
        )
        if inventory["release_id"] == expected_previous:
            final_active = active
            status = "unchanged"
        else:
            activation = activate_dense_release(
                slot_root=slot_root,
                release_id=inventory["release_id"],
                manifest_sha256=inventory["manifest_sha256"],
                expected_previous_release_id=expected_previous,
            )
            status = "activated"
            final_active = _active_index_summary(slot_root, dict(_load_pointer(slot_root / "current.json") or {}))
            if final_active["active_index_id"] != activation["current_release_id"]:
                raise ProductIndexError("activation_result_mismatch")
        return _observation(
            workspace=workspace,
            started_ns=started_ns,
            status=status,
            scope=normalized_scope,
            rebuild=rebuild,
            indexed_source_count=1,
            skipped_source_count=0,
            source_attempts=source_attempts,
            source_state_sha256=frozen.source_state_sha256,
            active=final_active,
            embedding_receipt_digest=inventory.get(
                "embedding_operation_receipt_digest"
            ),
            error_codes=(),
        )
    except ProductIndexError:
        raise
    except (DenseReleaseError, SharedGpuTransportError, OSError, ValueError) as exc:
        current_status, current_active = _index_state(slot_root)
        code = getattr(exc, "code", None) or type(exc).__name__
        return _observation(
            workspace=workspace,
            started_ns=started_ns,
            status="build_failed",
            scope=normalized_scope,
            rebuild=rebuild,
            indexed_source_count=0,
            skipped_source_count=0,
            source_attempts=source_attempts,
            source_state_sha256=frozen.source_state_sha256,
            active=current_active if current_status == "ready" else None,
            embedding_receipt_digest=None,
            error_codes=(str(code),),
        )


def kwrag_index_status(scope: ProductScope | Any = None) -> dict[str, Any]:
    """Return a content-free observation of source and active index state."""

    normalized_scope = _product_scope(scope)
    adapter = product_source_adapter(normalized_scope.sources[0])
    requested_rooms = normalized_scope.room_ids(adapter.source)
    layout = _runtime_layout()
    mount, workspace = _validate_layout(layout)
    source_status, source_error = _source_availability(
        adapter.package_root(mount), requested_rooms
    )
    try:
        index_status, active = _index_state(_slot_root(workspace, layout))
        error_codes = [source_error] if source_error else []
    except ProductIndexError as exc:
        index_status, active = "invalid", None
        error_codes = [str(exc)]
        if source_error:
            error_codes.append(source_error)
    overall = (
        "ready"
        if index_status == "ready" and source_status == "available"
        else "unbuilt"
        if index_status == "unbuilt"
        else "unavailable"
    )
    return {
        "schema_version": INDEX_STATUS_SCHEMA,
        "status": overall,
        "source_status": source_status,
        "index_status": index_status,
        "supported_source_count": len(PRODUCT_SOURCE_ADAPTERS),
        "active_index_id": active.get("active_index_id") if active else None,
        "previous_index_id": active.get("previous_index_id") if active else None,
        "activation_sequence": active.get("activation_sequence") if active else None,
        "indexed_source_count": active.get("indexed_source_count", 0) if active else 0,
        "indexed_room_count": active.get("indexed_room_count", 0) if active else 0,
        "segment_count": active.get("segment_count") if active else None,
        "source_state_sha256": active.get("source_state_sha256") if active else None,
        "production_eligible": active.get("production_eligible") if active else None,
        "error_codes": error_codes,
        "raw_content_present": False,
    }


__all__ = ["ProductIndexError", "kwrag_index_build", "kwrag_index_status"]
