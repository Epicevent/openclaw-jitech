"""Backend-neutral assembly for one host-portless slot retrieval runtime."""

from __future__ import annotations

import os
import stat
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Mapping

from .jsonutil import is_sha256, loads_canonical_json_bytes
from .operation import ReceiptWriter, SearchPipeline
from .slot_api import SlotSearchApplication, SlotSearchExchange
from .slot_mount import SlotIndexScope, load_slot_index_scope


class SlotRuntimeError(ValueError):
    pass


@dataclass(frozen=True)
class SlotRuntimeSpec:
    mount_root: Path
    index_manifest_relative: str
    index_manifest_digest: str
    receipt_path: Path
    pipeline_fingerprint: str
    max_concurrent: int = 1

    @classmethod
    def from_mapping(cls, raw: Any) -> "SlotRuntimeSpec":
        if not isinstance(raw, Mapping):
            raise SlotRuntimeError("slot runtime binding must be an object")
        expected = {
            "schema_version",
            "mount_root",
            "index_manifest_relative",
            "index_manifest_digest",
            "receipt_path",
            "pipeline_fingerprint",
            "max_concurrent",
        }
        if set(raw) != expected:
            raise SlotRuntimeError("slot runtime binding fields are invalid")
        if raw.get("schema_version") != "kwrag-slot-runtime-binding-v1":
            raise SlotRuntimeError("slot runtime binding schema is invalid")

        mount_raw = str(raw.get("mount_root") or "")
        receipt_raw = str(raw.get("receipt_path") or "")
        mount_root = Path(mount_raw)
        receipt_path = Path(receipt_raw)
        manifest_relative = raw.get("index_manifest_relative")
        manifest_digest = raw.get("index_manifest_digest")
        fingerprint = raw.get("pipeline_fingerprint")
        max_concurrent = raw.get("max_concurrent")
        for value in (mount_raw, receipt_raw):
            if (
                not PurePosixPath(value).is_absolute()
                or "\\" in value
                or ":" in value
                or any(part in {"", ".", ".."} for part in PurePosixPath(value).parts)
            ):
                raise SlotRuntimeError(
                    "slot runtime paths must be absolute canonical POSIX paths"
                )
        if not isinstance(manifest_relative, str) or not manifest_relative:
            raise SlotRuntimeError("index manifest path is missing")
        if not is_sha256(manifest_digest):
            raise SlotRuntimeError("index manifest digest is invalid")
        if not is_sha256(fingerprint):
            raise SlotRuntimeError("pipeline fingerprint is invalid")
        if (
            isinstance(max_concurrent, bool)
            or not isinstance(max_concurrent, int)
            or not 1 <= max_concurrent <= 64
        ):
            raise SlotRuntimeError("slot runtime concurrency is invalid")
        return cls(
            mount_root=mount_root,
            index_manifest_relative=manifest_relative,
            index_manifest_digest=manifest_digest,
            receipt_path=receipt_path,
            pipeline_fingerprint=fingerprint,
            max_concurrent=max_concurrent,
        )


@dataclass(frozen=True)
class SlotRuntime:
    spec: SlotRuntimeSpec
    scope: SlotIndexScope
    application: SlotSearchApplication

    def ready(self) -> dict[str, Any]:
        return self.application.ready()

    def search(self, request: Any) -> dict[str, Any]:
        return self.application.search(request)

    def search_exchange(self, request: Any) -> SlotSearchExchange:
        """Return the response with its exact in-process operation receipt."""

        return self.application.search_exchange(request)


PipelineFactory = Callable[[SlotIndexScope], SearchPipeline]


def load_slot_runtime_spec(path: Path) -> SlotRuntimeSpec:
    """Load one canonical, single-link runtime binding without following a leaf link."""

    source = Path(path)
    if source.is_symlink():
        raise SlotRuntimeError("slot runtime binding cannot be a symlink")
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_BINARY", 0)
    )
    try:
        descriptor = os.open(source, flags)
        try:
            before = os.fstat(descriptor)
            if not stat.S_ISREG(before.st_mode) or before.st_nlink != 1:
                raise SlotRuntimeError(
                    "slot runtime binding must be a single-link regular file"
                )
            chunks: list[bytes] = []
            total = 0
            while True:
                chunk = os.read(descriptor, 16 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > 64 * 1024:
                    raise SlotRuntimeError("slot runtime binding is too large")
                chunks.append(chunk)
            after = os.fstat(descriptor)
            if (
                before.st_dev,
                before.st_ino,
                before.st_size,
                before.st_mtime_ns,
            ) != (
                after.st_dev,
                after.st_ino,
                after.st_size,
                after.st_mtime_ns,
            ):
                raise SlotRuntimeError("slot runtime binding changed while loading")
        finally:
            os.close(descriptor)
        raw = loads_canonical_json_bytes(b"".join(chunks))
        return SlotRuntimeSpec.from_mapping(raw)
    except SlotRuntimeError:
        raise
    except (OSError, UnicodeDecodeError, ValueError) as exc:
        raise SlotRuntimeError("slot runtime binding is invalid") from exc


def build_slot_runtime(
    spec: SlotRuntimeSpec,
    *,
    pipeline_factory: PipelineFactory,
) -> SlotRuntime:
    """Assemble a direct-call runtime without choosing a retrieval backend."""

    try:
        scope = load_slot_index_scope(
            spec.mount_root,
            spec.index_manifest_relative,
            require_readonly=True,
        )
    except ValueError as exc:
        raise SlotRuntimeError(f"slot mount boundary validation failed: {exc}") from exc
    if scope.manifest.digest != spec.index_manifest_digest:
        raise SlotRuntimeError("mounted index manifest does not match the runtime binding")
    pipeline = pipeline_factory(scope)
    application = SlotSearchApplication(
        pipeline=pipeline,
        scope=scope,
        pipeline_fingerprint=spec.pipeline_fingerprint,
        receipt_writer=ReceiptWriter(spec.receipt_path),
        max_concurrent=spec.max_concurrent,
    )
    return SlotRuntime(spec=spec, scope=scope, application=application)
