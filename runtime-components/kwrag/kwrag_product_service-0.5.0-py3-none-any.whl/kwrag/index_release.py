"""Deterministic, slot-isolated index release construction.

The builder consumes one already-authorized kw_corpus user package and writes
only a private, inactive staging tree. It never publishes to NAS, changes a
runtime binding, or treats its output directory as slot-visible. Publication
is a separate PC/DSM credentialed operation in kwrag.index_publisher.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sqlite3
import stat
import unicodedata
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Mapping

from .fixed_producer import _packaged_engine_identity
from .jsonutil import canonical_json_bytes, is_sha256, loads_strict_json


TRANSFORM_ID = "kwrag-authorized-package-turns-v1"
CORPUS_ID = "kakao"
PUBLISH_FILES = (
    "turns.sqlite3",
    "source-snapshot.json",
    "index-manifest.json",
)
_REQUIRED_MESSAGE_COLUMNS = frozenset(
    {
        "conversation_id",
        "message_id",
        "user_id",
        "user_name",
        "sent_time",
        "text_kind",
        "plain_text",
    }
)


class IndexReleaseError(ValueError):
    """The source package or requested release violates the P6 contract."""


@dataclass(frozen=True)
class SlotPublicationSpec:
    slot: str
    host_package_mount: str
    container_package_mount: str
    slot_view_root: str
    binding_path: str
    binding_owner: str
    binding_mode: str
    operation_receipt_path: str
    producer_receipt_path: str


SLOT_SPECS: Mapping[str, SlotPublicationSpec] = {
    "oc14": SlotPublicationSpec(
        slot="oc14",
        host_package_mount="/home/oc14/nas_docs/kw/package",
        container_package_mount="/home/node/nas_docs/kw/package",
        slot_view_root="/srv/kw-nas/slots/oc14/view",
        binding_path="/run/kwrag/fixed-producer-binding.json",
        binding_owner="root:root",
        binding_mode="0444",
        operation_receipt_path=(
            "/home/node/.openclaw/agent-runtime/kwrag/operation-receipts.jsonl"
        ),
        producer_receipt_path=(
            "/home/node/.openclaw/agent-runtime/kwrag/producer-receipts.jsonl"
        ),
    ),
    "oc20": SlotPublicationSpec(
        slot="oc20",
        host_package_mount="/home/oc20/nas_docs/kw/package",
        container_package_mount="/workspace/nas_docs/kw/package",
        slot_view_root="/srv/kw-nas/slots/oc20/view",
        binding_path="/run/kwrag/fixed-producer-binding.json",
        binding_owner="root:root",
        binding_mode="0444",
        operation_receipt_path=(
            "/opt/data/kwrag-p1-attachment/operation-receipts.jsonl"
        ),
        producer_receipt_path=(
            "/opt/data/kwrag-p1-attachment/producer-receipts.jsonl"
        ),
    ),
}


@dataclass(frozen=True)
class FileIdentity:
    device: int
    inode: int
    mode: int
    links: int
    size: int
    mtime_ns: int


@dataclass(frozen=True)
class Message:
    conversation_id: str
    message_id: str
    user_id: str
    user_name: str
    sent_time: int
    text: str


@dataclass(frozen=True)
class Turn:
    conversation_id: str
    user_id: str
    user_name: str
    sent_time: int
    end_time: int
    text: str
    message_ids: tuple[str, ...]


def _sha256_bytes(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _file_identity(path: Path) -> FileIdentity:
    try:
        metadata = path.lstat()
    except OSError as exc:
        raise IndexReleaseError("source_file_unavailable") from exc
    if (
        stat.S_ISLNK(metadata.st_mode)
        or not stat.S_ISREG(metadata.st_mode)
        or metadata.st_nlink != 1
    ):
        raise IndexReleaseError("source_file_identity_invalid")
    return FileIdentity(
        device=metadata.st_dev,
        inode=metadata.st_ino,
        mode=metadata.st_mode,
        links=metadata.st_nlink,
        size=metadata.st_size,
        mtime_ns=metadata.st_mtime_ns,
    )


def _stable_file(path: Path, *, maximum: int) -> tuple[bytes, str, FileIdentity]:
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_BINARY", 0)
    )
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise IndexReleaseError("source_file_unavailable") from exc
    chunks: list[bytes] = []
    try:
        before_raw = os.fstat(descriptor)
        before = FileIdentity(
            device=before_raw.st_dev,
            inode=before_raw.st_ino,
            mode=before_raw.st_mode,
            links=before_raw.st_nlink,
            size=before_raw.st_size,
            mtime_ns=before_raw.st_mtime_ns,
        )
        if (
            not stat.S_ISREG(before.mode)
            or before.links != 1
            or before.size < 1
            or before.size > maximum
        ):
            raise IndexReleaseError("source_file_identity_invalid")
        while True:
            block = os.read(descriptor, 1024 * 1024)
            if not block:
                break
            chunks.append(block)
            if sum(map(len, chunks)) > maximum:
                raise IndexReleaseError("source_file_size_invalid")
        after_raw = os.fstat(descriptor)
        after = FileIdentity(
            device=after_raw.st_dev,
            inode=after_raw.st_ino,
            mode=after_raw.st_mode,
            links=after_raw.st_nlink,
            size=after_raw.st_size,
            mtime_ns=after_raw.st_mtime_ns,
        )
        if before != after:
            raise IndexReleaseError("source_file_changed")
    finally:
        os.close(descriptor)
    payload = b"".join(chunks)
    return payload, _sha256_bytes(payload), before


def _strict_object(payload: bytes, *, code: str) -> dict[str, Any]:
    try:
        value = loads_strict_json(payload.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise IndexReleaseError(code) from exc
    if not isinstance(value, dict):
        raise IndexReleaseError(code)
    return value


def _write_bytes(path: Path, payload: bytes) -> tuple[str, int]:
    if path.exists() or path.is_symlink():
        raise IndexReleaseError("release_output_collision")
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    descriptor = os.open(
        path,
        os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_CLOEXEC", 0),
        0o600,
    )
    try:
        offset = 0
        while offset < len(payload):
            offset += os.write(descriptor, payload[offset:])
        os.fsync(descriptor)
    finally:
        os.close(descriptor)
    return _sha256_bytes(payload), len(payload)


def _write_canonical(path: Path, value: object) -> tuple[str, int]:
    return _write_bytes(path, canonical_json_bytes(value))


def _validate_remote_package(value: str, package_name: str) -> str:
    if not isinstance(value, str) or value != unicodedata.normalize("NFC", value):
        raise IndexReleaseError("publisher_remote_package_invalid")
    pure = PurePosixPath(value)
    if (
        not pure.is_absolute()
        or pure.as_posix() != value
        or "\\" in value
        or ":" in value
        or pure.parts != ("/", "kakao-work", "users", package_name)
    ):
        raise IndexReleaseError("publisher_remote_package_invalid")
    return value


def _validate_package(path: Path) -> Path:
    supplied = Path(path)
    try:
        metadata = supplied.lstat()
        resolved = supplied.resolve(strict=True)
    except OSError as exc:
        raise IndexReleaseError("source_package_unavailable") from exc
    if supplied.is_symlink() or not stat.S_ISDIR(metadata.st_mode):
        raise IndexReleaseError("source_package_identity_invalid")
    if resolved.name != unicodedata.normalize("NFC", resolved.name):
        raise IndexReleaseError("source_package_name_not_nfc")
    return resolved


def _load_membership(path: Path) -> tuple[dict[str, Any], bytes, str, FileIdentity]:
    payload, digest, identity = _stable_file(path, maximum=1024 * 1024)
    value = _strict_object(payload, code="membership_invalid")
    if value.get("schema") != "kw-corpus-nas-user":
        raise IndexReleaseError("membership_schema_invalid")
    raw_ids = value.get("conversation_ids")
    if (
        not isinstance(raw_ids, list)
        or not raw_ids
        or any(
            not isinstance(item, str)
            or not item
            or item != item.strip()
            or len(item) > 256
            for item in raw_ids
        )
        or len(raw_ids) != len(set(raw_ids))
    ):
        raise IndexReleaseError("membership_conversation_ids_invalid")
    return value, payload, digest, identity


def _normalize_text(value: object) -> str:
    if not isinstance(value, str):
        raise IndexReleaseError("message_text_invalid")
    normalized = unicodedata.normalize(
        "NFC", value.replace("\r\n", "\n").replace("\r", "\n")
    )
    return normalized.strip()


def _source_messages(
    source_db: Path,
    *,
    authorized_conversations: set[str],
) -> tuple[list[Message], dict[str, int]]:
    uri = source_db.resolve(strict=True).as_uri() + "?mode=ro&immutable=1"
    try:
        connection = sqlite3.connect(uri, uri=True)
    except sqlite3.Error as exc:
        raise IndexReleaseError("source_database_unavailable") from exc
    try:
        if connection.execute("PRAGMA integrity_check").fetchall() != [("ok",)]:
            raise IndexReleaseError("source_database_integrity_invalid")
        tables = {
            str(row[0])
            for row in connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            )
        }
        if not {"messages", "messages_fts"}.issubset(tables):
            raise IndexReleaseError("source_database_tables_invalid")
        columns = {
            str(row[1])
            for row in connection.execute("PRAGMA table_info(messages)")
        }
        if not _REQUIRED_MESSAGE_COLUMNS.issubset(columns):
            raise IndexReleaseError("source_database_columns_invalid")
        db_conversations = {
            str(row[0])
            for row in connection.execute(
                "SELECT DISTINCT conversation_id FROM messages"
            )
        }
        if db_conversations != authorized_conversations:
            raise IndexReleaseError("source_membership_database_scope_mismatch")
        source_count = int(
            connection.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
        )
        source_fts_count = int(
            connection.execute("SELECT COUNT(*) FROM messages_fts").fetchone()[0]
        )
        if source_count != source_fts_count:
            raise IndexReleaseError("source_fts_coverage_mismatch")
        rows = connection.execute(
            """
            SELECT conversation_id,message_id,user_id,user_name,sent_time,plain_text
            FROM messages
            WHERE plain_text IS NOT NULL AND TRIM(plain_text) != ''
            ORDER BY conversation_id,sent_time,message_id,user_id,user_name
            """
        ).fetchall()
    except sqlite3.Error as exc:
        raise IndexReleaseError("source_database_query_failed") from exc
    finally:
        connection.close()

    messages: list[Message] = []
    message_ids: set[str] = set()
    for raw_cid, raw_mid, raw_uid, raw_name, raw_time, raw_text in rows:
        cid = str(raw_cid)
        mid = str(raw_mid)
        if cid not in authorized_conversations:
            raise IndexReleaseError("source_message_outside_membership")
        if not mid or len(mid) > 256 or mid in message_ids:
            raise IndexReleaseError("source_message_id_invalid_or_reused")
        message_ids.add(mid)
        try:
            sent_time = int(raw_time or 0)
        except (TypeError, ValueError) as exc:
            raise IndexReleaseError("source_message_time_invalid") from exc
        text = _normalize_text(raw_text)
        if not text:
            continue
        messages.append(
            Message(
                conversation_id=cid,
                message_id=mid,
                user_id=unicodedata.normalize("NFC", str(raw_uid or "?")),
                user_name=unicodedata.normalize("NFC", str(raw_name or "?")),
                sent_time=sent_time,
                text=text,
            )
        )
    if not messages:
        raise IndexReleaseError("source_has_no_indexable_messages")
    return messages, {
        "source_message_count": source_count,
        "source_fts_count": source_fts_count,
        "indexable_message_count": len(messages),
    }


def _merge_turns(messages: list[Message]) -> list[Turn]:
    grouped: dict[str, list[Message]] = {}
    for message in messages:
        grouped.setdefault(message.conversation_id, []).append(message)
    turns: list[Turn] = []
    for conversation_id in sorted(grouped):
        room = grouped[conversation_id]
        gaps = sorted(
            max(0, room[index].sent_time - room[index - 1].sent_time)
            for index in range(1, len(room))
        )
        adaptive_gap = max(30, gaps[len(gaps) // 2] if gaps else 60)
        active: dict[str, Any] | None = None
        for message in room:
            if (
                active is not None
                and message.user_id == active["user_id"]
                and message.sent_time - active["end_time"] <= adaptive_gap
            ):
                active["texts"].append(message.text)
                active["message_ids"].append(message.message_id)
                active["end_time"] = message.sent_time
                continue
            if active is not None:
                turns.append(
                    Turn(
                        conversation_id=conversation_id,
                        user_id=active["user_id"],
                        user_name=active["user_name"],
                        sent_time=active["sent_time"],
                        end_time=active["end_time"],
                        text=" ".join(active["texts"]),
                        message_ids=tuple(active["message_ids"]),
                    )
                )
            active = {
                "user_id": message.user_id,
                "user_name": message.user_name,
                "sent_time": message.sent_time,
                "end_time": message.sent_time,
                "texts": [message.text],
                "message_ids": [message.message_id],
            }
        if active is not None:
            turns.append(
                Turn(
                    conversation_id=conversation_id,
                    user_id=active["user_id"],
                    user_name=active["user_name"],
                    sent_time=active["sent_time"],
                    end_time=active["end_time"],
                    text=" ".join(active["texts"]),
                    message_ids=tuple(active["message_ids"]),
                )
            )
    if not turns:
        raise IndexReleaseError("transform_produced_no_turns")
    return turns


def _build_database(path: Path, turns: list[Turn]) -> tuple[str, int]:
    if path.exists() or path.is_symlink():
        raise IndexReleaseError("release_output_collision")
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    connection = sqlite3.connect(path)
    try:
        connection.executescript(
            """
            PRAGMA page_size=4096;
            PRAGMA auto_vacuum=NONE;
            PRAGMA journal_mode=DELETE;
            PRAGMA synchronous=FULL;
            PRAGMA temp_store=MEMORY;
            PRAGMA application_id=1264017735;
            PRAGMA user_version=1;
            CREATE TABLE turns(
                turn_id INTEGER PRIMARY KEY,
                text TEXT NOT NULL
            );
            CREATE TABLE turn_mids(
                turn_id INTEGER NOT NULL,
                mid TEXT NOT NULL
            );
            CREATE INDEX turn_mids_turn_id ON turn_mids(turn_id,mid);
            CREATE UNIQUE INDEX turn_mids_mid ON turn_mids(mid);
            CREATE VIRTUAL TABLE turns_fts USING fts5(
                turn_id UNINDEXED,
                text,
                tokenize='trigram'
            );
            """
        )
        for turn_id, turn in enumerate(turns, 1):
            connection.execute(
                "INSERT INTO turns(turn_id,text) VALUES(?,?)",
                (turn_id, turn.text),
            )
            connection.execute(
                "INSERT INTO turns_fts(turn_id,text) VALUES(?,?)",
                (turn_id, turn.text),
            )
            connection.executemany(
                "INSERT INTO turn_mids(turn_id,mid) VALUES(?,?)",
                ((turn_id, message_id) for message_id in turn.message_ids),
            )
        connection.commit()
        connection.execute("VACUUM")
    except sqlite3.Error as exc:
        raise IndexReleaseError("release_database_build_failed") from exc
    finally:
        connection.close()
    os.chmod(path, 0o600)
    uri = path.resolve(strict=True).as_uri() + "?mode=ro&immutable=1"
    verify = sqlite3.connect(uri, uri=True)
    try:
        if verify.execute("PRAGMA integrity_check").fetchall() != [("ok",)]:
            raise IndexReleaseError("release_database_integrity_invalid")
        sql = str(
            verify.execute(
                "SELECT sql FROM sqlite_master WHERE name='turns_fts'"
            ).fetchone()[0]
        ).lower()
        counts = {
            "turns": int(verify.execute("SELECT COUNT(*) FROM turns").fetchone()[0]),
            "fts": int(
                verify.execute("SELECT COUNT(*) FROM turns_fts").fetchone()[0]
            ),
            "mids": int(
                verify.execute("SELECT COUNT(*) FROM turn_mids").fetchone()[0]
            ),
            "distinct_mids": int(
                verify.execute(
                    "SELECT COUNT(DISTINCT mid) FROM turn_mids"
                ).fetchone()[0]
            ),
            "orphans": int(
                verify.execute(
                    """
                    SELECT COUNT(*) FROM turn_mids m
                    LEFT JOIN turns t ON t.turn_id=m.turn_id
                    WHERE t.turn_id IS NULL
                    """
                ).fetchone()[0]
            ),
        }
        if (
            "tokenize='trigram'" not in sql.replace(" ", "")
            or counts["turns"] != len(turns)
            or counts["fts"] != len(turns)
            or counts["mids"] != sum(len(turn.message_ids) for turn in turns)
            or counts["mids"] != counts["distinct_mids"]
            or counts["orphans"] != 0
        ):
            raise IndexReleaseError("release_database_contract_invalid")
    finally:
        verify.close()
    payload, digest, _identity = _stable_file(path, maximum=512 * 1024 * 1024)
    return digest, len(payload)


def _builder_source_digest() -> str:
    payload, digest, _identity = _stable_file(
        Path(__file__).resolve(strict=True),
        maximum=256 * 1024,
    )
    if not payload:
        raise IndexReleaseError("builder_source_unavailable")
    return digest


def _release_name(
    *,
    slot: str,
    remote_package: str,
    database_digest: str,
    source_snapshot_digest: str,
    engine_identity: Mapping[str, str],
    builder_source_digest: str,
) -> str:
    preimage = {
        "schema_version": "kwrag-index-release-identity-v1",
        "slot": slot,
        "publisher_remote_package": remote_package,
        "database_sha256": database_digest,
        "source_snapshot_sha256": source_snapshot_digest,
        "transform_id": TRANSFORM_ID,
        "builder_source_sha256": builder_source_digest,
        "selected_engine": dict(engine_identity),
    }
    digest = _sha256_bytes(canonical_json_bytes(preimage)).removeprefix("sha256:")
    return "sha256-" + digest


def _slot_binding_input(
    *,
    spec: SlotPublicationSpec,
    release_name: str,
    manifest_digest: str,
    database_digest: str,
    snapshot_digest: str,
    engine_identity: Mapping[str, str],
) -> dict[str, Any]:
    manifest_relative = f"kwrag/releases/{release_name}/index-manifest.json"
    return {
        "schema_version": "kwrag-fixed-producer-binding-input-v1",
        "status": "INACTIVE_REQUIRES_ROOT_AND_PRODUCT_MATERIALIZATION",
        "binding_projection": {
            "container_path": spec.binding_path,
            "owner": spec.binding_owner,
            "mode": spec.binding_mode,
            "source_owner": "Common OPS and product owner",
        },
        "blocked_by": [
            "service_identity_exact_release_read_only_authority_receipt",
            "product_owned_durable_receipt_projection",
            "root_owned_binding_projection",
        ],
        "value": {
            "schema_version": "kwrag-fixed-producer-binding-v1",
            "enabled": False,
            "mount_root": spec.container_package_mount,
            "index_manifest_relative": manifest_relative,
            "index_manifest_digest": manifest_digest,
            "operation_receipt_path": spec.operation_receipt_path,
            "producer_receipt_path": spec.producer_receipt_path,
            "max_concurrent": 1,
            "selected_engine": dict(engine_identity),
            "corpora": {
                CORPUS_ID: {
                    "database_relative": "turns.sqlite3",
                    "database_sha256": database_digest,
                    "source_snapshot_relative": "source-snapshot.json",
                    "source_snapshot_digest": snapshot_digest,
                    "authority_receipt_digest": None,
                }
            },
        },
    }


def build_release(
    *,
    slot: str,
    package: Path,
    output: Path,
    publisher_remote_package: str,
) -> dict[str, Any]:
    """Build one deterministic inactive release tree."""

    if slot not in SLOT_SPECS:
        raise IndexReleaseError("slot_invalid")
    spec = SLOT_SPECS[slot]
    source_package = _validate_package(Path(package))
    remote_package = _validate_remote_package(
        publisher_remote_package, source_package.name
    )
    output = Path(output)
    if output.exists() or output.is_symlink():
        raise IndexReleaseError("output_must_not_exist")
    resolved_output = output.resolve(strict=False)
    try:
        resolved_output.relative_to(source_package)
    except ValueError:
        pass
    else:
        raise IndexReleaseError("output_cannot_be_inside_source_package")
    output.mkdir(mode=0o700, parents=True)
    os.chmod(output, 0o700)
    private_payload = output / ".building"
    private_payload.mkdir(mode=0o700)

    membership_path = source_package / "membership.json"
    source_db = source_package / "messages.sqlite"
    membership, membership_bytes, membership_digest, membership_identity = (
        _load_membership(membership_path)
    )
    source_db_payload, source_db_digest, source_db_identity = _stable_file(
        source_db, maximum=512 * 1024 * 1024
    )
    if not source_db_payload.startswith(b"SQLite format 3\x00"):
        raise IndexReleaseError("source_database_header_invalid")
    authorized = set(membership["conversation_ids"])
    messages, source_counts = _source_messages(
        source_db, authorized_conversations=authorized
    )
    turns = _merge_turns(messages)

    database_path = private_payload / "turns.sqlite3"
    database_digest, database_bytes = _build_database(database_path, turns)
    builder_digest = _builder_source_digest()
    engine_identity = _packaged_engine_identity()
    snapshot = {
        "schema_version": "kwrag-source-snapshot-v1",
        "slot": slot,
        "source_kind": "kw_corpus_authorized_user_package",
        "publisher_remote_package": remote_package,
        "source_membership_sha256": membership_digest,
        "source_membership_bytes": len(membership_bytes),
        "source_database_sha256": source_db_digest,
        "source_database_bytes": len(source_db_payload),
        "authorized_conversation_count": len(authorized),
        "authorized_conversation_set_sha256": _sha256_bytes(
            canonical_json_bytes(sorted(authorized))
        ),
        "source_message_count": source_counts["source_message_count"],
        "source_fts_count": source_counts["source_fts_count"],
        "indexable_message_count": source_counts["indexable_message_count"],
        "indexable_message_set_sha256": _sha256_bytes(
            canonical_json_bytes(
                sorted(message.message_id for message in messages)
            )
        ),
        "turn_count": len(turns),
        "transform_id": TRANSFORM_ID,
        "transform": {
            "input": "all_nonempty_plain_text_in_authorized_package",
            "order": [
                "conversation_id",
                "sent_time",
                "message_id",
                "user_id",
                "user_name",
            ],
            "turn_merge": (
                "consecutive_same_user_per_conversation_with_"
                "max_30_or_median_nonnegative_gap_seconds"
            ),
            "unicode": "NFC",
            "line_endings": "LF",
            "fts5_tokenizer": "trigram",
        },
        "builder_source_sha256": builder_digest,
        "selected_engine": engine_identity,
        "raw_content_in_snapshot": False,
    }
    snapshot_path = private_payload / "source-snapshot.json"
    snapshot_digest, snapshot_bytes = _write_canonical(snapshot_path, snapshot)
    release_name = _release_name(
        slot=slot,
        remote_package=remote_package,
        database_digest=database_digest,
        source_snapshot_digest=snapshot_digest,
        engine_identity=engine_identity,
        builder_source_digest=builder_digest,
    )
    manifest = {
        "version": 1,
        "release_id": release_name,
        "corpus_snapshot": _sha256_bytes(
            canonical_json_bytes({CORPUS_ID: snapshot_digest})
        ),
        "embedding_fingerprint": engine_identity["pipeline_fingerprint"],
        "rooms": {
            CORPUS_ID: {
                "conversation_id": f"authorized-package:{slot}",
                "files": [
                    {"path": "turns.sqlite3", "sha256": database_digest},
                    {"path": "source-snapshot.json", "sha256": snapshot_digest},
                ],
            }
        },
    }
    manifest_path = private_payload / "index-manifest.json"
    manifest_digest, manifest_bytes = _write_canonical(manifest_path, manifest)

    if (
        _file_identity(membership_path) != membership_identity
        or _file_identity(source_db) != source_db_identity
        or _stable_file(membership_path, maximum=1024 * 1024)[1]
        != membership_digest
        or _stable_file(source_db, maximum=512 * 1024 * 1024)[1]
        != source_db_digest
    ):
        raise IndexReleaseError("source_package_changed_during_build")

    release_relative = f"releases/{slot}/{release_name}"
    release_directory = output / release_relative
    release_directory.parent.mkdir(mode=0o700, parents=True)
    private_payload.replace(release_directory)
    remote_release = f"{remote_package}/kwrag/releases/{release_name}"
    publication_files = [
        {
            "relative": "turns.sqlite3",
            "sha256": database_digest,
            "bytes": database_bytes,
            "order": 1,
        },
        {
            "relative": "source-snapshot.json",
            "sha256": snapshot_digest,
            "bytes": snapshot_bytes,
            "order": 2,
        },
        {
            "relative": "index-manifest.json",
            "sha256": manifest_digest,
            "bytes": manifest_bytes,
            "order": 3,
        },
    ]
    publication_plan = {
        "schema_version": "kwrag-pc-dsm-index-publication-plan-v1",
        "status": "READY_FOR_EXACT_PC_CREDENTIAL_ACTION_NOT_EXECUTED",
        "slot": slot,
        "publisher": {
            "owner": "kw_corpus kw publish nas",
            "os_principal": (
                "PC owner running the authoritative kw_corpus publisher"
            ),
            "credential": "dedicated Synology RW account via NAS_DSM_USER",
            "credential_material_present": False,
            "required_remote_root": "/kakao-work",
            "required_grant": f"read/write only for {remote_release}",
        },
        "source_package": {
            "remote_package": remote_package,
            "membership_sha256": membership_digest,
            "database_sha256": source_db_digest,
        },
        "release": {
            "release_id": release_name,
            "release_relative": release_relative,
            "remote_release": remote_release,
            "host_slot_visible_release": (
                f"{spec.host_package_mount}/kwrag/releases/{release_name}"
            ),
            "container_slot_visible_release": (
                f"{spec.container_package_mount}/kwrag/releases/{release_name}"
            ),
            "slot_view_root": spec.slot_view_root,
        },
        "upload": {
            "files": publication_files,
            "manifest_last": True,
            "overwrite_existing_mismatch": False,
            "unknown_remote_entry": "fail_closed",
            "cross_slot_reuse": False,
            "delete_or_rename": False,
        },
        "postcheck": {
            "read_back_every_file_sha256": True,
            "manifest_digest": manifest_digest,
            "server_service_identity_observation_required_after_publication": True,
            "raw_content_in_receipt": False,
        },
        "failure_state": (
            "no active binding changes; incomplete immutable directory may "
            "remain inactive and retained for later credentialed GC"
        ),
    }
    control_root = output / "control" / slot
    plan_digest, plan_bytes = _write_canonical(
        control_root / "publication-plan.json", publication_plan
    )
    binding_input = _slot_binding_input(
        spec=spec,
        release_name=release_name,
        manifest_digest=manifest_digest,
        database_digest=database_digest,
        snapshot_digest=snapshot_digest,
        engine_identity=engine_identity,
    )
    binding_input_digest, binding_input_bytes = _write_canonical(
        control_root / "fixed-producer-binding-input.json", binding_input
    )
    rollback = {
        "schema_version": "kwrag-index-release-rollback-retention-v1",
        "slot": slot,
        "release_id": release_name,
        "publication_changes_active_reference": False,
        "pre_publication_runtime_state": "disabled_or_absent",
        "post_publication_runtime_state": "disabled_or_absent",
        "rollback_after_publication_only": "no runtime action; retain release",
        "rollback_after_later_activation": (
            "Common OPS/product owner atomically restores previous root-owned "
            "binding or installs a disabled binding and emits a linked receipt"
        ),
        "retention_owner": "PC kw_corpus dedicated Synology publisher",
        "gc_owner": "PC kw_corpus dedicated Synology publisher",
        "canary_gc_policy": "retain every canary release",
        "later_gc_preconditions": [
            "release is neither current nor previous",
            "disable_or_rollback terminal receipt exists",
            "linked publication and consumption receipts remain retained",
        ],
        "delete_authorized_by_this_plan": False,
    }
    rollback_digest, rollback_bytes = _write_canonical(
        control_root / "rollback-retention.json", rollback
    )
    inventory = {
        "schema_version": "kwrag-private-index-release-inventory-v1",
        "slot": slot,
        "publication_status": "PRIVATE_STAGING_ONLY_NOT_SLOT_VISIBLE",
        "release_id": release_name,
        "release_relative": release_relative,
        "publisher_remote_release": remote_release,
        "authorized_conversation_count": len(authorized),
        "source_message_count": source_counts["source_message_count"],
        "indexable_message_count": source_counts["indexable_message_count"],
        "turn_count": len(turns),
        "files": publication_files,
        "publication_plan_sha256": plan_digest,
        "publication_plan_bytes": plan_bytes,
        "binding_input_sha256": binding_input_digest,
        "binding_input_bytes": binding_input_bytes,
        "rollback_retention_sha256": rollback_digest,
        "rollback_retention_bytes": rollback_bytes,
        "active_release": None,
        "credential_used": False,
        "runtime_mutation": False,
        "raw_content_in_inventory": False,
    }
    inventory_digest, inventory_bytes = _write_canonical(
        output / "inventory.json", inventory
    )
    return {
        **inventory,
        "inventory_sha256": inventory_digest,
        "inventory_bytes": inventory_bytes,
    }


def materialize_binding(
    *,
    binding_input_path: Path,
    authority_receipt_digest: str,
    destination: Path,
    enabled: bool = False,
) -> dict[str, Any]:
    """Fill the one root-observation field after that receipt actually exists."""

    if not is_sha256(authority_receipt_digest):
        raise IndexReleaseError("authority_receipt_digest_invalid")
    if not isinstance(enabled, bool):
        raise IndexReleaseError("binding_enabled_invalid")
    payload, _digest, _identity = _stable_file(
        Path(binding_input_path), maximum=256 * 1024
    )
    value = _strict_object(payload, code="binding_input_invalid")
    if (
        value.get("schema_version")
        != "kwrag-fixed-producer-binding-input-v1"
        or not isinstance(value.get("value"), dict)
    ):
        raise IndexReleaseError("binding_input_invalid")
    binding = json.loads(json.dumps(value["value"]))
    binding["enabled"] = enabled
    corpus = binding.get("corpora", {}).get(CORPUS_ID)
    if (
        not isinstance(corpus, dict)
        or corpus.get("authority_receipt_digest") is not None
    ):
        raise IndexReleaseError("binding_input_authority_state_invalid")
    corpus["authority_receipt_digest"] = authority_receipt_digest
    digest, size = _write_canonical(Path(destination), binding)
    return {
        "schema_version": "kwrag-fixed-producer-binding-materialization-v1",
        "binding_sha256": digest,
        "binding_bytes": size,
        "enabled": enabled,
        "authority_receipt_digest": authority_receipt_digest,
    }


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Build one inactive, private KWRAG index release."
    )
    parser.add_argument("--slot", required=True, choices=sorted(SLOT_SPECS))
    parser.add_argument("--package", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--publisher-remote-package", required=True)
    return parser


def main() -> int:
    args = _parser().parse_args()
    try:
        inventory = build_release(
            slot=args.slot,
            package=args.package,
            output=args.output,
            publisher_remote_package=args.publisher_remote_package,
        )
    except (IndexReleaseError, OSError, sqlite3.Error) as exc:
        print(
            canonical_json_bytes(
                {
                    "schema_version": "kwrag-index-release-build-error-v1",
                    "code": str(exc),
                }
            ).decode("utf-8")
        )
        return 2
    print(canonical_json_bytes(inventory).decode("utf-8"))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
