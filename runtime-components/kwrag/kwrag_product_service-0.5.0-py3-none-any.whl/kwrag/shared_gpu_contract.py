"""Fixed wire and evidence contract for the host-local shared GPU plane."""

from __future__ import annotations

import hashlib
import math
import re
import time
from dataclasses import dataclass
from typing import Any, Mapping

from .jsonutil import canonical_json_bytes, is_sha256


REQUEST_SCHEMA = "kwrag-shared-gpu-request-v1"
RESPONSE_SCHEMA = "kwrag-shared-gpu-response-v1"
RECEIPT_SCHEMA = "kwrag-shared-gpu-execution-receipt-v1"

KURE_MODEL = "nlpai-lab/KURE-v1"
KURE_REVISION = "d14c8a9423946e268a0c9952fecf3a7aabd73bd9"
KURE_DIMENSION = 1_024
RERANK_MODEL = "BAAI/bge-reranker-v2-m3"
RERANK_REVISION = "953dc6f6f85a1b2dbfca4c34a2796e7dde08d41e"
MODEL_MAX_TOKENS = 512

MAX_FRAME_BYTES = 2 * 1024 * 1024
MAX_DEADLINE_MS = 60_000
MAX_QUERY_CHARS = 4_000
MAX_QUERY_UTF8_BYTES = 16_000
MAX_CORPUS_TEXT_CHARS = 4_000
MAX_CORPUS_BATCH = 32
MAX_CORPUS_TOTAL_UTF8_BYTES = 256 * 1024
MAX_RERANK_PASSAGE_CHARS = 8_000
MAX_RERANK_PAIRS = 32
MAX_RERANK_TOTAL_UTF8_BYTES = 256 * 1024
MAX_VECTOR_DIMENSION = 4_096

_REQUEST_FIELDS = frozenset(
    {
        "schema_version",
        "request_id",
        "operation",
        "slot",
        "principal",
        "deadline_unix_ms",
        "payload",
    }
)
_RESPONSE_FIELDS = frozenset(
    {
        "schema_version",
        "request_id",
        "operation",
        "status",
        "output",
        "error",
        "receipt",
        "receipt_digest",
    }
)
_RECEIPT_FIELDS = frozenset(
    {
        "schema_version",
        "request_id",
        "operation",
        "status",
        "model",
        "revision",
        "production_backend",
        "input_count",
        "input_utf8_bytes",
        "output_count",
        "output_shape",
        "external_persistence",
        "raw_content_persisted_bytes",
        "duration_ms",
        "error_code",
    }
)
_ERROR_FIELDS = frozenset({"code", "retryable"})
_OPERATIONS = frozenset(
    {"embed_query", "embed_corpus", "rerank", "health", "ready", "cancel"}
)
_SLOT_RE = re.compile(r"[a-z][a-z0-9_-]{0,63}\Z")
_REQUEST_ID_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,127}\Z")
_PRINCIPAL_RE = re.compile(r"uid:(0|[1-9][0-9]{0,19})\Z")


class SharedGpuContractError(ValueError):
    def __init__(self, code: str, *, retryable: bool = False):
        super().__init__(code)
        self.code = code
        self.retryable = retryable


@dataclass(frozen=True)
class ValidatedGpuRequest:
    request_id: str
    operation: str
    slot: str
    principal: str
    deadline_unix_ms: int
    payload: Mapping[str, Any]
    input_count: int
    input_utf8_bytes: int


def _text(
    value: Any,
    *,
    code: str,
    max_chars: int,
    max_bytes: int,
) -> tuple[str, int]:
    if (
        not isinstance(value, str)
        or not value
        or len(value) > max_chars
        or "\x00" in value
    ):
        raise SharedGpuContractError(code)
    encoded = value.encode("utf-8")
    if len(encoded) > max_bytes:
        raise SharedGpuContractError(code)
    return value, len(encoded)


def _exact_payload(raw: Any, fields: set[str], code: str) -> Mapping[str, Any]:
    if not isinstance(raw, Mapping) or set(raw) != fields:
        raise SharedGpuContractError(code)
    return raw


def validate_request(
    raw: Any,
    *,
    now_unix_ms: int | None = None,
) -> ValidatedGpuRequest:
    if not isinstance(raw, Mapping) or set(raw) != _REQUEST_FIELDS:
        raise SharedGpuContractError("request_fields_invalid")
    if raw.get("schema_version") != REQUEST_SCHEMA:
        raise SharedGpuContractError("request_schema_invalid")
    request_id = raw.get("request_id")
    operation = raw.get("operation")
    slot = raw.get("slot")
    principal = raw.get("principal")
    if not isinstance(request_id, str) or _REQUEST_ID_RE.fullmatch(request_id) is None:
        raise SharedGpuContractError("request_id_invalid")
    if operation not in _OPERATIONS:
        raise SharedGpuContractError("operation_invalid")
    if not isinstance(slot, str) or _SLOT_RE.fullmatch(slot) is None:
        raise SharedGpuContractError("slot_invalid")
    if not isinstance(principal, str) or _PRINCIPAL_RE.fullmatch(principal) is None:
        raise SharedGpuContractError("principal_invalid")
    deadline = raw.get("deadline_unix_ms")
    now = int(time.time() * 1_000) if now_unix_ms is None else now_unix_ms
    if (
        isinstance(deadline, bool)
        or not isinstance(deadline, int)
        or deadline <= now
        or deadline > now + MAX_DEADLINE_MS
    ):
        raise SharedGpuContractError("deadline_invalid")
    payload = raw.get("payload")
    input_count = 0
    input_bytes = 0
    if operation == "embed_query":
        payload = _exact_payload(payload, {"text"}, "embed_query_payload_invalid")
        _value, input_bytes = _text(
            payload.get("text"),
            code="query_text_invalid",
            max_chars=MAX_QUERY_CHARS,
            max_bytes=MAX_QUERY_UTF8_BYTES,
        )
        input_count = 1
    elif operation == "embed_corpus":
        payload = _exact_payload(payload, {"texts"}, "embed_corpus_payload_invalid")
        texts = payload.get("texts")
        if not isinstance(texts, list) or not 1 <= len(texts) <= MAX_CORPUS_BATCH:
            raise SharedGpuContractError("corpus_batch_invalid")
        for value in texts:
            _item, size = _text(
                value,
                code="corpus_text_invalid",
                max_chars=MAX_CORPUS_TEXT_CHARS,
                max_bytes=MAX_CORPUS_TOTAL_UTF8_BYTES,
            )
            input_bytes += size
        if input_bytes > MAX_CORPUS_TOTAL_UTF8_BYTES:
            raise SharedGpuContractError("corpus_batch_bytes_invalid")
        input_count = len(texts)
    elif operation == "rerank":
        payload = _exact_payload(payload, {"query", "passages"}, "rerank_payload_invalid")
        _query, query_bytes = _text(
            payload.get("query"),
            code="query_text_invalid",
            max_chars=MAX_QUERY_CHARS,
            max_bytes=MAX_QUERY_UTF8_BYTES,
        )
        passages = payload.get("passages")
        if not isinstance(passages, list) or not 1 <= len(passages) <= MAX_RERANK_PAIRS:
            raise SharedGpuContractError("rerank_pairs_invalid")
        passage_bytes = 0
        for value in passages:
            _item, size = _text(
                value,
                code="rerank_passage_invalid",
                max_chars=MAX_RERANK_PASSAGE_CHARS,
                max_bytes=MAX_RERANK_TOTAL_UTF8_BYTES,
            )
            passage_bytes += size
        input_bytes = query_bytes + passage_bytes
        if input_bytes > MAX_RERANK_TOTAL_UTF8_BYTES:
            raise SharedGpuContractError("rerank_bytes_invalid")
        input_count = len(passages)
    elif operation == "cancel":
        payload = _exact_payload(payload, {"target_request_id"}, "cancel_payload_invalid")
        target = payload.get("target_request_id")
        if not isinstance(target, str) or _REQUEST_ID_RE.fullmatch(target) is None:
            raise SharedGpuContractError("cancel_target_invalid")
    else:
        payload = _exact_payload(payload, set(), f"{operation}_payload_invalid")
    return ValidatedGpuRequest(
        request_id=request_id,
        operation=str(operation),
        slot=slot,
        principal=principal,
        deadline_unix_ms=deadline,
        payload=payload,
        input_count=input_count,
        input_utf8_bytes=input_bytes,
    )


def _count(value: Any, code: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise SharedGpuContractError(code)
    return value


def validate_vectors(value: Any, *, expected_count: int) -> list[list[float]]:
    if not isinstance(value, list) or len(value) != expected_count:
        raise SharedGpuContractError("vector_count_invalid")
    dimension: int | None = None
    output: list[list[float]] = []
    for row in value:
        if not isinstance(row, list) or not 1 <= len(row) <= MAX_VECTOR_DIMENSION:
            raise SharedGpuContractError("vector_shape_invalid")
        if dimension is None:
            dimension = len(row)
        elif len(row) != dimension:
            raise SharedGpuContractError("vector_shape_invalid")
        converted: list[float] = []
        for item in row:
            if isinstance(item, bool) or not isinstance(item, (int, float)):
                raise SharedGpuContractError("vector_value_invalid")
            number = float(item)
            if not math.isfinite(number):
                raise SharedGpuContractError("vector_value_invalid")
            converted.append(number)
        output.append(converted)
    return output


def validate_scores(value: Any, *, expected_count: int) -> list[float]:
    if not isinstance(value, list) or len(value) != expected_count:
        raise SharedGpuContractError("score_count_invalid")
    output: list[float] = []
    for item in value:
        if isinstance(item, bool) or not isinstance(item, (int, float)):
            raise SharedGpuContractError("score_value_invalid")
        number = float(item)
        if not math.isfinite(number):
            raise SharedGpuContractError("score_value_invalid")
        output.append(number)
    return output


def receipt_digest(receipt: Mapping[str, Any]) -> str:
    return "sha256:" + hashlib.sha256(canonical_json_bytes(receipt)).hexdigest()


def make_receipt(
    *,
    request: ValidatedGpuRequest,
    status: str,
    model: str | None,
    revision: str | None,
    production_backend: bool,
    output_count: int,
    output_shape: list[int],
    duration_ms: int,
    error_code: str | None,
) -> dict[str, Any]:
    return {
        "schema_version": RECEIPT_SCHEMA,
        "request_id": request.request_id,
        "operation": request.operation,
        "status": status,
        "model": model,
        "revision": revision,
        "production_backend": production_backend,
        "input_count": request.input_count,
        "input_utf8_bytes": request.input_utf8_bytes,
        "output_count": output_count,
        "output_shape": output_shape,
        "external_persistence": "attested_none",
        "raw_content_persisted_bytes": 0,
        "duration_ms": max(0, int(duration_ms)),
        "error_code": error_code,
    }


def make_response(
    *,
    request: ValidatedGpuRequest,
    status: str,
    output: Mapping[str, Any] | None,
    receipt: Mapping[str, Any],
    error_code: str | None = None,
    retryable: bool = False,
) -> dict[str, Any]:
    return {
        "schema_version": RESPONSE_SCHEMA,
        "request_id": request.request_id,
        "operation": request.operation,
        "status": status,
        "output": dict(output) if output is not None else None,
        "error": (
            {"code": error_code, "retryable": retryable}
            if error_code is not None
            else None
        ),
        "receipt": dict(receipt),
        "receipt_digest": receipt_digest(receipt),
    }


def validate_response(
    raw: Any,
    *,
    request: ValidatedGpuRequest,
) -> dict[str, Any]:
    if not isinstance(raw, Mapping) or set(raw) != _RESPONSE_FIELDS:
        raise SharedGpuContractError("response_fields_invalid")
    if (
        raw.get("schema_version") != RESPONSE_SCHEMA
        or raw.get("request_id") != request.request_id
        or raw.get("operation") != request.operation
        or raw.get("status") not in {"completed", "error"}
    ):
        raise SharedGpuContractError("response_identity_invalid")
    receipt = raw.get("receipt")
    if not isinstance(receipt, Mapping) or set(receipt) != _RECEIPT_FIELDS:
        raise SharedGpuContractError("receipt_fields_invalid")
    if (
        receipt.get("schema_version") != RECEIPT_SCHEMA
        or receipt.get("request_id") != request.request_id
        or receipt.get("operation") != request.operation
        or receipt.get("status") != raw.get("status")
        or receipt.get("input_count") != request.input_count
        or receipt.get("input_utf8_bytes") != request.input_utf8_bytes
        or receipt.get("external_persistence") != "attested_none"
        or receipt.get("raw_content_persisted_bytes") != 0
        or not isinstance(receipt.get("production_backend"), bool)
        or receipt_digest(receipt) != raw.get("receipt_digest")
    ):
        raise SharedGpuContractError("receipt_identity_invalid")
    _count(receipt.get("output_count"), "receipt_output_count_invalid")
    _count(receipt.get("duration_ms"), "receipt_duration_invalid")
    shape = receipt.get("output_shape")
    if (
        not isinstance(shape, list)
        or len(shape) > 2
        or any(isinstance(item, bool) or not isinstance(item, int) or item < 0 for item in shape)
    ):
        raise SharedGpuContractError("receipt_output_shape_invalid")
    for field in ("model", "revision", "error_code"):
        value = receipt.get(field)
        if value is not None and (not isinstance(value, str) or not value or len(value) > 256):
            raise SharedGpuContractError("receipt_text_invalid")
    status = raw.get("status")
    error = raw.get("error")
    output = raw.get("output")
    if status == "error":
        if output is not None or not isinstance(error, Mapping) or set(error) != _ERROR_FIELDS:
            raise SharedGpuContractError("error_response_invalid")
        if error.get("code") != receipt.get("error_code") or not isinstance(
            error.get("retryable"), bool
        ):
            raise SharedGpuContractError("error_response_invalid")
        return dict(raw)
    if error is not None or not isinstance(output, Mapping) or receipt.get("error_code") is not None:
        raise SharedGpuContractError("completed_response_invalid")
    operation = request.operation
    if operation in {"embed_query", "embed_corpus"}:
        if set(output) != {"vectors"}:
            raise SharedGpuContractError("embedding_output_invalid")
        vectors = validate_vectors(output.get("vectors"), expected_count=request.input_count)
        expected_shape = [len(vectors), len(vectors[0])]
        if receipt.get("output_count") != len(vectors) or shape != expected_shape:
            raise SharedGpuContractError("embedding_receipt_shape_mismatch")
    elif operation == "rerank":
        if set(output) != {"scores"}:
            raise SharedGpuContractError("rerank_output_invalid")
        scores = validate_scores(output.get("scores"), expected_count=request.input_count)
        if receipt.get("output_count") != len(scores) or shape != [len(scores)]:
            raise SharedGpuContractError("rerank_receipt_shape_mismatch")
    elif operation in {"health", "ready", "cancel"}:
        if receipt.get("output_count") != 1 or shape != [1]:
            raise SharedGpuContractError("control_receipt_shape_mismatch")
    return dict(raw)
