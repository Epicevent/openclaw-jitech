"""Dense index lifecycle for a slot's writable Workspace.

The corpus remains the live read-only ``kw/package`` mount.  The index is a
disposable Workspace artifact: an indexer may build and atomically replace the
current pointer without turning that pointer into corpus authorization.
"""

from __future__ import annotations

import stat
from pathlib import Path
from typing import Any, Sequence

from .dense_pipeline import SharedGpuDensePipeline
from .dense_release import (
    D_PIPELINE_FINGERPRINT,
    _file_digest,
    _load_pointer,
    activate_dense_release,
    build_dense_release,
)
from .live_kakao import LiveKakaoPackageSource
from .manifest import load_and_verify_manifest
from .operation import ReceiptWriter
from .shared_gpu_transport import GpuInferenceClient
from .slot_api import SlotSearchApplication, SlotSearchExchange
from .slot_mount import SlotMountError


class WorkspaceDenseError(ValueError):
    """The current Workspace index cannot serve the mounted corpus."""


def _real_directory(path: Path, code: str) -> Path:
    supplied = Path(path)
    if not supplied.is_absolute():
        raise WorkspaceDenseError(code)
    try:
        info = supplied.lstat()
        resolved = supplied.resolve(strict=True)
    except OSError as exc:
        raise WorkspaceDenseError(code) from exc
    if (
        stat.S_ISLNK(info.st_mode)
        or not stat.S_ISDIR(info.st_mode)
        or resolved != supplied.absolute()
    ):
        raise WorkspaceDenseError(code)
    return resolved


class WorkspaceDenseScope:
    """Current index files in Workspace plus the live read-only corpus scope."""

    readonly_required = True

    def __init__(self, source: LiveKakaoPackageSource, slot_root: Path):
        if not isinstance(source, LiveKakaoPackageSource):
            raise WorkspaceDenseError("source_invalid")
        self.source = source
        self.mount_root = source.package_root
        self.slot_root = _real_directory(slot_root, "workspace_index_root_invalid")
        pointer = _load_pointer(self.slot_root / "current.json")
        if pointer is None:
            raise WorkspaceDenseError("workspace_index_not_built")
        release_id = str(pointer["current_release_id"])
        release_root = _real_directory(
            self.slot_root / "releases" / release_id,
            "workspace_release_invalid",
        )
        manifest_path = release_root / "index-manifest.json"
        if _file_digest(manifest_path)[0] != pointer["current_manifest_sha256"]:
            raise WorkspaceDenseError("workspace_pointer_manifest_mismatch")
        manifest = load_and_verify_manifest(manifest_path, release_root)
        if (
            manifest.release_id != release_id
            or manifest.digest != pointer["current_manifest_sha256"]
        ):
            raise WorkspaceDenseError("workspace_release_identity_mismatch")
        self.index_root = release_root
        self.manifest_path = manifest_path
        self.manifest = manifest
        self.assert_current()

    @property
    def available_rooms(self) -> tuple[str, ...]:
        return tuple(sorted(set(self.manifest.rooms) & set(self.source.rooms)))

    def select_rooms(self, requested: Sequence[str] | None = None) -> list[str]:
        available = set(self.available_rooms)
        if requested is None:
            return sorted(available)
        if isinstance(requested, (str, bytes)) or not requested:
            raise SlotMountError("requested rooms are invalid")
        rooms = [str(room) for room in requested]
        if (
            any(not room or room != room.strip() for room in rooms)
            or len(rooms) != len(set(rooms))
            or set(rooms) - available
        ):
            raise SlotMountError("requested room is outside the live corpus")
        return rooms

    def assert_current(self) -> None:
        self.source.assert_available()
        _real_directory(self.index_root, "workspace_release_unavailable")


class WorkspaceDenseRuntime:
    def __init__(self, application: SlotSearchApplication):
        self.application = application
        self.scope = application.scope
        self.pipeline = application.pipeline

    def search_exchange(self, request: Any) -> SlotSearchExchange:
        return self.application.search_exchange(request)

    def close(self) -> None:
        self.pipeline.close()


def open_workspace_dense_runtime(
    *,
    package_root: Path,
    slot_root: Path,
    gpu: GpuInferenceClient,
    receipt_writer: ReceiptWriter,
    candidate_pool: int = 30,
    max_concurrent: int = 1,
    allow_nonproduction_release: bool = False,
) -> WorkspaceDenseRuntime:
    source = LiveKakaoPackageSource(package_root)
    try:
        scope = WorkspaceDenseScope(source, slot_root)
        pipeline = SharedGpuDensePipeline(
            scope,
            gpu,
            pool=candidate_pool,
            source=source,
            allow_nonproduction_release=allow_nonproduction_release,
        )
        application = SlotSearchApplication(
            pipeline=pipeline,
            scope=scope,
            pipeline_fingerprint=D_PIPELINE_FINGERPRINT,
            receipt_writer=receipt_writer,
            max_concurrent=max_concurrent,
        )
        return WorkspaceDenseRuntime(application)
    except Exception:
        source.close()
        raise


def rebuild_workspace_dense_index(
    *,
    package_root: Path,
    workspace_root: Path,
    slot_namespace: str,
    gpu: GpuInferenceClient,
    allow_nonproduction: bool = False,
) -> dict[str, Any]:
    """Build from the current package snapshot, then replace the local pointer."""

    source = LiveKakaoPackageSource(package_root)
    try:
        inventory = build_dense_release(
            source=source,
            gpu=gpu,
            output_root=workspace_root,
            slot_namespace=slot_namespace,
            allow_nonproduction=allow_nonproduction,
        )
    finally:
        source.close()
    slot_root = Path(workspace_root) / slot_namespace
    previous = _load_pointer(slot_root / "current.json")
    activation = activate_dense_release(
        slot_root=slot_root,
        release_id=inventory["release_id"],
        manifest_sha256=inventory["manifest_sha256"],
        expected_previous_release_id=(
            str(previous["current_release_id"]) if previous is not None else None
        ),
    )
    return {"build": inventory, "activation": activation}


__all__ = [
    "WorkspaceDenseError",
    "WorkspaceDenseRuntime",
    "WorkspaceDenseScope",
    "open_workspace_dense_runtime",
    "rebuild_workspace_dense_index",
]
