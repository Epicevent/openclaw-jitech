"""Read-only access to an immutable conversation index release."""

from __future__ import annotations

import hashlib
import sqlite3
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

import numpy as np


@dataclass(frozen=True)
class Unit:
    room: str
    level: str
    uid: int
    text: str
    mids: frozenset[str]
    t_start: int | None = None
    t_end: int | None = None


class RoomIndex:
    def __init__(
        self,
        room: str,
        cid: str,
        index_dir: Path,
        cache_dir: Path,
        cache_namespace: str,
    ):
        self.room = room
        self.cid = cid
        self.index_dir = Path(index_dir)
        self.cache_dir = Path(cache_dir)
        self.cache_namespace = hashlib.sha256(cache_namespace.encode("utf-8")).hexdigest()[:16]
        self._units: dict[str, list[Unit]] = {}
        self._embeddings: dict[str, np.ndarray] = {}
        self._parent: dict[int, int] | None = None

    def _db(self) -> sqlite3.Connection:
        path = (self.index_dir / f"room_{self.cid}.meta.sqlite").resolve()
        return sqlite3.connect(f"file:{path.as_posix()}?mode=ro&immutable=1", uri=True)

    def _load_segments(self) -> None:
        with self._db() as connection:
            rows = {
                int(row[0]): (row[1] or "", row[2], row[3])
                for row in connection.execute("SELECT seg_id, text, t_start, t_end FROM segments")
            }
            mids: dict[int, set[str]] = defaultdict(set)
            parent: dict[int, int] = {}
            for turn_id, segment_id, mid in connection.execute(
                "SELECT t.turn_id, t.seg_id, tm.mid FROM turns t "
                "JOIN turn_mids tm ON tm.turn_id = t.turn_id"
            ):
                mids[int(segment_id)].add(str(mid))
                parent[int(turn_id)] = int(segment_id)
        units = [
            Unit(
                self.room,
                "segment",
                segment_id,
                rows[segment_id][0],
                frozenset(mids.get(segment_id, ())),
                rows[segment_id][1],
                rows[segment_id][2],
            )
            for segment_id in sorted(rows)
        ]
        embeddings = np.load(
            self.index_dir / f"room_{self.cid}.npy", mmap_mode="r", allow_pickle=False
        )
        if embeddings.ndim != 2 or embeddings.shape[0] != len(units):
            raise ValueError(f"index row count mismatch for corpus {self.room}")
        self._parent = parent
        self._units["segment"] = units
        self._embeddings["segment"] = embeddings

    def _load_turns(self, embedder) -> None:
        with self._db() as connection:
            rows = {
                int(row[0]): (row[1] or "", row[2])
                for row in connection.execute("SELECT turn_id, text, t FROM turns")
            }
            mids: dict[int, set[str]] = defaultdict(set)
            for turn_id, mid in connection.execute("SELECT turn_id, mid FROM turn_mids"):
                mids[int(turn_id)].add(str(mid))
        ids = sorted(rows)
        self._units["turn"] = [
            Unit(
                self.room,
                "turn",
                turn_id,
                rows[turn_id][0],
                frozenset(mids.get(turn_id, ())),
                rows[turn_id][1],
                rows[turn_id][1],
            )
            for turn_id in ids
        ]
        self._embeddings["turn"] = self._turn_embeddings(ids, rows, embedder)

    def _turn_embeddings(self, ids, rows, embedder) -> np.ndarray:
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        cache = self.cache_dir / f"room_{self.cid}_turns_{self.cache_namespace}.npy"
        if cache.is_file():
            cached = np.load(cache, mmap_mode="r", allow_pickle=False)
            if cached.ndim == 2 and cached.shape[0] == len(ids):
                return cached
        embeddings = embedder.encode([rows[turn_id][0] for turn_id in ids]).astype(np.float32)
        temporary = cache.with_suffix(".npy.tmp")
        with temporary.open("wb") as handle:
            np.save(handle, embeddings, allow_pickle=False)
        temporary.replace(cache)
        return np.load(cache, mmap_mode="r", allow_pickle=False)

    def units(self, level: str, embedder=None) -> list[Unit]:
        self._ensure(level, embedder)
        return self._units[level]

    def embeddings(self, level: str, embedder=None) -> np.ndarray:
        self._ensure(level, embedder)
        return self._embeddings[level]

    def _ensure(self, level: str, embedder) -> None:
        if level in self._units:
            return
        if level == "segment":
            self._load_segments()
            return
        if level == "turn":
            if self._parent is None:
                self._load_segments()
            if embedder is None:
                raise ValueError("turn-level loading requires an embedder")
            self._load_turns(embedder)
            return
        raise ValueError(f"unknown retrieval level: {level}")

    def turns_of_segment(self, segment_id: int, embedder=None) -> list[Unit]:
        self._ensure("turn", embedder)
        assert self._parent is not None
        return [unit for unit in self._units["turn"] if self._parent.get(unit.uid) == segment_id]


class Corpus:
    def __init__(
        self,
        index_dir: Path,
        cache_dir: Path,
        rooms: dict[str, str],
        cache_namespace: str,
    ):
        self.index_dir = Path(index_dir)
        self.cache_dir = Path(cache_dir)
        self.rooms = dict(rooms)
        self.cache_namespace = cache_namespace
        self._by_room: dict[str, RoomIndex] = {}

    def room(self, room: str) -> RoomIndex:
        if room not in self.rooms:
            raise KeyError(room)
        if room not in self._by_room:
            self._by_room[room] = RoomIndex(
                room,
                self.rooms[room],
                self.index_dir,
                self.cache_dir,
                self.cache_namespace,
            )
        return self._by_room[room]

    def room_keys(self) -> list[str]:
        return list(self.rooms)
