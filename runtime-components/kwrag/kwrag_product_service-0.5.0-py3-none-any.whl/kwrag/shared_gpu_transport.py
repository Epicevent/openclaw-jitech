"""Host-local UDS adapter and content-free caller-side receipt journal."""

from __future__ import annotations

import os
import re
import socket
import socketserver
import stat
import struct
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Protocol, Sequence
from uuid import uuid4

from .jsonutil import canonical_json_bytes, loads_canonical_json_bytes
from .operation import ReceiptWriter
from .shared_gpu_contract import (
    MAX_FRAME_BYTES,
    REQUEST_SCHEMA,
    SharedGpuContractError,
    ValidatedGpuRequest,
    validate_request,
    validate_response,
)
from .shared_gpu_core import CallerIdentity, SharedGpuCore


class SharedGpuTransportError(ValueError):
    def __init__(self, code: str, *, retryable: bool = False):
        super().__init__(code)
        self.code = code
        self.retryable = retryable


@dataclass(frozen=True)
class SlotPeerGrant:
    slot: str
    uid: int
    gid: int

    def __post_init__(self) -> None:
        if (
            not isinstance(self.slot, str)
            or re.fullmatch(r"[a-z][a-z0-9_-]{0,63}", self.slot) is None
            or isinstance(self.uid, bool)
            or not isinstance(self.uid, int)
            or self.uid < 0
            or isinstance(self.gid, bool)
            or not isinstance(self.gid, int)
            or self.gid < 0
        ):
            raise ValueError("slot peer grant is invalid")


class PeerAuthorizer:
    """Bind each host peer credential tuple to exactly one slot."""

    def __init__(self, grants: Sequence[SlotPeerGrant]):
        if not grants:
            raise ValueError("at least one slot peer grant is required")
        by_peer: dict[tuple[int, int], SlotPeerGrant] = {}
        slots: set[str] = set()
        for grant in grants:
            key = (grant.uid, grant.gid)
            if key in by_peer or grant.slot in slots:
                raise ValueError("slot peer grants must be one-to-one")
            by_peer[key] = grant
            slots.add(grant.slot)
        self._by_peer = by_peer

    def authorize(self, *, uid: int, gid: int, requested_slot: Any) -> CallerIdentity:
        grant = self._by_peer.get((uid, gid))
        if grant is None or requested_slot != grant.slot:
            raise SharedGpuTransportError("peer_not_authorized")
        return CallerIdentity(
            slot=grant.slot,
            principal=f"uid:{uid}",
            peer_uid=uid,
            peer_gid=gid,
        )


@dataclass(frozen=True)
class GpuCallResult:
    operation: str
    output: Mapping[str, Any]
    service_receipt_digest: str
    journal_receipt_digest: str | None
    wire_bytes_sent: int
    input_count: int
    input_utf8_bytes: int
    model: str | None
    revision: str | None
    production_backend: bool


class GpuInferenceClient(Protocol):
    def embed_query(self, text: str) -> GpuCallResult: ...

    def embed_corpus(self, texts: Sequence[str]) -> GpuCallResult: ...

    def rerank(self, query: str, passages: Sequence[str]) -> GpuCallResult: ...

    def commit_operation(self, calls: Sequence[GpuCallResult]) -> str | None: ...


class ContentFreeGpuJournal:
    """Persist execution identities and counts, never query/passage/vector bytes."""

    def __init__(self, path: Path):
        path = Path(path)
        if not path.is_absolute():
            raise ValueError("GPU receipt journal path must be absolute")
        self.writer = ReceiptWriter(path)

    @property
    def path(self) -> Path:
        return self.writer.path

    def write_call(
        self,
        *,
        response: Mapping[str, Any],
        wire_bytes_sent: int,
    ) -> str | None:
        receipt = response["receipt"]
        entry = {
            "schema_version": "kwrag-shared-gpu-call-journal-v1",
            "service_receipt_digest": response["receipt_digest"],
            "request_id": receipt["request_id"],
            "operation": receipt["operation"],
            "status": receipt["status"],
            "model": receipt["model"],
            "revision": receipt["revision"],
            "production_backend": receipt["production_backend"],
            "input_count": receipt["input_count"],
            "input_utf8_bytes": receipt["input_utf8_bytes"],
            "output_count": receipt["output_count"],
            "output_shape": receipt["output_shape"],
            "wire_bytes_sent": wire_bytes_sent,
            "external_persistence": receipt["external_persistence"],
            "raw_content_persisted_bytes": receipt["raw_content_persisted_bytes"],
            "duration_ms": receipt["duration_ms"],
            "error_code": receipt["error_code"],
            "raw_content_present": False,
        }
        result = self.writer.write(entry)
        return result.digest if result.status == "written" else None

    def commit_operation(self, calls: Sequence[GpuCallResult]) -> str | None:
        if not calls:
            raise SharedGpuTransportError("gpu_operation_calls_missing")
        entry = {
            "schema_version": "kwrag-shared-gpu-operation-journal-v1",
            "status": "completed",
            "call_count": len(calls),
            "operations": [call.operation for call in calls],
            "service_receipt_digests": [call.service_receipt_digest for call in calls],
            "call_journal_digests": [
                call.journal_receipt_digest
                for call in calls
                if call.journal_receipt_digest is not None
            ],
            "input_count": sum(call.input_count for call in calls),
            "input_utf8_bytes": sum(call.input_utf8_bytes for call in calls),
            "wire_bytes_sent": sum(call.wire_bytes_sent for call in calls),
            "external_persistence": "attested_none",
            "raw_content_persisted_bytes": 0,
            "raw_content_present": False,
        }
        result = self.writer.write(entry)
        return result.digest if result.status == "written" else None


def _request(
    *,
    operation: str,
    payload: Mapping[str, Any],
    slot: str,
    principal: str,
    deadline_ms: int,
    request_id: str | None = None,
) -> tuple[dict[str, Any], ValidatedGpuRequest, bytes]:
    now = int(time.time() * 1_000)
    value = {
        "schema_version": REQUEST_SCHEMA,
        "request_id": request_id or f"gpu-{uuid4()}",
        "operation": operation,
        "slot": slot,
        "principal": principal,
        "deadline_unix_ms": now + deadline_ms,
        "payload": dict(payload),
    }
    validated = validate_request(value, now_unix_ms=now)
    encoded = canonical_json_bytes(value)
    if len(encoded) > MAX_FRAME_BYTES:
        raise SharedGpuTransportError("request_frame_too_large")
    return value, validated, encoded


class _ClientBase:
    def __init__(
        self,
        *,
        slot: str,
        principal: str,
        journal: ContentFreeGpuJournal,
        deadline_ms: int = 30_000,
    ):
        if not 1 <= deadline_ms <= 60_000:
            raise ValueError("GPU client deadline is invalid")
        self.slot = slot
        self.principal = principal
        self.journal = journal
        self.deadline_ms = deadline_ms

    def _dispatch(self, raw: Mapping[str, Any], encoded: bytes) -> Mapping[str, Any]:
        raise NotImplementedError

    def _call(self, operation: str, payload: Mapping[str, Any]) -> GpuCallResult:
        raw, validated, encoded = _request(
            operation=operation,
            payload=payload,
            slot=self.slot,
            principal=self.principal,
            deadline_ms=self.deadline_ms,
        )
        response = validate_response(self._dispatch(raw, encoded), request=validated)
        wire_bytes_sent = 4 + len(encoded)
        journal_digest = self.journal.write_call(
            response=response,
            wire_bytes_sent=wire_bytes_sent,
        )
        if response["status"] == "error":
            error = response["error"]
            raise SharedGpuTransportError(
                str(error["code"]), retryable=bool(error["retryable"])
            )
        return GpuCallResult(
            operation=operation,
            output=dict(response["output"]),
            service_receipt_digest=str(response["receipt_digest"]),
            journal_receipt_digest=journal_digest,
            wire_bytes_sent=wire_bytes_sent,
            input_count=validated.input_count,
            input_utf8_bytes=validated.input_utf8_bytes,
            model=response["receipt"]["model"],
            revision=response["receipt"]["revision"],
            production_backend=bool(response["receipt"]["production_backend"]),
        )

    def embed_query(self, text: str) -> GpuCallResult:
        return self._call("embed_query", {"text": text})

    def embed_corpus(self, texts: Sequence[str]) -> GpuCallResult:
        return self._call("embed_corpus", {"texts": list(texts)})

    def rerank(self, query: str, passages: Sequence[str]) -> GpuCallResult:
        return self._call("rerank", {"query": query, "passages": list(passages)})

    def commit_operation(self, calls: Sequence[GpuCallResult]) -> str | None:
        return self.journal.commit_operation(calls)


class InProcessSharedGpuClient(_ClientBase):
    """Test/build adapter; explicitly not a production transport."""

    def __init__(
        self,
        *,
        core: SharedGpuCore,
        caller: CallerIdentity,
        journal: ContentFreeGpuJournal,
        deadline_ms: int = 30_000,
    ):
        super().__init__(
            slot=caller.slot,
            principal=caller.principal,
            journal=journal,
            deadline_ms=deadline_ms,
        )
        self.core = core
        self.caller = caller

    def _dispatch(self, raw: Mapping[str, Any], encoded: bytes) -> Mapping[str, Any]:
        del encoded
        return self.core.execute(raw, caller=self.caller)


def _read_exact(stream: socket.socket, size: int) -> bytes:
    chunks: list[bytes] = []
    remaining = size
    while remaining:
        block = stream.recv(remaining)
        if not block:
            raise SharedGpuTransportError("connection_closed", retryable=True)
        chunks.append(block)
        remaining -= len(block)
    return b"".join(chunks)


def _read_frame(stream: socket.socket) -> bytes:
    header = _read_exact(stream, 4)
    size = struct.unpack("!I", header)[0]
    if not 1 <= size <= MAX_FRAME_BYTES:
        raise SharedGpuTransportError("frame_size_invalid")
    return _read_exact(stream, size)


def _write_frame(stream: socket.socket, payload: bytes) -> None:
    if not 1 <= len(payload) <= MAX_FRAME_BYTES:
        raise SharedGpuTransportError("frame_size_invalid")
    stream.sendall(struct.pack("!I", len(payload)) + payload)


class UnixSharedGpuClient(_ClientBase):
    def __init__(
        self,
        *,
        socket_path: Path,
        slot: str,
        principal: str,
        journal: ContentFreeGpuJournal,
        deadline_ms: int = 30_000,
    ):
        path = Path(socket_path)
        if not path.is_absolute():
            raise ValueError("shared GPU socket path must be absolute")
        super().__init__(
            slot=slot,
            principal=principal,
            journal=journal,
            deadline_ms=deadline_ms,
        )
        self.socket_path = path

    def _dispatch(self, raw: Mapping[str, Any], encoded: bytes) -> Mapping[str, Any]:
        del raw
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as stream:
                stream.settimeout(self.deadline_ms / 1_000)
                stream.connect(str(self.socket_path))
                _write_frame(stream, encoded)
                response_bytes = _read_frame(stream)
        except (OSError, TimeoutError) as exc:
            raise SharedGpuTransportError(
                "shared_gpu_transport_unavailable", retryable=True
            ) from exc
        try:
            response = loads_canonical_json_bytes(response_bytes)
        except (UnicodeDecodeError, ValueError) as exc:
            raise SharedGpuTransportError("response_not_canonical") from exc
        if not isinstance(response, Mapping):
            raise SharedGpuTransportError("response_not_object")
        return response


if hasattr(socketserver, "UnixStreamServer"):

    class _ThreadingUnixServer(
        socketserver.ThreadingMixIn, socketserver.UnixStreamServer
    ):
        daemon_threads = False
        block_on_close = True
        allow_reuse_address = False

else:

    class _ThreadingUnixServer:  # pragma: no cover - exercised by POSIX runtime
        """Import-only stand-in on platforms without Unix-domain servers."""

        def __init__(self, *_args: object, **_kwargs: object) -> None:
            raise SharedGpuTransportError("unix_socket_server_unavailable")


class _RequestHandler(socketserver.BaseRequestHandler):
    def handle(self) -> None:
        server = self.server
        assert isinstance(server, _BoundUnixServer)
        stream = self.request
        assert isinstance(stream, socket.socket)
        stream.settimeout(server.request_timeout_seconds)
        try:
            payload = _read_frame(stream)
            raw = loads_canonical_json_bytes(payload)
            if not isinstance(raw, Mapping):
                return
            uid, gid = server.peer_credentials(stream)
            caller = server.authorizer.authorize(
                uid=uid,
                gid=gid,
                requested_slot=raw.get("slot"),
            )
            response = server.core.execute(raw, caller=caller)
            encoded = canonical_json_bytes(response)
            _write_frame(stream, encoded)
        except (
            OSError,
            TimeoutError,
            UnicodeDecodeError,
            ValueError,
            SharedGpuContractError,
            SharedGpuTransportError,
        ):
            # Authentication/protocol errors deliberately receive no detail.
            return


class _BoundUnixServer(_ThreadingUnixServer):
    def __init__(
        self,
        path: str,
        *,
        core: SharedGpuCore,
        authorizer: PeerAuthorizer,
        request_timeout_seconds: float,
    ):
        self.core = core
        self.authorizer = authorizer
        self.request_timeout_seconds = request_timeout_seconds
        super().__init__(path, _RequestHandler, bind_and_activate=True)

    @staticmethod
    def peer_credentials(stream: socket.socket) -> tuple[int, int]:
        if not hasattr(socket, "SO_PEERCRED"):
            raise SharedGpuTransportError("peer_credentials_unavailable")
        raw = stream.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12)
        _pid, uid, gid = struct.unpack("3i", raw)
        return uid, gid


class SharedGpuUnixServer:
    """One host-local endpoint.  Run separate endpoints if peer IDs overlap."""

    def __init__(
        self,
        *,
        socket_path: Path,
        socket_mode: int,
        core: SharedGpuCore,
        authorizer: PeerAuthorizer,
        request_timeout_seconds: float = 65.0,
    ):
        if os.name != "posix" or not hasattr(socketserver, "UnixStreamServer"):
            raise SharedGpuTransportError("unix_socket_server_unavailable")
        path = Path(socket_path)
        if not path.is_absolute() or path.exists() or path.is_symlink():
            raise SharedGpuTransportError("socket_path_invalid_or_occupied")
        parent = path.parent
        try:
            metadata = parent.lstat()
            resolved_parent = parent.resolve(strict=True)
        except OSError as exc:
            raise SharedGpuTransportError("socket_parent_unavailable") from exc
        if (
            parent.is_symlink()
            or not stat.S_ISDIR(metadata.st_mode)
            or resolved_parent != parent.absolute()
            or metadata.st_uid != os.geteuid()
            or stat.S_IMODE(metadata.st_mode) & 0o002
        ):
            raise SharedGpuTransportError("socket_parent_trust_invalid")
        if socket_mode not in {0o600, 0o660}:
            raise SharedGpuTransportError("socket_mode_invalid")
        if not 1 <= request_timeout_seconds <= 120:
            raise SharedGpuTransportError("socket_timeout_invalid")
        self.socket_path = path
        self.socket_mode = socket_mode
        self._server = _BoundUnixServer(
            str(path),
            core=core,
            authorizer=authorizer,
            request_timeout_seconds=request_timeout_seconds,
        )
        os.chmod(path, socket_mode)
        identity = path.lstat()
        if not stat.S_ISSOCK(identity.st_mode):
            self._server.server_close()
            raise SharedGpuTransportError("bound_path_not_socket")
        self._identity = (identity.st_dev, identity.st_ino)
        self._thread: threading.Thread | None = None

    def serve_in_thread(self) -> threading.Thread:
        if self._thread is not None:
            raise SharedGpuTransportError("server_already_started")
        thread = threading.Thread(
            target=self._server.serve_forever,
            name="kwrag-shared-gpu-uds",
            daemon=False,
        )
        thread.start()
        self._thread = thread
        return thread

    def serve_forever(self) -> None:
        self._server.serve_forever()

    def shutdown(self) -> None:
        self._server.shutdown()
        self._server.server_close()
        try:
            metadata = self.socket_path.lstat()
            if (
                stat.S_ISSOCK(metadata.st_mode)
                and (metadata.st_dev, metadata.st_ino) == self._identity
            ):
                self.socket_path.unlink()
        except FileNotFoundError:
            pass
        if self._thread is not None:
            self._thread.join(timeout=10)
