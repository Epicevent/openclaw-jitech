"""Canonical, slot-local access to crawler-published SQLite generations.

The crawler database remains the semantic source.  A generation contains the
existing ``messages.sqlite``, ``membership.json`` and ``profile.json`` plus a
content-free manifest.  Two activation records form a bounded publication
journal; readers never combine files from different generations.
"""

from __future__ import annotations

import hashlib
import math
import os
import re
import sqlite3
import stat
import threading
import unicodedata
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Sequence

from .dense_source import SourceMessage
from .jsonutil import (
    canonical_json_bytes,
    is_sha256,
    loads_canonical_json_bytes,
    loads_strict_json,
)


ACTIVATION_RELATIVES = (
    "kwrag/source/activation-a.json",
    "kwrag/source/activation-b.json",
)
GENERATION_ROOT_RELATIVE = "kwrag/source/generations"
MAX_ACTIVATION_BYTES = 16 * 1024
MAX_MANIFEST_BYTES = 256 * 1024
MAX_MEMBERSHIP_BYTES = 4 * 1024 * 1024
MAX_PROFILE_BYTES = 16 * 1024 * 1024
MAX_DATABASE_BYTES = 4 * 1024 * 1024 * 1024
MAX_QUERY_CHARS = 4_000
MAX_ROOMS = 4_096
MAX_RESULTS = 100

_GENERATION_RE = re.compile(r"g-[0-9a-f]{64}\Z")
_FTS5_RE = re.compile(r"\busing\s+fts5\s*\(", re.IGNORECASE)
_TOKENIZE_RE = re.compile(
    r"\btokenize\s*=\s*(?:'([^']*)'|\"([^\"]*)\"|([^\s,)]+))",
    re.IGNORECASE,
)
_ACTIVATION_FIELDS = frozenset(
    {
        "schema_version",
        "sequence",
        "generation_id",
        "manifest_relative",
        "manifest_sha256",
        "previous_generation_id",
    }
)
_MANIFEST_FIELDS = frozenset(
    {
        "schema_version",
        "generation_id",
        "files",
        "membership_conversation_set_sha256",
        "room_count",
        "message_count",
        "messages_fts_count",
        "fts_tokenizers",
    }
)
_FILE_FIELDS = frozenset({"name", "sha256", "bytes"})
_REQUIRED_DATABASE_COLUMNS = frozenset(
    {
        "conversation_id",
        "message_id",
        "user_id",
        "user_name",
        "sent_time",
        "plain_text",
    }
)


class CrawlerSourceError(ValueError):
    """A crawler generation is unavailable or violates the source contract."""

    def __init__(self, code: str):
        super().__init__(code)
        self.code = code


@dataclass(frozen=True)
class FileIdentity:
    device: int
    inode: int
    mode: int
    links: int
    size: int
    mtime_ns: int


@dataclass(frozen=True)
class StableFile:
    path: Path
    digest: str
    identity: FileIdentity
    payload: bytes | None


@dataclass(frozen=True)
class ActivationRecord:
    path: Path
    sequence: int
    generation_id: str
    manifest_relative: str
    manifest_sha256: str
    previous_generation_id: str | None
    digest: str
    identity: FileIdentity


@dataclass(frozen=True)
class CrawlerGeneration:
    generation_id: str
    sequence: int
    manifest_digest: str
    manifest_path: Path
    membership_path: Path
    database_path: Path
    profile_path: Path
    membership_digest: str
    database_digest: str
    profile_digest: str
    rooms: tuple[str, ...]
    message_count: int
    lexical_table: str
    lexical_tokenizer: str
    activation_identities: tuple[FileIdentity, ...]
    file_identities: tuple[FileIdentity, ...]


@dataclass(frozen=True)
class LexicalHit:
    room: str
    message_id: str
    user_name: str
    sent_time: int
    text: str
    score: float


def _sha256(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _identity(metadata: os.stat_result) -> FileIdentity:
    return FileIdentity(
        device=metadata.st_dev,
        inode=metadata.st_ino,
        mode=metadata.st_mode,
        links=metadata.st_nlink,
        size=metadata.st_size,
        mtime_ns=metadata.st_mtime_ns,
    )


def _stable_file(
    path: Path,
    *,
    maximum: int,
    retain_payload: bool,
) -> StableFile:
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NOFOLLOW", 0)
        | getattr(os, "O_BINARY", 0)
    )
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise CrawlerSourceError("source_file_unavailable") from exc
    digest = hashlib.sha256()
    chunks: list[bytes] | None = [] if retain_payload else None
    total = 0
    try:
        before = _identity(os.fstat(descriptor))
        if (
            not stat.S_ISREG(before.mode)
            or before.links != 1
            or before.size < 1
            or before.size > maximum
        ):
            raise CrawlerSourceError("source_file_identity_invalid")
        while True:
            block = os.read(descriptor, 1024 * 1024)
            if not block:
                break
            total += len(block)
            if total > maximum:
                raise CrawlerSourceError("source_file_size_invalid")
            digest.update(block)
            if chunks is not None:
                chunks.append(block)
        after = _identity(os.fstat(descriptor))
        if before != after or total != before.size:
            raise CrawlerSourceError("source_file_changed_during_read")
    finally:
        os.close(descriptor)
    return StableFile(
        path=Path(path),
        digest="sha256:" + digest.hexdigest(),
        identity=before,
        payload=b"".join(chunks) if chunks is not None else None,
    )


def _safe_relative(value: Any, *, field: str) -> str:
    if not isinstance(value, str) or not value or len(value) > 2_048:
        raise CrawlerSourceError(f"{field}_invalid")
    path = PurePosixPath(value)
    if (
        path.is_absolute()
        or path.as_posix() != value
        or "\\" in value
        or ":" in value
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        raise CrawlerSourceError(f"{field}_invalid")
    return value


def _mount_root(path: Path, *, require_readonly: bool) -> Path:
    supplied = Path(path)
    if not supplied.is_absolute():
        raise CrawlerSourceError("mount_root_not_absolute")
    try:
        metadata = supplied.lstat()
        resolved = supplied.resolve(strict=True)
    except OSError as exc:
        raise CrawlerSourceError("mount_root_unavailable") from exc
    if (
        supplied.is_symlink()
        or not stat.S_ISDIR(metadata.st_mode)
        or resolved != supplied.absolute()
    ):
        raise CrawlerSourceError("mount_root_identity_invalid")
    if require_readonly:
        readonly_flag = getattr(os, "ST_RDONLY", None)
        if readonly_flag is None:
            raise CrawlerSourceError("readonly_state_unavailable")
        try:
            mount_flags = os.statvfs(resolved).f_flag
        except OSError as exc:
            raise CrawlerSourceError("readonly_state_unavailable") from exc
        if not mount_flags & readonly_flag:
            raise CrawlerSourceError("mount_root_not_readonly")
    return resolved


def _resolve(root: Path, relative: str, *, kind: str) -> Path:
    rel = _safe_relative(relative, field="source_relative")
    current = root
    for part in PurePosixPath(rel).parts:
        current = current / part
        try:
            metadata = current.lstat()
        except OSError as exc:
            raise CrawlerSourceError("source_path_unavailable") from exc
        if stat.S_ISLNK(metadata.st_mode):
            raise CrawlerSourceError("source_path_symlink_forbidden")
    try:
        resolved = current.resolve(strict=True)
        resolved.relative_to(root)
    except (OSError, ValueError) as exc:
        raise CrawlerSourceError("source_path_escape") from exc
    if kind == "file" and not resolved.is_file():
        raise CrawlerSourceError("source_path_not_file")
    if kind == "directory" and not resolved.is_dir():
        raise CrawlerSourceError("source_path_not_directory")
    return resolved


def _strict_json(payload: bytes, *, canonical: bool, code: str) -> Mapping[str, Any]:
    try:
        raw = (
            loads_canonical_json_bytes(payload)
            if canonical
            else loads_strict_json(payload.decode("utf-8"))
        )
    except (UnicodeDecodeError, ValueError) as exc:
        raise CrawlerSourceError(code) from exc
    if not isinstance(raw, Mapping):
        raise CrawlerSourceError(code)
    return raw


def _generation_id(value: Any, *, nullable: bool = False) -> str | None:
    if value is None and nullable:
        return None
    if not isinstance(value, str) or _GENERATION_RE.fullmatch(value) is None:
        raise CrawlerSourceError("generation_id_invalid")
    return value


def _activation(root: Path, relative: str) -> ActivationRecord | None:
    candidate = root / relative
    if not candidate.exists() and not candidate.is_symlink():
        return None
    path = _resolve(root, relative, kind="file")
    stable = _stable_file(path, maximum=MAX_ACTIVATION_BYTES, retain_payload=True)
    raw = _strict_json(
        stable.payload or b"", canonical=True, code="activation_not_canonical"
    )
    if set(raw) != _ACTIVATION_FIELDS:
        raise CrawlerSourceError("activation_fields_invalid")
    if raw.get("schema_version") != "kw-corpus-package-activation-v1":
        raise CrawlerSourceError("activation_schema_invalid")
    sequence = raw.get("sequence")
    if (
        isinstance(sequence, bool)
        or not isinstance(sequence, int)
        or not 1 <= sequence <= 2**63 - 1
    ):
        raise CrawlerSourceError("activation_sequence_invalid")
    generation_id = _generation_id(raw.get("generation_id"))
    assert isinstance(generation_id, str)
    previous = _generation_id(raw.get("previous_generation_id"), nullable=True)
    manifest_relative = _safe_relative(
        raw.get("manifest_relative"), field="activation_manifest_relative"
    )
    expected_relative = (
        f"{GENERATION_ROOT_RELATIVE}/{generation_id}/package-manifest.json"
    )
    if manifest_relative != expected_relative:
        raise CrawlerSourceError("activation_manifest_path_mismatch")
    manifest_digest = raw.get("manifest_sha256")
    if not is_sha256(manifest_digest):
        raise CrawlerSourceError("activation_manifest_digest_invalid")
    return ActivationRecord(
        path=path,
        sequence=sequence,
        generation_id=generation_id,
        manifest_relative=manifest_relative,
        manifest_sha256=manifest_digest,
        previous_generation_id=previous,
        digest=stable.digest,
        identity=stable.identity,
    )


def _select_activation(root: Path) -> tuple[ActivationRecord, tuple[FileIdentity, ...]]:
    records = [
        record
        for relative in ACTIVATION_RELATIVES
        if (record := _activation(root, relative)) is not None
    ]
    if not records:
        raise CrawlerSourceError("activation_missing")
    records.sort(key=lambda record: record.sequence)
    if len(records) == 2:
        older, current = records
        if (
            current.sequence != older.sequence + 1
            or current.previous_generation_id != older.generation_id
            or current.generation_id == older.generation_id
        ):
            raise CrawlerSourceError("activation_chain_invalid_or_stale")
    current = records[-1]
    return current, tuple(record.identity for record in records)


def _manifest_files(raw: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    entries = raw.get("files")
    if not isinstance(entries, list) or len(entries) != 3:
        raise CrawlerSourceError("manifest_files_invalid")
    output: dict[str, Mapping[str, Any]] = {}
    for entry in entries:
        if not isinstance(entry, Mapping) or set(entry) != _FILE_FIELDS:
            raise CrawlerSourceError("manifest_files_invalid")
        name = entry.get("name")
        digest = entry.get("sha256")
        size = entry.get("bytes")
        if (
            name not in {"membership.json", "messages.sqlite", "profile.json"}
            or name in output
            or not is_sha256(digest)
            or isinstance(size, bool)
            or not isinstance(size, int)
            or size < 1
        ):
            raise CrawlerSourceError("manifest_files_invalid")
        output[str(name)] = entry
    if set(output) != {"membership.json", "messages.sqlite", "profile.json"}:
        raise CrawlerSourceError("manifest_files_invalid")
    return output


def _membership_rooms(payload: bytes) -> tuple[str, ...]:
    raw = _strict_json(payload, canonical=False, code="membership_invalid")
    if raw.get("schema") != "kw-corpus-nas-user":
        raise CrawlerSourceError("membership_schema_invalid")
    room_values = raw.get("conversation_ids")
    if (
        not isinstance(room_values, list)
        or not 1 <= len(room_values) <= MAX_ROOMS
        or any(
            not isinstance(room, str)
            or not room
            or room != room.strip()
            or len(room) > 256
            for room in room_values
        )
        or len(room_values) != len(set(room_values))
    ):
        raise CrawlerSourceError("membership_rooms_invalid")
    return tuple(sorted(room_values))


def _tokenizer(sql: str | None) -> str:
    if not isinstance(sql, str) or _FTS5_RE.search(sql) is None:
        raise CrawlerSourceError("fts_schema_invalid")
    matches = list(_TOKENIZE_RE.finditer(sql))
    if len(matches) > 1:
        raise CrawlerSourceError("fts_schema_invalid")
    if not matches:
        # FTS5's documented default tokenizer is unicode61.
        return "unicode61"
    match = matches[0]
    specification = next(
        (value for value in match.groups() if value is not None), ""
    ).strip()
    tokenizer = specification.split(maxsplit=1)[0].lower() if specification else ""
    if tokenizer not in {"unicode61", "trigram"}:
        raise CrawlerSourceError("fts_tokenizer_unsupported")
    return tokenizer


def _database_contract(
    path: Path,
    *,
    rooms: tuple[str, ...],
) -> tuple[int, int, dict[str, str], sqlite3.Connection]:
    uri = path.as_uri() + "?mode=ro&immutable=1"
    try:
        connection = sqlite3.connect(uri, uri=True, check_same_thread=False)
        if connection.execute("PRAGMA integrity_check").fetchall() != [("ok",)]:
            raise CrawlerSourceError("database_integrity_invalid")
        tables = {
            str(row[0])
            for row in connection.execute(
                "SELECT name FROM sqlite_master WHERE type IN ('table','view')"
            )
        }
        if not {"messages", "messages_fts"}.issubset(tables):
            raise CrawlerSourceError("database_tables_invalid")
        columns = {
            str(row[1]) for row in connection.execute("PRAGMA table_info(messages)")
        }
        if not _REQUIRED_DATABASE_COLUMNS.issubset(columns):
            raise CrawlerSourceError("database_columns_invalid")
        database_rooms = tuple(
            sorted(
                str(row[0])
                for row in connection.execute(
                    "SELECT DISTINCT conversation_id FROM messages"
                )
            )
        )
        if database_rooms != rooms:
            raise CrawlerSourceError("membership_database_scope_mismatch")
        message_count = int(
            connection.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
        )
        tokenizers: dict[str, str] = {}
        counts: dict[str, int] = {}
        for table in ("messages_fts", "messages_fts_trigram"):
            if table not in tables:
                continue
            row = connection.execute(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (table,)
            ).fetchone()
            tokenizers[table] = _tokenizer(str(row[0]) if row else None)
            counts[table] = int(
                connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            )
            if counts[table] != message_count:
                raise CrawlerSourceError("fts_coverage_mismatch")
        if tokenizers.get("messages_fts") != "unicode61":
            raise CrawlerSourceError("compatibility_fts_tokenizer_invalid")
        if "messages_fts_trigram" in tokenizers and (
            tokenizers["messages_fts_trigram"] != "trigram"
        ):
            raise CrawlerSourceError("trigram_fts_tokenizer_invalid")
        return message_count, counts["messages_fts"], tokenizers, connection
    except CrawlerSourceError:
        try:
            connection.close()
        except (NameError, sqlite3.Error):
            pass
        raise
    except sqlite3.Error as exc:
        try:
            connection.close()
        except (NameError, sqlite3.Error):
            pass
        raise CrawlerSourceError("database_query_failed") from exc


class CanonicalCrawlerSource:
    """One reloadable, immutable crawler generation under a slot-visible root."""

    def __init__(self, mount_root: Path, *, require_readonly: bool = True):
        if not isinstance(require_readonly, bool):
            raise CrawlerSourceError("readonly_requirement_invalid")
        self.mount_root = _mount_root(
            Path(mount_root), require_readonly=require_readonly
        )
        self.require_readonly = require_readonly
        self._lock = threading.RLock()
        self._connection: sqlite3.Connection | None = None
        self._generation: CrawlerGeneration | None = None
        self.refresh(force=True)

    @property
    def generation(self) -> CrawlerGeneration:
        with self._lock:
            if self._generation is None:
                raise CrawlerSourceError("source_closed")
            return self._generation

    @property
    def rooms(self) -> tuple[str, ...]:
        return self.generation.rooms

    def close(self) -> None:
        with self._lock:
            if self._connection is not None:
                self._connection.close()
            self._connection = None
            self._generation = None

    def __enter__(self) -> "CanonicalCrawlerSource":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()

    def refresh(self, *, force: bool = False) -> bool:
        """Re-open only after a complete, self-consistent activation is visible."""

        with self._lock:
            if self.require_readonly:
                _mount_root(self.mount_root, require_readonly=True)
            activation, activation_identities = _select_activation(self.mount_root)
            if (
                not force
                and self._generation is not None
                and activation.generation_id == self._generation.generation_id
                and activation.sequence == self._generation.sequence
            ):
                self._assert_generation_current()
                return False
            loaded, connection = self._load_generation(
                activation, activation_identities
            )
            previous = self._connection
            self._connection = connection
            self._generation = loaded
            if previous is not None:
                previous.close()
            return True

    def _load_generation(
        self,
        activation: ActivationRecord,
        activation_identities: tuple[FileIdentity, ...],
    ) -> tuple[CrawlerGeneration, sqlite3.Connection]:
        manifest_path = _resolve(
            self.mount_root, activation.manifest_relative, kind="file"
        )
        manifest_file = _stable_file(
            manifest_path, maximum=MAX_MANIFEST_BYTES, retain_payload=True
        )
        if manifest_file.digest != activation.manifest_sha256:
            raise CrawlerSourceError("activation_manifest_digest_mismatch")
        raw = _strict_json(
            manifest_file.payload or b"",
            canonical=True,
            code="manifest_not_canonical",
        )
        if set(raw) != _MANIFEST_FIELDS:
            raise CrawlerSourceError("manifest_fields_invalid")
        if raw.get("schema_version") != "kw-corpus-package-manifest-v1":
            raise CrawlerSourceError("manifest_schema_invalid")
        if raw.get("generation_id") != activation.generation_id:
            raise CrawlerSourceError("manifest_generation_mismatch")
        manifest_identity = dict(raw)
        manifest_identity.pop("generation_id")
        expected_generation_id = "g-" + hashlib.sha256(
            canonical_json_bytes(manifest_identity)
        ).hexdigest()
        if activation.generation_id != expected_generation_id:
            raise CrawlerSourceError("generation_content_address_mismatch")
        files = _manifest_files(raw)
        generation_relative = (
            f"{GENERATION_ROOT_RELATIVE}/{activation.generation_id}"
        )
        limits = {
            "membership.json": MAX_MEMBERSHIP_BYTES,
            "messages.sqlite": MAX_DATABASE_BYTES,
            "profile.json": MAX_PROFILE_BYTES,
        }
        stable: dict[str, StableFile] = {}
        for name in sorted(files):
            path = _resolve(
                self.mount_root, f"{generation_relative}/{name}", kind="file"
            )
            stable[name] = _stable_file(
                path,
                maximum=limits[name],
                retain_payload=name in {"membership.json", "profile.json"},
            )
            expected = files[name]
            if (
                stable[name].digest != expected.get("sha256")
                or stable[name].identity.size != expected.get("bytes")
            ):
                raise CrawlerSourceError("generation_file_manifest_mismatch")
        rooms = _membership_rooms(stable["membership.json"].payload or b"")
        _strict_json(
            stable["profile.json"].payload or b"",
            canonical=False,
            code="profile_invalid",
        )
        room_set_digest = _sha256(canonical_json_bytes(list(rooms)))
        if (
            raw.get("membership_conversation_set_sha256") != room_set_digest
            or raw.get("room_count") != len(rooms)
        ):
            raise CrawlerSourceError("manifest_membership_summary_mismatch")
        message_count, fts_count, tokenizers, connection = _database_contract(
            stable["messages.sqlite"].path,
            rooms=rooms,
        )
        declared_tokenizers = raw.get("fts_tokenizers")
        if not isinstance(declared_tokenizers, Mapping) or dict(
            declared_tokenizers
        ) != {
            "messages_fts": "unicode61",
            "messages_fts_trigram": tokenizers.get("messages_fts_trigram"),
        }:
            connection.close()
            raise CrawlerSourceError("manifest_tokenizer_summary_mismatch")
        if (
            raw.get("message_count") != message_count
            or raw.get("messages_fts_count") != fts_count
        ):
            connection.close()
            raise CrawlerSourceError("manifest_database_summary_mismatch")
        lexical_table = (
            "messages_fts_trigram"
            if tokenizers.get("messages_fts_trigram") == "trigram"
            else "messages_fts"
        )
        generation = CrawlerGeneration(
            generation_id=activation.generation_id,
            sequence=activation.sequence,
            manifest_digest=manifest_file.digest,
            manifest_path=manifest_path,
            membership_path=stable["membership.json"].path,
            database_path=stable["messages.sqlite"].path,
            profile_path=stable["profile.json"].path,
            membership_digest=stable["membership.json"].digest,
            database_digest=stable["messages.sqlite"].digest,
            profile_digest=stable["profile.json"].digest,
            rooms=rooms,
            message_count=message_count,
            lexical_table=lexical_table,
            lexical_tokenizer=tokenizers[lexical_table],
            activation_identities=activation_identities,
            file_identities=tuple(
                [manifest_file.identity]
                + [stable[name].identity for name in sorted(stable)]
            ),
        )
        return generation, connection

    def _assert_generation_current(self) -> None:
        generation = self._generation
        if generation is None:
            raise CrawlerSourceError("source_closed")
        activation, activation_identities = _select_activation(self.mount_root)
        if (
            activation.generation_id != generation.generation_id
            or activation.sequence != generation.sequence
            or activation_identities != generation.activation_identities
        ):
            raise CrawlerSourceError("generation_activation_changed")
        paths = (
            generation.manifest_path,
            generation.membership_path,
            generation.database_path,
            generation.profile_path,
        )
        identities = generation.file_identities
        try:
            current = tuple(_identity(path.lstat()) for path in paths)
        except OSError as exc:
            raise CrawlerSourceError("generation_file_unavailable") from exc
        if current != identities:
            raise CrawlerSourceError("generation_file_identity_changed")

    def search(
        self,
        query: str,
        rooms: Sequence[str],
        *,
        limit: int,
    ) -> list[LexicalHit]:
        if (
            not isinstance(query, str)
            or not 1 <= len(query) <= MAX_QUERY_CHARS
            or not query.strip()
            or "\x00" in query
        ):
            raise CrawlerSourceError("query_invalid")
        if (
            isinstance(rooms, (str, bytes))
            or not rooms
            or len(rooms) != len(set(rooms))
            or any(not isinstance(room, str) for room in rooms)
        ):
            raise CrawlerSourceError("room_selection_invalid")
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= MAX_RESULTS:
            raise CrawlerSourceError("result_limit_invalid")
        with self._lock:
            try:
                self.refresh()
            except CrawlerSourceError as exc:
                if exc.code != "generation_activation_changed":
                    raise
                self.refresh(force=True)
            generation = self.generation
            unknown = set(rooms) - set(generation.rooms)
            if unknown:
                raise CrawlerSourceError("room_outside_generation")
            connection = self._connection
            if connection is None:
                raise CrawlerSourceError("source_closed")
            table = generation.lexical_table
            placeholders = ",".join("?" for _ in rooms)
            # Quoting makes the caller's literal text one FTS phrase.  No
            # expansion, operator injection, or fallback query is introduced.
            expression = '"' + query.replace('"', '""') + '"'
            statement = f"""
                SELECT m.conversation_id,m.message_id,m.user_name,m.sent_time,
                       m.plain_text,bm25({table})
                FROM {table}
                JOIN messages AS m ON m.rowid={table}.rowid
                WHERE {table} MATCH ?
                  AND m.conversation_id IN ({placeholders})
                ORDER BY bm25({table}),m.conversation_id,m.sent_time,m.message_id
                LIMIT ?
            """
            self._assert_generation_current()
            try:
                rows = connection.execute(
                    statement, (expression, *rooms, limit)
                ).fetchall()
            except sqlite3.Error as exc:
                raise CrawlerSourceError("fts_query_failed") from exc
            self._assert_generation_current()
        hits: list[LexicalHit] = []
        for room, message_id, user_name, sent_time, text, score in rows:
            numeric_score = -float(score)
            if not math.isfinite(numeric_score):
                raise CrawlerSourceError("fts_score_invalid")
            hits.append(
                LexicalHit(
                    room=str(room),
                    message_id=str(message_id),
                    user_name=str(user_name or ""),
                    sent_time=int(sent_time or 0),
                    text=str(text or ""),
                    score=numeric_score,
                )
            )
        return hits

    def message_snapshot(self) -> list[SourceMessage]:
        """Read all indexable source messages without creating a second corpus."""

        with self._lock:
            self.refresh()
            connection = self._connection
            generation = self.generation
            if connection is None:
                raise CrawlerSourceError("source_closed")
            self._assert_generation_current()
            try:
                rows = connection.execute(
                    """
                    SELECT conversation_id,message_id,user_id,user_name,sent_time,plain_text
                    FROM messages
                    WHERE plain_text IS NOT NULL AND TRIM(plain_text) != ''
                    ORDER BY conversation_id,sent_time,message_id,user_id,user_name
                    """
                ).fetchall()
            except sqlite3.Error as exc:
                raise CrawlerSourceError("database_query_failed") from exc
            self._assert_generation_current()
        output: list[SourceMessage] = []
        seen: set[str] = set()
        allowed = set(generation.rooms)
        for room, message_id, user_id, user_name, sent_time, raw_text in rows:
            room = str(room)
            message_id = str(message_id)
            if room not in allowed or not message_id or message_id in seen:
                raise CrawlerSourceError("source_message_identity_invalid")
            seen.add(message_id)
            text = unicodedata.normalize(
                "NFC", str(raw_text).replace("\r\n", "\n").replace("\r", "\n")
            ).strip()
            if not text:
                continue
            output.append(
                SourceMessage(
                    room=room,
                    message_id=message_id,
                    user_id=unicodedata.normalize("NFC", str(user_id or "?")),
                    user_name=unicodedata.normalize("NFC", str(user_name or "?")),
                    sent_time=int(sent_time or 0),
                    text=text,
                )
            )
        if not output:
            raise CrawlerSourceError("source_has_no_indexable_messages")
        return output

    def resolve_references(
        self,
        *,
        room: str,
        references: Sequence[Mapping[str, Any]],
        expected_text_sha256: str,
    ) -> tuple[str, tuple[str, ...]]:
        """Resolve bounded segment references back to the authoritative SQLite."""

        if room not in self.rooms or not is_sha256(expected_text_sha256):
            raise CrawlerSourceError("segment_source_binding_invalid")
        if not 1 <= len(references) <= 32:
            raise CrawlerSourceError("segment_reference_count_invalid")
        identifiers: list[str] = []
        normalized_refs: list[tuple[str, int, int]] = []
        for reference in references:
            if not isinstance(reference, Mapping) or set(reference) != {
                "message_id",
                "start",
                "end",
            }:
                raise CrawlerSourceError("segment_reference_invalid")
            message_id = reference.get("message_id")
            start = reference.get("start")
            end = reference.get("end")
            if (
                not isinstance(message_id, str)
                or not message_id
                or len(message_id) > 256
                or isinstance(start, bool)
                or not isinstance(start, int)
                or isinstance(end, bool)
                or not isinstance(end, int)
                or not 0 <= start < end
            ):
                raise CrawlerSourceError("segment_reference_invalid")
            identifiers.append(message_id)
            normalized_refs.append((message_id, start, end))
        unique = sorted(set(identifiers))
        placeholders = ",".join("?" for _ in unique)
        with self._lock:
            self.refresh()
            connection = self._connection
            if connection is None:
                raise CrawlerSourceError("source_closed")
            self._assert_generation_current()
            try:
                rows = connection.execute(
                    f"SELECT message_id,conversation_id,plain_text FROM messages "
                    f"WHERE message_id IN ({placeholders})",
                    unique,
                ).fetchall()
            except sqlite3.Error as exc:
                raise CrawlerSourceError("database_query_failed") from exc
            self._assert_generation_current()
        by_id: dict[str, str] = {}
        for message_id, source_room, raw_text in rows:
            if str(source_room) != room:
                raise CrawlerSourceError("segment_reference_outside_room")
            by_id[str(message_id)] = unicodedata.normalize(
                "NFC", str(raw_text).replace("\r\n", "\n").replace("\r", "\n")
            ).strip()
        if set(by_id) != set(unique):
            raise CrawlerSourceError("segment_reference_missing")
        pieces: list[str] = []
        for message_id, start, end in normalized_refs:
            text = by_id[message_id]
            if end > len(text):
                raise CrawlerSourceError("segment_reference_bounds_invalid")
            pieces.append(text[start:end])
        rendered = " ".join(pieces)
        if _sha256(rendered.encode("utf-8")) != expected_text_sha256:
            raise CrawlerSourceError("segment_source_text_digest_mismatch")
        return rendered, tuple(dict.fromkeys(identifiers))



class CrawlerFtsSearchPipeline:
    """Replaceable F extension that searches the crawler SQLite directly."""

    def __init__(self, source: CanonicalCrawlerSource, *, pool: int = 30):
        if source.require_readonly is not True:
            raise CrawlerSourceError("product_source_must_be_readonly")
        if isinstance(pool, bool) or not isinstance(pool, int) or not 1 <= pool <= 100:
            raise CrawlerSourceError("candidate_pool_invalid")
        self.source = source
        self.pool = pool

    def search(self, query: str, rooms: list[str], k: int) -> dict[str, Any]:
        if isinstance(k, bool) or not isinstance(k, int) or not 1 <= k <= 10:
            raise CrawlerSourceError("result_limit_invalid")
        hits = self.source.search(query, rooms, limit=max(k, self.pool))
        generation = self.source.generation
        selected = hits[:k]
        return {
            "hits": [
                {
                    "room": hit.room,
                    "level": "message",
                    "seg_id": hit.message_id,
                    "message_ids": [hit.message_id],
                    "text": hit.text,
                    "score": hit.score,
                }
                for hit in selected
            ],
            "operation_evidence": {
                "schema_version": "kwrag-slot-pipeline-evidence-v1",
                "backend_id": (
                    "crawler-sqlite-fts-trigram-v1"
                    if generation.lexical_tokenizer == "trigram"
                    else "crawler-sqlite-fts-unicode61-compat-v1"
                ),
                "stages": [
                    {
                        "stage_id": "crawler_sqlite_fts",
                        "execution_scope": "slot_local",
                        "call_count": 1,
                        "input_count": len(rooms),
                        "output_count": len(hits),
                        "model": None,
                        "revision": generation.manifest_digest,
                    }
                ],
                "candidate_count": len(hits),
                "data_boundary": {
                    "bytes_sent_outside_slot": 0,
                    "external_persistence": "not_applicable",
                    "persistence_receipt_digest": None,
                },
            },
        }
