"""Production-only entry point for the host-local shared GPU service."""

from __future__ import annotations

import argparse
import os
import signal
import stat
import threading
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Mapping

from .jsonutil import loads_canonical_json_bytes
from .shared_gpu_core import SharedGpuCore, SharedGpuCoreConfig
from .shared_gpu_models import PinnedKureBgeBackend
from .shared_gpu_transport import (
    PeerAuthorizer,
    SharedGpuUnixServer,
    SlotPeerGrant,
)


MAX_CONFIG_BYTES = 256 * 1024
_CONFIG_FIELDS = frozenset(
    {
        "schema_version",
        "model_cache_root",
        "dtype",
        "embedding_batch_size",
        "rerank_batch_size",
        "max_concurrent",
        "max_queue",
        "endpoints",
    }
)
_ENDPOINT_FIELDS = frozenset({"socket_path", "socket_mode", "grants"})
_GRANT_FIELDS = frozenset({"slot", "uid", "gid"})


class SharedGpuServiceConfigError(ValueError):
    pass


@dataclass(frozen=True)
class EndpointSpec:
    socket_path: Path
    socket_mode: int
    grants: tuple[SlotPeerGrant, ...]


@dataclass(frozen=True)
class ServiceSpec:
    model_cache_root: Path
    dtype: str
    embedding_batch_size: int
    rerank_batch_size: int
    max_concurrent: int
    max_queue: int
    endpoints: tuple[EndpointSpec, ...]


def _absolute(value: Any, field: str) -> Path:
    if not isinstance(value, str) or not value or len(value) > 4_096:
        raise SharedGpuServiceConfigError(f"{field} is invalid")
    path = PurePosixPath(value)
    if (
        not path.is_absolute()
        or path.as_posix() != value
        or "\\" in value
        or ":" in value
        or any(part in {"", ".", ".."} for part in path.parts)
    ):
        raise SharedGpuServiceConfigError(f"{field} is invalid")
    return Path(value)


def _integer(value: Any, *, minimum: int, maximum: int, field: str) -> int:
    if (
        isinstance(value, bool)
        or not isinstance(value, int)
        or not minimum <= value <= maximum
    ):
        raise SharedGpuServiceConfigError(f"{field} is invalid")
    return value


def _read_config(path: Path) -> Mapping[str, Any]:
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    try:
        descriptor = os.open(path, flags)
    except OSError as exc:
        raise SharedGpuServiceConfigError("config is unavailable") from exc
    chunks: list[bytes] = []
    try:
        before = os.fstat(descriptor)
        if (
            not stat.S_ISREG(before.st_mode)
            or before.st_nlink != 1
            or before.st_size < 1
            or before.st_size > MAX_CONFIG_BYTES
            or before.st_uid not in {0, os.geteuid()}
            or stat.S_IMODE(before.st_mode) & 0o022
        ):
            raise SharedGpuServiceConfigError("config identity is invalid")
        while True:
            block = os.read(descriptor, 16 * 1024)
            if not block:
                break
            chunks.append(block)
        after = os.fstat(descriptor)
        if (
            before.st_dev,
            before.st_ino,
            before.st_size,
            before.st_mtime_ns,
        ) != (
            after.st_dev,
            after.st_ino,
            after.st_size,
            after.st_mtime_ns,
        ):
            raise SharedGpuServiceConfigError("config changed while loading")
    finally:
        os.close(descriptor)
    try:
        raw = loads_canonical_json_bytes(b"".join(chunks))
    except (UnicodeDecodeError, ValueError) as exc:
        raise SharedGpuServiceConfigError("config is not canonical") from exc
    if not isinstance(raw, Mapping):
        raise SharedGpuServiceConfigError("config root is invalid")
    return raw


def load_service_spec(path: Path) -> ServiceSpec:
    raw = _read_config(Path(path))
    if set(raw) != _CONFIG_FIELDS or raw.get("schema_version") != "kwrag-shared-gpu-service-config-v1":
        raise SharedGpuServiceConfigError("config fields or schema are invalid")
    model_cache_root = _absolute(raw.get("model_cache_root"), "model_cache_root")
    dtype = raw.get("dtype")
    if dtype not in {"float32", "float16", "bfloat16"}:
        raise SharedGpuServiceConfigError("dtype is invalid")
    embedding_batch = _integer(
        raw.get("embedding_batch_size"), minimum=1, maximum=64, field="embedding_batch_size"
    )
    rerank_batch = _integer(
        raw.get("rerank_batch_size"), minimum=1, maximum=32, field="rerank_batch_size"
    )
    max_concurrent = _integer(
        raw.get("max_concurrent"), minimum=1, maximum=8, field="max_concurrent"
    )
    max_queue = _integer(raw.get("max_queue"), minimum=1, maximum=64, field="max_queue")
    endpoints_raw = raw.get("endpoints")
    if not isinstance(endpoints_raw, list) or not 1 <= len(endpoints_raw) <= 64:
        raise SharedGpuServiceConfigError("endpoints are invalid")
    endpoints: list[EndpointSpec] = []
    socket_paths: set[Path] = set()
    slots: set[str] = set()
    peers: set[tuple[int, int]] = set()
    for endpoint_raw in endpoints_raw:
        if not isinstance(endpoint_raw, Mapping) or set(endpoint_raw) != _ENDPOINT_FIELDS:
            raise SharedGpuServiceConfigError("endpoint fields are invalid")
        socket_path = _absolute(endpoint_raw.get("socket_path"), "socket_path")
        if socket_path in socket_paths:
            raise SharedGpuServiceConfigError("socket path is reused")
        socket_paths.add(socket_path)
        mode_raw = endpoint_raw.get("socket_mode")
        if mode_raw not in {"0600", "0660"}:
            raise SharedGpuServiceConfigError("socket mode is invalid")
        grants_raw = endpoint_raw.get("grants")
        if not isinstance(grants_raw, list) or len(grants_raw) != 1:
            raise SharedGpuServiceConfigError("endpoint grants are invalid")
        grants: list[SlotPeerGrant] = []
        for grant_raw in grants_raw:
            if not isinstance(grant_raw, Mapping) or set(grant_raw) != _GRANT_FIELDS:
                raise SharedGpuServiceConfigError("grant fields are invalid")
            slot = grant_raw.get("slot")
            uid = _integer(grant_raw.get("uid"), minimum=0, maximum=2**31 - 1, field="uid")
            gid = _integer(grant_raw.get("gid"), minimum=0, maximum=2**31 - 1, field="gid")
            grant = SlotPeerGrant(slot=str(slot), uid=uid, gid=gid)
            peer = (uid, gid)
            if peer in peers:
                raise SharedGpuServiceConfigError("peer is bound more than once")
            peers.add(peer)
            if grant.slot in slots:
                raise SharedGpuServiceConfigError("slot is bound more than once")
            slots.add(grant.slot)
            grants.append(grant)
        endpoints.append(
            EndpointSpec(
                socket_path=socket_path,
                socket_mode=int(str(mode_raw), 8),
                grants=tuple(grants),
            )
        )
    return ServiceSpec(
        model_cache_root=model_cache_root,
        dtype=str(dtype),
        embedding_batch_size=embedding_batch,
        rerank_batch_size=rerank_batch,
        max_concurrent=max_concurrent,
        max_queue=max_queue,
        endpoints=tuple(endpoints),
    )


def run(spec: ServiceSpec) -> int:
    backend = PinnedKureBgeBackend(
        spec.model_cache_root,
        dtype=spec.dtype,
        embedding_batch_size=spec.embedding_batch_size,
        rerank_batch_size=spec.rerank_batch_size,
    )
    core = SharedGpuCore(
        backend,
        SharedGpuCoreConfig(
            max_concurrent=spec.max_concurrent,
            max_queue=spec.max_queue,
            allow_nonproduction_backend=False,
        ),
    )
    core.start()
    servers: list[SharedGpuUnixServer] = []
    stop = threading.Event()

    def request_stop(_signum: int, _frame: Any) -> None:
        stop.set()

    previous = {
        signal_number: signal.signal(signal_number, request_stop)
        for signal_number in (signal.SIGINT, signal.SIGTERM)
    }
    try:
        for endpoint in spec.endpoints:
            server = SharedGpuUnixServer(
                socket_path=endpoint.socket_path,
                socket_mode=endpoint.socket_mode,
                core=core,
                authorizer=PeerAuthorizer(endpoint.grants),
            )
            server.serve_in_thread()
            servers.append(server)
        stop.wait()
    finally:
        for server in reversed(servers):
            server.shutdown()
        core.shutdown(grace_seconds=30)
        for signal_number, handler in previous.items():
            signal.signal(signal_number, handler)
    return 0


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run the host-local KWRAG shared GPU plane.")
    parser.add_argument("--config", type=Path, required=True)
    return parser


def main() -> int:
    args = _parser().parse_args()
    try:
        spec = load_service_spec(args.config)
        return run(spec)
    except (SharedGpuServiceConfigError, ValueError, OSError):
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
