"""Bounded, transport-independent execution core for shared GPU inference."""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass
from typing import Any, Mapping

from .shared_gpu_contract import (
    KURE_MODEL,
    KURE_REVISION,
    RERANK_MODEL,
    RERANK_REVISION,
    SharedGpuContractError,
    ValidatedGpuRequest,
    make_receipt,
    make_response,
    validate_request,
    validate_scores,
    validate_vectors,
)
from .shared_gpu_models import SharedGpuBackend


@dataclass(frozen=True)
class CallerIdentity:
    slot: str
    principal: str
    peer_uid: int
    peer_gid: int


@dataclass(frozen=True)
class SharedGpuCoreConfig:
    max_concurrent: int = 1
    max_queue: int = 8
    allow_nonproduction_backend: bool = False

    def __post_init__(self) -> None:
        for value, maximum, name in (
            (self.max_concurrent, 8, "max_concurrent"),
            (self.max_queue, 64, "max_queue"),
        ):
            if (
                isinstance(value, bool)
                or not isinstance(value, int)
                or not 1 <= value <= maximum
            ):
                raise ValueError(f"{name} is invalid")
        if not isinstance(self.allow_nonproduction_backend, bool):
            raise ValueError("allow_nonproduction_backend is invalid")


@dataclass
class _ActiveRequest:
    cancelled: threading.Event
    slot: str
    principal: str


class SharedGpuCore:
    """Own models once, admit a bounded queue, and retain no request payload."""

    def __init__(self, backend: SharedGpuBackend, config: SharedGpuCoreConfig):
        if not backend.production and not config.allow_nonproduction_backend:
            raise SharedGpuContractError("nonproduction_backend_forbidden")
        self.backend = backend
        self.config = config
        self._state = "created"
        self._state_lock = threading.RLock()
        self._active_changed = threading.Condition(self._state_lock)
        self._active: dict[str, _ActiveRequest] = {}
        self._admission = threading.BoundedSemaphore(
            config.max_concurrent + config.max_queue
        )
        self._execution = threading.BoundedSemaphore(config.max_concurrent)
        self._accepted_count = 0
        self._completed_count = 0
        self._rejected_count = 0

    @property
    def state(self) -> str:
        with self._state_lock:
            return self._state

    def start(self) -> None:
        with self._state_lock:
            if self._state == "ready":
                return
            if self._state != "created":
                raise SharedGpuContractError("service_start_state_invalid")
            self._state = "starting"
        try:
            self.backend.warm()
        except Exception:
            with self._state_lock:
                self._state = "failed"
            raise
        with self._state_lock:
            self._state = "ready"

    def snapshot(self) -> dict[str, Any]:
        """Return only bounded operational counters, never request data."""

        with self._state_lock:
            return {
                "state": self._state,
                "production_backend": bool(self.backend.production),
                "active_count": len(self._active),
                "accepted_count": self._accepted_count,
                "completed_count": self._completed_count,
                "rejected_count": self._rejected_count,
                "embedding_model": self.backend.embedding_model,
                "embedding_revision": self.backend.embedding_revision,
                "rerank_model": self.backend.rerank_model,
                "rerank_revision": self.backend.rerank_revision,
            }

    def shutdown(self, *, grace_seconds: float = 10.0) -> bool:
        if not 0 <= grace_seconds <= 60:
            raise ValueError("shutdown grace is invalid")
        deadline = time.monotonic() + grace_seconds
        with self._state_lock:
            if self._state in {"stopped", "failed"}:
                return not self._active
            self._state = "stopping"
            for active in self._active.values():
                active.cancelled.set()
            while self._active and time.monotonic() < deadline:
                self._active_changed.wait(timeout=max(0.0, deadline - time.monotonic()))
            drained = not self._active
            self._state = "stopped"
            return drained

    def execute(
        self,
        raw_request: Any,
        *,
        caller: CallerIdentity,
        now_unix_ms: int | None = None,
    ) -> dict[str, Any]:
        request = validate_request(raw_request, now_unix_ms=now_unix_ms)
        if request.slot != caller.slot or request.principal != caller.principal:
            raise SharedGpuContractError("caller_identity_mismatch")
        if request.operation == "health":
            healthy = self.state not in {"failed", "stopped"}
            return self._control_response(
                request,
                {"healthy": healthy, "state": self.state},
            )
        if request.operation == "ready":
            ready = self.state == "ready" and bool(self.backend.production)
            return self._control_response(
                request,
                {
                    "ready": ready,
                    "production_backend": bool(self.backend.production),
                    "state": self.state,
                    "embedding_model": self.backend.embedding_model,
                    "embedding_revision": self.backend.embedding_revision,
                    "rerank_model": self.backend.rerank_model,
                    "rerank_revision": self.backend.rerank_revision,
                },
            )
        if request.operation == "cancel":
            target = str(request.payload["target_request_id"])
            with self._state_lock:
                active = self._active.get(target)
                cancelled = bool(
                    active is not None
                    and active.slot == caller.slot
                    and active.principal == caller.principal
                )
                if cancelled:
                    assert active is not None
                    active.cancelled.set()
            return self._control_response(request, {"cancelled": cancelled})
        with self._state_lock:
            if self._state != "ready":
                self._rejected_count += 1
                return self._error_response(
                    request, "service_not_ready", retryable=True, started=time.monotonic()
                )
        if not self._admission.acquire(blocking=False):
            with self._state_lock:
                self._rejected_count += 1
            return self._error_response(
                request, "queue_full", retryable=True, started=time.monotonic()
            )
        started = time.monotonic()
        event = threading.Event()
        execution_acquired = False
        registered = False
        try:
            with self._state_lock:
                if request.request_id in self._active:
                    self._rejected_count += 1
                    return self._error_response(
                        request,
                        "duplicate_request_id",
                        retryable=False,
                        started=started,
                    )
                self._active[request.request_id] = _ActiveRequest(
                    cancelled=event,
                    slot=caller.slot,
                    principal=caller.principal,
                )
                registered = True
                self._accepted_count += 1
            while not execution_acquired:
                if event.is_set():
                    raise SharedGpuContractError("cancelled")
                remaining = (request.deadline_unix_ms - int(time.time() * 1_000)) / 1_000
                if remaining <= 0:
                    raise SharedGpuContractError("deadline_exceeded", retryable=True)
                execution_acquired = self._execution.acquire(
                    timeout=min(0.05, remaining)
                )
            if event.is_set():
                raise SharedGpuContractError("cancelled")
            response = self._run(request, event, started)
            with self._state_lock:
                self._completed_count += 1
            return response
        except SharedGpuContractError as exc:
            with self._state_lock:
                self._rejected_count += 1
            return self._error_response(
                request, exc.code, retryable=exc.retryable, started=started
            )
        except Exception:
            with self._state_lock:
                self._rejected_count += 1
            return self._error_response(
                request, "backend_failed", retryable=True, started=started
            )
        finally:
            if execution_acquired:
                self._execution.release()
            if registered:
                with self._state_lock:
                    self._active.pop(request.request_id, None)
                    self._active_changed.notify_all()
            self._admission.release()

    def _run(
        self,
        request: ValidatedGpuRequest,
        event: threading.Event,
        started: float,
    ) -> dict[str, Any]:
        cancelled = event.is_set
        if request.operation in {"embed_query", "embed_corpus"}:
            texts = (
                [str(request.payload["text"])]
                if request.operation == "embed_query"
                else list(request.payload["texts"])
            )
            vectors = self.backend.embed(
                texts,
                corpus=request.operation == "embed_corpus",
                cancelled=cancelled,
                deadline_unix_ms=request.deadline_unix_ms,
            )
            vectors = validate_vectors(vectors, expected_count=len(texts))
            if any(len(vector) != self.backend.embedding_dimension for vector in vectors):
                raise SharedGpuContractError("embedding_dimension_mismatch")
            output: Mapping[str, Any] = {"vectors": vectors}
            shape = [len(vectors), self.backend.embedding_dimension]
            model = self.backend.embedding_model
            revision = self.backend.embedding_revision
        elif request.operation == "rerank":
            passages = list(request.payload["passages"])
            scores = self.backend.rerank(
                str(request.payload["query"]),
                passages,
                cancelled=cancelled,
                deadline_unix_ms=request.deadline_unix_ms,
            )
            scores = validate_scores(scores, expected_count=len(passages))
            output = {"scores": scores}
            shape = [len(scores)]
            model = self.backend.rerank_model
            revision = self.backend.rerank_revision
        else:  # validated above
            raise SharedGpuContractError("operation_invalid")
        receipt = make_receipt(
            request=request,
            status="completed",
            model=model,
            revision=revision,
            production_backend=bool(self.backend.production),
            output_count=request.input_count,
            output_shape=shape,
            duration_ms=round((time.monotonic() - started) * 1_000),
            error_code=None,
        )
        return make_response(
            request=request,
            status="completed",
            output=output,
            receipt=receipt,
        )

    def _control_response(
        self,
        request: ValidatedGpuRequest,
        output: Mapping[str, Any],
    ) -> dict[str, Any]:
        receipt = make_receipt(
            request=request,
            status="completed",
            model=None,
            revision=None,
            production_backend=bool(self.backend.production),
            output_count=1,
            output_shape=[1],
            duration_ms=0,
            error_code=None,
        )
        return make_response(
            request=request,
            status="completed",
            output=output,
            receipt=receipt,
        )

    def _error_response(
        self,
        request: ValidatedGpuRequest,
        code: str,
        *,
        retryable: bool,
        started: float,
    ) -> dict[str, Any]:
        model: str | None
        revision: str | None
        if request.operation in {"embed_query", "embed_corpus"}:
            model, revision = KURE_MODEL, KURE_REVISION
        elif request.operation == "rerank":
            model, revision = RERANK_MODEL, RERANK_REVISION
        else:
            model, revision = None, None
        receipt = make_receipt(
            request=request,
            status="error",
            model=model,
            revision=revision,
            output_count=0,
            production_backend=bool(self.backend.production),
            output_shape=[],
            duration_ms=round((time.monotonic() - started) * 1_000),
            error_code=code,
        )
        return make_response(
            request=request,
            status="error",
            output=None,
            receipt=receipt,
            error_code=code,
            retryable=retryable,
        )
