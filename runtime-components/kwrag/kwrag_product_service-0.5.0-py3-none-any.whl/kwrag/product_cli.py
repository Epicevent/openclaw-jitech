"""Fixed, shell-free product CLI for the slot-local Kakao runtime.

The process environment selects the product profile.  Callers provide only
bounded search/index intent; paths, corpus identity, releases, and digests are
resolved from the mounted slot and its writable Workspace.
"""

from __future__ import annotations

import hashlib
import json
import sys
from typing import Any

from .jsonutil import canonical_json_bytes
from .product_index import ProductIndexError, _runtime_layout
from .product_runtime import ProductRuntimeError, build_index, index_status, open_product_runtime

MAX_INPUT_BYTES = 64 * 1024


def _read_body() -> dict[str, Any]:
    raw = sys.stdin.buffer.read(MAX_INPUT_BYTES + 1)
    if len(raw) > MAX_INPUT_BYTES:
        raise ValueError("request_too_large")
    if not raw.strip():
        return {}
    value = json.loads(raw.decode("utf-8"))
    if not isinstance(value, dict):
        raise ValueError("request_must_be_object")
    return value


def _emit(value: dict[str, Any], *, code: int = 0) -> int:
    sys.stdout.write(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")))
    sys.stdout.write("\n")
    return code


def _error(exc: Exception) -> int:
    message = str(exc)
    reason = (
        message
        if message and message.replace("_", "").isalnum() and message.isascii()
        else "product_runtime_error"
    )
    return _emit(
        {
            "schema_version": "kwrag-product-cli-error-v1",
            "status": "error",
            "reason_code": reason,
            "raw_content_present": False,
        },
        code=1,
    )


def _index_build(body: dict[str, Any]) -> dict[str, Any]:
    allowed = {"scope", "exclude"}
    if set(body) - allowed:
        raise ValueError("index_build_fields_invalid")
    # An explicit operator/user index action is a refresh of today's mounted
    # corpus.  It never trusts a caller-supplied generation or manifest.
    return {"schema_version": "kwrag-product-cli-index-build-v1", **build_index(
        scope=body.get("scope"),
        exclude=body.get("exclude"),
        rebuild=True,
    )}


def _search(body: dict[str, Any]) -> dict[str, Any]:
    allowed = {"query", "request_id", "operation_id", "run_id", "attempt", "max_results", "corpus"}
    if set(body) - allowed:
        raise ValueError("search_fields_invalid")
    request = {
        "schema_version": "kwrag-slot-search-request-v1",
        **body,
    }
    layout = _runtime_layout()
    with open_product_runtime(
        source_root=layout.mount_root / "kw" / "package",
        workspace_root=layout.workspace_root,
        slot_namespace=layout.slot_namespace,
        socket_path=layout.socket_path,
        receipt_path=layout.workspace_root / "receipts" / "search.jsonl",
        gpu_receipt_path=layout.workspace_root / "receipts" / "gpu.jsonl",
    ) as runtime:
        exchange = runtime.search_exchange(request)
        runtime_observation = {
            "slot_namespace": layout.slot_namespace,
            "mount_read_only": True,
            "index_manifest": runtime.identity.index_manifest,
            "pipeline_fingerprint": runtime.identity.pipeline_fingerprint,
            "source_state_sha256": runtime.identity.source_state_sha256,
        }
        runtime_digest = "sha256:" + hashlib.sha256(
            canonical_json_bytes(runtime_observation)
        ).hexdigest()
    return {
        "schema_version": "kwrag-product-cli-search-v1",
        "status": "ok",
        "response": exchange.response,
        "operation_receipt": exchange.operation_receipt,
        "operation_receipt_observation": exchange.response["operation_receipt"],
        "runtime_observation": runtime_observation,
        "runtime_digest": runtime_digest,
        "raw_content_present": False,
    }


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if len(args) != 1 or args[0] not in {"index-build", "index-status", "search"}:
        return _emit(
            {
                "schema_version": "kwrag-product-cli-error-v1",
                "status": "error",
                "reason_code": "command_invalid",
                "raw_content_present": False,
            },
            code=2,
        )
    try:
        body = _read_body()
        if args[0] == "index-build":
            return _emit(_index_build(body))
        if args[0] == "index-status":
            if body:
                raise ValueError("index_status_fields_invalid")
            return _emit({"schema_version": "kwrag-product-cli-index-status-v1", **index_status()})
        return _emit(_search(body))
    except (ProductIndexError, ProductRuntimeError, ValueError, OSError, json.JSONDecodeError) as exc:
        return _error(exc)


if __name__ == "__main__":
    raise SystemExit(main())
