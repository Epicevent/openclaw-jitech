"""In-slot search boundary whose authority is the mounted index itself.

This is deliberately transport-neutral.  It does not open a host port and it
does not accept a bearer token, slot id, grant, or projection.  A product-owned
adapter may call it only from inside the slot boundary that owns ``scope``.
"""

from __future__ import annotations

import hashlib
import threading
import time
from dataclasses import dataclass
from typing import Any
from uuid import uuid4

from .jsonutil import canonical_json_bytes, is_sha256
from .operation import (
    MAX_CORRELATION_CHARS,
    MAX_QUERY_CHARS,
    OperationError,
    ReceiptWriter,
    SearchPipeline,
    map_results,
    slot_pipeline_evidence,
)
from .slot_mount import SlotIndexScope, SlotMountError

_ALLOWED_REQUEST_FIELDS = frozenset(
    {
        "query",
        "schema_version",
        "request_id",
        "operation_id",
        "run_id",
        "attempt",
        "max_results",
        "corpus",
        "rooms",
    }
)


def _requested_rooms(body: dict[str, Any]) -> list[str] | None:
    """Translate the private room-list seam; keep old producers isolated."""

    if "rooms" in body and "corpus" in body:
        raise OperationError(
            400, "invalid_request", "room selection fields are mutually exclusive"
        )
    if "rooms" in body:
        value = body.get("rooms")
        if (
            not isinstance(value, list)
            or not 1 <= len(value) <= 64
            or any(
                not isinstance(room, str)
                or not 1 <= len(room) <= 256
                or room != room.strip()
                for room in value
            )
            or len(value) != len(set(value))
        ):
            raise OperationError(
                400,
                "invalid_request",
                "rooms must be a unique list of 1-64 exact room ids",
            )
        return list(value)
    corpus = body.get("corpus")
    if corpus is not None and (
        not isinstance(corpus, str) or not 1 <= len(corpus) <= 256
    ):
        raise OperationError(
            400,
            "invalid_request",
            "corpus must contain 1-256 characters when provided",
        )
    return None if corpus is None else [corpus]


@dataclass(frozen=True)
class SlotSearchExchange:
    """One response and the exact operation receipt written for that response.

    This is an in-process integration object.  It does not add either object to
    the model-visible contract or change the public response schema.
    """

    response: dict[str, Any]
    operation_receipt: dict[str, Any]


class SlotSearchApplication:
    def __init__(
        self,
        *,
        pipeline: SearchPipeline,
        scope: SlotIndexScope,
        pipeline_fingerprint: str,
        receipt_writer: ReceiptWriter,
        max_concurrent: int = 1,
    ):
        if not is_sha256(pipeline_fingerprint):
            raise ValueError("pipeline_fingerprint must be a SHA-256 identity")
        if (
            isinstance(max_concurrent, bool)
            or not isinstance(max_concurrent, int)
            or not 1 <= max_concurrent <= 64
        ):
            raise ValueError("max_concurrent must be an integer from 1 to 64")
        mount_root = scope.mount_root.resolve(strict=False)
        receipt_path = receipt_writer.path.resolve(strict=False)
        try:
            receipt_path.relative_to(mount_root)
        except ValueError:
            pass
        else:
            raise ValueError("receipt sink must be outside the read-only slot mount")
        if scope.readonly_required is not True:
            raise ValueError("slot search scope must require a read-only mount")
        try:
            scope.assert_current()
        except SlotMountError as exc:
            raise ValueError("slot search scope must be a current read-only mount") from exc
        self.pipeline = pipeline
        self.scope = scope
        self.pipeline_fingerprint = pipeline_fingerprint
        self.receipts = receipt_writer
        self._search_slots = threading.BoundedSemaphore(max_concurrent)

    def ready(self) -> dict[str, Any]:
        self.scope.assert_current()
        return {
            "ready": True,
            "authorization_basis": "slot_mounted_storage",
            "index_manifest": self.scope.manifest.digest,
            "pipeline_fingerprint": self.pipeline_fingerprint,
            "corpus_count": len(self.scope.available_rooms),
        }

    def search(self, body: Any) -> dict[str, Any]:
        return self.search_exchange(body).response

    def search_exchange(self, body: Any) -> SlotSearchExchange:
        """Run one caller-requested search and retain its receipt for validation."""

        started = time.monotonic()
        request_id = str(uuid4())
        if not isinstance(body, dict):
            raise OperationError(400, "invalid_request", "request body must be an object")
        unknown_fields = set(body) - _ALLOWED_REQUEST_FIELDS
        if unknown_fields:
            raise OperationError(
                400,
                "invalid_request",
                "request contains a field outside the slot-local contract",
            )
        if body.get("schema_version") != "kwrag-slot-search-request-v1":
            raise OperationError(
                400,
                "invalid_request",
                "schema_version must be kwrag-slot-search-request-v1",
            )
        raw_request_id = body.get("request_id")
        if raw_request_id is None:
            pass
        elif (
            isinstance(raw_request_id, str)
            and 0 < len(raw_request_id) <= MAX_CORRELATION_CHARS
        ):
            request_id = raw_request_id
        else:
            raise OperationError(
                400, "invalid_request", "request_id must contain 1-128 characters"
            )
        raw_operation_id = body.get("operation_id")
        if raw_operation_id is None:
            operation_id = request_id
            operation_id_source = "request_id_default"
        elif (
            isinstance(raw_operation_id, str)
            and 0 < len(raw_operation_id) <= MAX_CORRELATION_CHARS
        ):
            operation_id = raw_operation_id
            operation_id_source = "client"
        else:
            raise OperationError(
                400, "invalid_request", "operation_id must contain 1-128 characters"
            )
        raw_run_id = body.get("run_id")
        if raw_run_id is None:
            run_id = None
        elif (
            isinstance(raw_run_id, str)
            and 0 < len(raw_run_id) <= MAX_CORRELATION_CHARS
        ):
            run_id = raw_run_id
        else:
            raise OperationError(400, "invalid_request", "run_id must contain 1-128 characters")
        attempt = body.get("attempt", 1)
        if isinstance(attempt, bool) or not isinstance(attempt, int) or not 1 <= attempt <= 16:
            raise OperationError(
                400, "invalid_request", "attempt must be an integer from 1 to 16"
            )
        raw_query = body.get("query")
        if (
            not isinstance(raw_query, str)
            or not 1 <= len(raw_query) <= MAX_QUERY_CHARS
        ):
            raise OperationError(
                400, "invalid_request", "query must contain 1-4000 characters"
            )
        query = raw_query.strip()
        if not query:
            raise OperationError(
                400, "invalid_request", "query must contain 1-4000 characters"
            )
        max_results = body.get("max_results", 5)
        if (
            isinstance(max_results, bool)
            or not isinstance(max_results, int)
            or not 1 <= max_results <= 10
        ):
            raise OperationError(
                400, "invalid_request", "max_results must be an integer from 1 to 10"
            )
        requested_rooms = _requested_rooms(body)
        try:
            self.scope.assert_current()
        except SlotMountError as exc:
            raise OperationError(
                503,
                "not_ready",
                "slot-mounted snapshot identity changed",
                retryable=True,
            ) from exc
        try:
            rooms = self.scope.select_rooms(requested_rooms)
        except SlotMountError as exc:
            raise OperationError(
                403,
                "outside_mounted_scope",
                "requested room is outside the slot-mounted index",
            ) from exc
        if not self._search_slots.acquire(blocking=False):
            raise OperationError(429, "overloaded", "slot search is busy", retryable=True)

        execution_status = "completed"
        result_status = "zero_hits"
        result_count = 0
        result_digest: str | None = None
        results: list[dict[str, Any]] = []
        evidence = slot_pipeline_evidence(None, 0, len(rooms))
        failure: OperationError | None = None
        try:
            raw = self.pipeline.search(query, rooms, max_results)
            results = map_results(raw.get("hits"), max_results, set(rooms))
            result_count = len(results)
            result_status = "hits" if results else "zero_hits"
            result_digest = "sha256:" + hashlib.sha256(
                canonical_json_bytes(results)
            ).hexdigest()
            evidence = slot_pipeline_evidence(raw, result_count, len(rooms))
            self.scope.assert_current()
        except OperationError as exc:
            execution_status = "failed"
            result_status = "error"
            result_count = 0
            result_digest = None
            results = []
            evidence = slot_pipeline_evidence(None, 0, len(rooms))
            failure = exc
        except SlotMountError:
            execution_status = "failed"
            result_status = "error"
            result_count = 0
            result_digest = None
            results = []
            evidence = slot_pipeline_evidence(None, 0, len(rooms))
            failure = OperationError(
                503,
                "not_ready",
                "slot-mounted snapshot identity changed during search",
                retryable=True,
            )
        except Exception:
            execution_status = "failed"
            result_status = "error"
            result_count = 0
            result_digest = None
            results = []
            evidence = slot_pipeline_evidence(None, 0, len(rooms))
            failure = OperationError(
                503, "not_ready", "slot search execution failed", retryable=True
            )
        finally:
            self._search_slots.release()

        duration_ms = round((time.monotonic() - started) * 1_000)
        fully_slot_local = evidence["status"] == "available" and all(
            stage["execution_scope"] == "slot_local"
            for stage in evidence["stages"]
        )
        provider_billing = (
            {
                "status": "not_applicable",
                "amount": None,
                "currency": None,
                "reason": "fully_slot_local_pipeline_has_no_external_provider_receipt",
            }
            if fully_slot_local
            else {
                "status": "unavailable",
                "amount": None,
                "currency": None,
                "reason": "pipeline_provider_billing_not_attested",
            }
        )
        operation_receipt = {
            "schema_version": "kwrag-slot-search-operation-receipt-v1",
            "recorded_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "operation_id": operation_id,
            "operation_id_source": operation_id_source,
            "request_id": request_id,
            "run_id": run_id,
            "attempt": attempt,
            "authorization_basis": "slot_mounted_storage",
            "corpora": rooms,
            "query_chars": len(query),
            "requested_max_results": max_results,
            "index_manifest": self.scope.manifest.digest,
            "pipeline_fingerprint": self.pipeline_fingerprint,
            "execution_status": execution_status,
            "result_status": result_status,
            "duration_ms": duration_ms,
            "result_count": result_count,
            "result_digest": result_digest,
            "pipeline_evidence": evidence,
            "provider_billing": provider_billing,
            "full_economic_cost": {
                "status": "unavailable",
                "amount": None,
                "currency": None,
                "reason": "hardware_energy_depreciation_and_operator_cost_not_measured",
            },
            "error_code": failure.code if failure is not None else None,
        }
        receipt_result = self.receipts.write(operation_receipt)
        if failure is not None:
            raise failure
        response = {
            "schema_version": "kwrag-slot-search-response-v1",
            "request_id": request_id,
            "operation_id": operation_id,
            "run_id": run_id,
            "attempt": attempt,
            "authorization_basis": "slot_mounted_storage",
            "index_manifest": self.scope.manifest.digest,
            "pipeline_fingerprint": self.pipeline_fingerprint,
            "result_digest": result_digest,
            "result_status": result_status,
            "operation_receipt": {
                "status": receipt_result.status,
                "digest": receipt_result.digest,
            },
            "results": results,
            "duration_ms": duration_ms,
        }
        return SlotSearchExchange(
            response=response,
            operation_receipt=operation_receipt,
        )
