"""Versioned HTTP contract around the retrieval pipeline."""

from __future__ import annotations

import json
import hashlib
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable
from uuid import uuid4

from .auth import ProjectionError, TokenProjection
from .jsonutil import canonical_json_bytes, loads_strict_json
from .manifest import IndexManifest
from .operation import (
    MAX_CORRELATION_CHARS as _MAX_CORRELATION_CHARS,
    MAX_QUERY_CHARS as _MAX_QUERY_CHARS,
    OperationError as ApiError,
    ReceiptWriter,
    SearchPipeline,
    map_results,
    pipeline_evidence as build_pipeline_evidence,
)

_MAX_REQUEST_BYTES = 64 * 1024


class SearchApplication:
    def __init__(
        self,
        *,
        pipeline: SearchPipeline,
        projection: TokenProjection,
        projection_loader: Callable[[], TokenProjection] | None = None,
        index_manifest: IndexManifest,
        pipeline_fingerprint: str,
        receipt_writer: ReceiptWriter,
        max_concurrent: int = 1,
    ):
        self.pipeline = pipeline
        self.projection = projection
        self._projection_loader = projection_loader
        self.index_manifest = index_manifest
        self.pipeline_fingerprint = pipeline_fingerprint
        self.receipts = receipt_writer
        self._search_slots = threading.BoundedSemaphore(max(1, max_concurrent))

    def ready(self) -> dict[str, Any]:
        try:
            projection = self._current_projection()
        except ProjectionError:
            return {
                "version": "1",
                "ready": False,
                "index_manifest": self.index_manifest.digest,
                "pipeline_fingerprint": self.pipeline_fingerprint,
                "projection_status": "unavailable",
                "corpus_count": len(self.index_manifest.rooms),
            }
        stale = projection.is_stale()
        return {
            "version": "1",
            "ready": not stale,
            "index_manifest": self.index_manifest.digest,
            "pipeline_fingerprint": self.pipeline_fingerprint,
            "projection_status": "stale" if stale else "current",
            "projection_digest": projection.projection_digest,
            "projection_expires_at": projection.expires_at.isoformat().replace(
                "+00:00", "Z"
            ),
            "corpus_count": len(self.index_manifest.rooms),
        }

    def search(self, token: str, body: Any) -> dict[str, Any]:
        started = time.monotonic()
        request_id = str(uuid4())
        try:
            projection = self._current_projection()
        except ProjectionError as exc:
            raise ApiError(
                503,
                "not_ready",
                "authorization projection is unavailable",
                retryable=True,
            ) from exc
        grant = projection.authorize(token)
        if grant is None:
            raise ApiError(
                401, "missing_or_invalid_token", "missing or invalid bearer token"
            )
        if projection.is_stale():
            raise ApiError(409, "stale_projection", "slot projection has expired")
        if not isinstance(body, dict):
            raise ApiError(400, "invalid_request", "request body must be an object")
        raw_request_id = body.get("request_id")
        if isinstance(raw_request_id, str) and 0 < len(raw_request_id) <= 128:
            request_id = raw_request_id
        raw_operation_id = body.get("operation_id")
        if raw_operation_id is None:
            operation_id = request_id
            operation_id_source = "request_id_default"
        elif (
            isinstance(raw_operation_id, str)
            and 0 < len(raw_operation_id) <= _MAX_CORRELATION_CHARS
        ):
            operation_id = raw_operation_id
            operation_id_source = "client"
        else:
            raise ApiError(
                400, "invalid_request", "operation_id must contain 1-128 characters"
            )
        raw_run_id = body.get("run_id")
        if raw_run_id is None:
            run_id = None
        elif (
            isinstance(raw_run_id, str)
            and 0 < len(raw_run_id) <= _MAX_CORRELATION_CHARS
        ):
            run_id = raw_run_id
        else:
            raise ApiError(
                400, "invalid_request", "run_id must contain 1-128 characters"
            )
        attempt = body.get("attempt", 1)
        if (
            isinstance(attempt, bool)
            or not isinstance(attempt, int)
            or not 1 <= attempt <= 16
        ):
            raise ApiError(
                400, "invalid_request", "attempt must be an integer from 1 to 16"
            )
        raw_query = body.get("query")
        query = raw_query.strip() if isinstance(raw_query, str) else ""
        if not query or len(query) > _MAX_QUERY_CHARS:
            raise ApiError(
                400, "invalid_request", "query must contain 1-4000 characters"
            )
        max_results = body.get("max_results", 5)
        if (
            isinstance(max_results, bool)
            or not isinstance(max_results, int)
            or not 1 <= max_results <= 10
        ):
            raise ApiError(
                400, "invalid_request", "max_results must be an integer from 1 to 10"
            )
        corpus = body.get("corpus")
        if corpus is not None and (
            not isinstance(corpus, str) or corpus not in grant.corpora
        ):
            raise ApiError(
                403,
                "forbidden_corpus",
                "requested corpus is outside the slot projection",
            )
        rooms = [corpus] if corpus else sorted(grant.corpora)
        unknown = set(rooms) - set(self.index_manifest.rooms)
        if unknown:
            raise ApiError(
                409,
                "stale_projection",
                "slot projection references an unavailable corpus",
            )
        if not self._search_slots.acquire(blocking=False):
            raise ApiError(429, "overloaded", "search service is busy", retryable=True)

        execution_status = "completed"
        result_status = "zero_hits"
        result_count = 0
        result_digest: str | None = None
        results: list[dict[str, Any]] = []
        pipeline_evidence: dict[str, Any] = {"status": "unavailable"}
        failure: ApiError | None = None
        try:
            raw = self.pipeline.search(query, rooms, max_results)
            results = map_results(raw.get("hits"), max_results, set(rooms))
            result_count = len(results)
            result_status = "hits" if results else "zero_hits"
            result_digest = (
                "sha256:" + hashlib.sha256(canonical_json_bytes(results)).hexdigest()
            )
            pipeline_evidence = build_pipeline_evidence(raw, result_count, len(rooms))
        except ApiError as exc:
            execution_status = "failed"
            result_status = "error"
            failure = exc
        except Exception:
            execution_status = "failed"
            result_status = "error"
            failure = ApiError(
                503, "not_ready", "search execution failed", retryable=True
            )
        finally:
            self._search_slots.release()
        duration_ms = round((time.monotonic() - started) * 1_000)
        receipt_result = self.receipts.write(
            {
                "schema_version": "kwrag-search-operation-receipt-v1",
                "recorded_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "operation_id": operation_id,
                "operation_id_source": operation_id_source,
                "request_id": request_id,
                "run_id": run_id,
                "attempt": attempt,
                "instance_id": grant.instance_id,
                "slot_id": grant.slot_id,
                "corpora": rooms,
                "query_chars": len(query),
                "requested_max_results": max_results,
                "index_manifest": self.index_manifest.digest,
                "pipeline_fingerprint": self.pipeline_fingerprint,
                "projection_digest": projection.projection_digest,
                "execution_status": execution_status,
                "result_status": result_status,
                "duration_ms": duration_ms,
                "result_count": result_count,
                "result_digest": result_digest,
                "pipeline_evidence": pipeline_evidence,
                "provider_billing": {
                    "status": "not_applicable",
                    "amount": None,
                    "currency": None,
                    "reason": "local_pipeline_has_no_external_provider_billing_receipt",
                },
                "full_economic_cost": {
                    "status": "unavailable",
                    "amount": None,
                    "currency": None,
                    "reason": "hardware_energy_depreciation_and_operator_cost_not_measured",
                },
                "error_code": failure.code if failure is not None else None,
            }
        )
        if failure is not None:
            raise failure
        return {
            "version": "1",
            "request_id": request_id,
            "operation_id": operation_id,
            "run_id": run_id,
            "attempt": attempt,
            "index_manifest": self.index_manifest.digest,
            "pipeline_fingerprint": self.pipeline_fingerprint,
            "result_digest": result_digest,
            "result_status": result_status,
            "operation_receipt": {
                "status": receipt_result.status,
                "digest": receipt_result.digest,
            },
            "results": results,
            "duration_ms": duration_ms,
        }

    def _current_projection(self) -> TokenProjection:
        if self._projection_loader is None:
            return self.projection
        return self._projection_loader()



def make_handler(application: SearchApplication):
    class Handler(BaseHTTPRequestHandler):
        app = application

        def log_message(self, *_args):
            return

        def _send(self, status: int, payload: dict[str, Any]) -> None:
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:
            if self.path == "/healthz":
                self._send(200, {"version": "1", "ok": True})
                return
            if self.path == "/readyz":
                ready = self.app.ready()
                self._send(200 if ready["ready"] else 503, ready)
                return
            self._send(404, {"version": "1", "error": {"code": "not_found"}})

        def do_POST(self) -> None:
            if self.path != "/v1/search":
                self._send(404, {"version": "1", "error": {"code": "not_found"}})
                return
            request_id = str(uuid4())
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > _MAX_REQUEST_BYTES:
                    raise ApiError(400, "invalid_request", "invalid request body size")
                body = loads_strict_json(self.rfile.read(length).decode("utf-8"))
                if isinstance(body, dict):
                    supplied_request_id = body.get("request_id")
                    if (
                        isinstance(supplied_request_id, str)
                        and 0 < len(supplied_request_id) <= 128
                    ):
                        request_id = supplied_request_id
                    else:
                        body["request_id"] = request_id
                authorization = self.headers.get("Authorization", "")
                token = (
                    authorization[7:].strip()
                    if authorization.lower().startswith("bearer ")
                    else ""
                )
                self._send(200, self.app.search(token, body))
            except ApiError as exc:
                self._send(
                    exc.status,
                    {
                        "version": "1",
                        "request_id": request_id,
                        "error": {
                            "code": exc.code,
                            "message": exc.message,
                            "retryable": exc.retryable,
                        },
                    },
                )
            except (UnicodeDecodeError, json.JSONDecodeError, ValueError):
                self._send(
                    400,
                    {
                        "version": "1",
                        "request_id": request_id,
                        "error": {
                            "code": "invalid_request",
                            "message": "request body is not valid JSON",
                            "retryable": False,
                        },
                    },
                )

    return Handler


def serve(application: SearchApplication, bind: str, port: int) -> None:
    ThreadingHTTPServer((bind, port), make_handler(application)).serve_forever()
