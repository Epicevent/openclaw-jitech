"""Pinned production model residency and unmistakable test-only adapters."""

from __future__ import annotations

import hashlib
import math
import threading
import stat
import time
from pathlib import Path
from typing import Callable, Mapping, Protocol, Sequence

from .jsonutil import loads_strict_json
from .shared_gpu_contract import (
    KURE_DIMENSION,
    KURE_MODEL,
    KURE_REVISION,
    MODEL_MAX_TOKENS,
    RERANK_MODEL,
    RERANK_REVISION,
    SharedGpuContractError,
    validate_scores,
    validate_vectors,
)


Cancelled = Callable[[], bool]


class SharedGpuBackend(Protocol):
    production: bool
    embedding_model: str
    embedding_revision: str
    embedding_dimension: int
    rerank_model: str
    rerank_revision: str

    def warm(self) -> None: ...

    def embed(
        self,
        texts: Sequence[str],
        *,
        corpus: bool,
        cancelled: Cancelled,
        deadline_unix_ms: int,
    ) -> list[list[float]]: ...

    def rerank(
        self,
        query: str,
        passages: Sequence[str],
        *,
        cancelled: Cancelled,
        deadline_unix_ms: int,
    ) -> list[float]: ...


def _checkpoint(cancelled: Cancelled, deadline_unix_ms: int) -> None:
    if cancelled():
        raise SharedGpuContractError("cancelled", retryable=False)
    if int(time.time() * 1_000) >= deadline_unix_ms:
        raise SharedGpuContractError("deadline_exceeded", retryable=True)


class NonProductionDeterministicBackend:
    """Content-free deterministic adapter; never production-ready or CUDA."""

    production = False
    embedding_model = "NONPRODUCTION/deterministic-fake-embedder"
    embedding_revision = "NONPRODUCTION"
    rerank_model = "NONPRODUCTION/deterministic-fake-reranker"
    rerank_revision = "NONPRODUCTION"

    def __init__(self, dimension: int = 8, *, delay_seconds: float = 0.0):
        if not 1 <= dimension <= 256:
            raise ValueError("fake dimension must be between 1 and 256")
        self.embedding_dimension = dimension
        self.delay_seconds = max(0.0, float(delay_seconds))
        self.warm_count = 0
        self.calls = 0

    def warm(self) -> None:
        self.warm_count += 1

    def _wait(self, cancelled: Cancelled, deadline_unix_ms: int) -> None:
        remaining = self.delay_seconds
        while remaining > 0:
            _checkpoint(cancelled, deadline_unix_ms)
            interval = min(0.01, remaining)
            time.sleep(interval)
            remaining -= interval

    def _vector(self, text: str) -> list[float]:
        values: list[float] = []
        counter = 0
        while len(values) < self.embedding_dimension:
            block = hashlib.sha256(
                text.encode("utf-8") + counter.to_bytes(4, "big")
            ).digest()
            values.extend((byte - 127.5) / 127.5 for byte in block)
            counter += 1
        values = values[: self.embedding_dimension]
        norm = math.sqrt(sum(value * value for value in values)) or 1.0
        return [value / norm for value in values]

    def embed(
        self,
        texts: Sequence[str],
        *,
        corpus: bool,
        cancelled: Cancelled,
        deadline_unix_ms: int,
    ) -> list[list[float]]:
        del corpus
        self.calls += 1
        self._wait(cancelled, deadline_unix_ms)
        _checkpoint(cancelled, deadline_unix_ms)
        return [self._vector(text) for text in texts]

    def rerank(
        self,
        query: str,
        passages: Sequence[str],
        *,
        cancelled: Cancelled,
        deadline_unix_ms: int,
    ) -> list[float]:
        self.calls += 1
        self._wait(cancelled, deadline_unix_ms)
        _checkpoint(cancelled, deadline_unix_ms)
        query_terms = set(query.casefold().split())
        return [
            float(len(query_terms.intersection(passage.casefold().split())))
            + int.from_bytes(hashlib.sha256(passage.encode("utf-8")).digest()[:2], "big")
            / 65535_000.0
            for passage in passages
        ]


class PinnedKureBgeBackend:
    """One-process CUDA residency for the two exact, offline model snapshots."""

    production = True
    embedding_model = KURE_MODEL
    embedding_revision = KURE_REVISION
    embedding_dimension = KURE_DIMENSION
    rerank_model = RERANK_MODEL
    rerank_revision = RERANK_REVISION

    def __init__(
        self,
        model_cache_root: Path,
        *,
        device: str = "cuda",
        dtype: str = "float32",
        embedding_batch_size: int = 32,
        rerank_batch_size: int = 16,
    ):
        if device != "cuda":
            raise SharedGpuContractError("production_device_must_be_cuda")
        if dtype not in {"float32", "float16", "bfloat16"}:
            raise SharedGpuContractError("production_dtype_invalid")
        if not 1 <= embedding_batch_size <= 64 or not 1 <= rerank_batch_size <= 32:
            raise SharedGpuContractError("production_batch_size_invalid")
        root = Path(model_cache_root)
        if not root.is_absolute() or root.is_symlink() or not root.is_dir():
            raise SharedGpuContractError("model_cache_root_invalid")
        self.model_cache_root = root.resolve(strict=True)
        if self.model_cache_root != root.absolute():
            raise SharedGpuContractError("model_cache_root_invalid")
        self.device = device
        self.dtype = dtype
        self.embedding_batch_size = embedding_batch_size
        self.rerank_batch_size = rerank_batch_size
        self._embedder = None
        self._reranker = None
        self._load_lock = threading.Lock()

    def _snapshot_file(self, snapshot: Path, relative: str) -> Path:
        candidate = snapshot / relative
        try:
            repository_root = snapshot.parents[1].resolve(strict=True)
            resolved = candidate.resolve(strict=True)
            resolved.relative_to(repository_root)
            metadata = resolved.stat()
        except (OSError, ValueError) as exc:
            raise SharedGpuContractError("pinned_model_snapshot_incomplete") from exc
        if not stat.S_ISREG(metadata.st_mode) or metadata.st_size < 1:
            raise SharedGpuContractError("pinned_model_snapshot_incomplete")
        return resolved

    def _snapshot(self, model: str, revision: str) -> Path:
        revisions = {KURE_MODEL: KURE_REVISION, RERANK_MODEL: RERANK_REVISION}
        if revisions.get(model) != revision:
            raise SharedGpuContractError("pinned_model_identity_invalid")
        owner, name = model.split("/", 1)
        path = (
            self.model_cache_root
            / f"models--{owner}--{name}"
            / "snapshots"
            / revision
        )
        try:
            resolved_snapshot = path.resolve(strict=True)
        except OSError as exc:
            raise SharedGpuContractError("pinned_model_snapshot_unavailable") from exc
        if (
            path.is_symlink()
            or not path.is_dir()
            or path.name != revision
            or resolved_snapshot != path.absolute()
        ):
            raise SharedGpuContractError("pinned_model_snapshot_unavailable")
        required = ["config.json", "model.safetensors", "tokenizer.json"]
        if model == KURE_MODEL:
            required.append("modules.json")
        files = {name: self._snapshot_file(path, name) for name in required}
        config_path = files["config.json"]
        before = config_path.stat()
        if before.st_size > 2 * 1024 * 1024:
            raise SharedGpuContractError("pinned_model_config_invalid")
        try:
            payload = config_path.read_bytes()
            after = config_path.stat()
            config = loads_strict_json(payload.decode("utf-8"))
        except (OSError, UnicodeDecodeError, ValueError) as exc:
            raise SharedGpuContractError("pinned_model_config_invalid") from exc
        if (
            before.st_dev,
            before.st_ino,
            before.st_size,
            before.st_mtime_ns,
        ) != (
            after.st_dev,
            after.st_ino,
            after.st_size,
            after.st_mtime_ns,
        ):
            raise SharedGpuContractError("pinned_model_config_changed")
        architecture = (
            "XLMRobertaModel"
            if model == KURE_MODEL
            else "XLMRobertaForSequenceClassification"
        )
        if (
            not isinstance(config, Mapping)
            or config.get("architectures") != [architecture]
            or config.get("model_type") != "xlm-roberta"
            or config.get("hidden_size") != KURE_DIMENSION
            or not isinstance(config.get("max_position_embeddings"), int)
            or config["max_position_embeddings"] < MODEL_MAX_TOKENS
        ):
            raise SharedGpuContractError("pinned_model_config_invalid")
        return path

    def _torch_dtype(self):
        try:
            import torch
        except ImportError as exc:
            raise SharedGpuContractError("production_dependencies_unavailable") from exc
        if not torch.cuda.is_available():
            raise SharedGpuContractError("cuda_unavailable")
        return {
            "float32": torch.float32,
            "float16": torch.float16,
            "bfloat16": torch.bfloat16,
        }[self.dtype]

    def _load(self) -> None:
        if self._embedder is not None and self._reranker is not None:
            return
        with self._load_lock:
            if self._embedder is not None and self._reranker is not None:
                return
            try:
                from sentence_transformers import CrossEncoder, SentenceTransformer
            except ImportError as exc:
                raise SharedGpuContractError("production_dependencies_unavailable") from exc
            dtype = self._torch_dtype()
            embedding_path = self._snapshot(KURE_MODEL, KURE_REVISION)
            rerank_path = self._snapshot(RERANK_MODEL, RERANK_REVISION)
            embedder = SentenceTransformer(
                str(embedding_path),
                device=self.device,
                local_files_only=True,
                model_kwargs={"torch_dtype": dtype},
            )
            if embedder.get_sentence_embedding_dimension() != KURE_DIMENSION:
                raise SharedGpuContractError("embedding_dimension_mismatch")
            embedder.max_seq_length = MODEL_MAX_TOKENS
            reranker = CrossEncoder(
                str(rerank_path),
                device=self.device,
                local_files_only=True,
                max_length=MODEL_MAX_TOKENS,
                model_kwargs={"torch_dtype": dtype},
            )
            self._embedder = embedder
            self._reranker = reranker

    def warm(self) -> None:
        self._load()
        deadline = int(time.time() * 1_000) + 60_000
        self.embed(
            ["KWRAG readiness"],
            corpus=False,
            cancelled=lambda: False,
            deadline_unix_ms=deadline,
        )
        self.rerank(
            "KWRAG readiness",
            ["KWRAG readiness"],
            cancelled=lambda: False,
            deadline_unix_ms=deadline,
        )

    def embed(
        self,
        texts: Sequence[str],
        *,
        corpus: bool,
        cancelled: Cancelled,
        deadline_unix_ms: int,
    ) -> list[list[float]]:
        del corpus
        self._load()
        _checkpoint(cancelled, deadline_unix_ms)
        assert self._embedder is not None
        raw = self._embedder.encode(
            list(texts),
            normalize_embeddings=True,
            batch_size=self.embedding_batch_size,
            show_progress_bar=False,
            convert_to_numpy=True,
        )
        _checkpoint(cancelled, deadline_unix_ms)
        vectors = validate_vectors(raw.tolist(), expected_count=len(texts))
        if any(len(vector) != KURE_DIMENSION for vector in vectors):
            raise SharedGpuContractError("embedding_dimension_mismatch")
        return vectors

    def rerank(
        self,
        query: str,
        passages: Sequence[str],
        *,
        cancelled: Cancelled,
        deadline_unix_ms: int,
    ) -> list[float]:
        self._load()
        _checkpoint(cancelled, deadline_unix_ms)
        assert self._reranker is not None
        raw = self._reranker.predict(
            [(query, passage) for passage in passages],
            batch_size=self.rerank_batch_size,
            show_progress_bar=False,
        )
        _checkpoint(cancelled, deadline_unix_ms)
        values = raw.tolist() if hasattr(raw, "tolist") else list(raw)
        return validate_scores(values, expected_count=len(passages))
