"""Exact PC-side publication adapter for P6 immutable index releases.

This module reuses the authoritative kw_corpus Synology transport. It exposes
no server-side NAS writer and deliberately never calls transport delete or
rename methods. The index manifest is the commit marker and is uploaded last.
"""

from __future__ import annotations

import argparse
import hashlib
import os
import re
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Mapping, Protocol

from .index_release import (
    IndexReleaseError,
    PUBLISH_FILES,
    SLOT_SPECS,
    _stable_file,
    _strict_object,
    _validate_remote_package,
    _write_canonical,
)
from .jsonutil import canonical_json_bytes, is_sha256
from .manifest import ManifestError, load_and_verify_manifest


_RELEASE_NAME = re.compile(r"^sha256-[0-9a-f]{64}$")
_TOP_FIELDS = frozenset(
    {
        "schema_version",
        "status",
        "slot",
        "publisher",
        "source_package",
        "release",
        "upload",
        "postcheck",
        "failure_state",
    }
)


class IndexPublisherError(ValueError):
    """A publication precondition failed closed."""


class PublishTransport(Protocol):
    def put_file_atomic(self, local_path: Path, remote_path: str) -> None: ...

    def read_bytes(self, remote_path: str) -> bytes: ...

    def list_dir(
        self,
        remote_dir: str,
        *,
        limit: int = 1000,
        offset: int = 0,
    ) -> list[dict]: ...

    def close(self) -> None: ...


def _digest_bytes(payload: bytes) -> str:
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _exact_mapping(
    value: object,
    fields: set[str] | frozenset[str],
    code: str,
) -> Mapping[str, Any]:
    if not isinstance(value, Mapping) or set(value) != set(fields):
        raise IndexPublisherError(code)
    return value


def _safe_relative(value: object, code: str) -> PurePosixPath:
    if not isinstance(value, str) or not value:
        raise IndexPublisherError(code)
    relative = PurePosixPath(value)
    if (
        relative.is_absolute()
        or relative.as_posix() != value
        or "\\" in value
        or ":" in value
        or any(part in {"", ".", ".."} for part in relative.parts)
    ):
        raise IndexPublisherError(code)
    return relative


def load_publication_plan(path: Path) -> tuple[dict[str, Any], str]:
    payload, digest, _identity = _stable_file(
        Path(path),
        maximum=1024 * 1024,
    )
    value = _strict_object(payload, code="publication_plan_invalid")
    _exact_mapping(value, _TOP_FIELDS, "publication_plan_fields_invalid")
    if (
        value.get("schema_version")
        != "kwrag-pc-dsm-index-publication-plan-v1"
        or value.get("status")
        != "READY_FOR_EXACT_PC_CREDENTIAL_ACTION_NOT_EXECUTED"
    ):
        raise IndexPublisherError("publication_plan_state_invalid")
    slot = value.get("slot")
    if slot not in SLOT_SPECS:
        raise IndexPublisherError("publication_plan_slot_invalid")

    publisher = _exact_mapping(
        value.get("publisher"),
        {
            "owner",
            "os_principal",
            "credential",
            "credential_material_present",
            "required_remote_root",
            "required_grant",
        },
        "publication_plan_publisher_invalid",
    )
    if (
        publisher.get("owner") != "kw_corpus kw publish nas"
        or publisher.get("credential_material_present") is not False
        or publisher.get("required_remote_root") != "/kakao-work"
    ):
        raise IndexPublisherError("publication_plan_publisher_invalid")

    source = _exact_mapping(
        value.get("source_package"),
        {"remote_package", "membership_sha256", "database_sha256"},
        "publication_plan_source_invalid",
    )
    remote_package = source.get("remote_package")
    if not isinstance(remote_package, str):
        raise IndexPublisherError("publication_plan_source_invalid")
    package_name = PurePosixPath(remote_package).name
    _validate_remote_package(remote_package, package_name)
    if not all(
        is_sha256(source.get(field))
        for field in ("membership_sha256", "database_sha256")
    ):
        raise IndexPublisherError("publication_plan_source_invalid")

    release = _exact_mapping(
        value.get("release"),
        {
            "release_id",
            "release_relative",
            "remote_release",
            "host_slot_visible_release",
            "container_slot_visible_release",
            "slot_view_root",
        },
        "publication_plan_release_invalid",
    )
    release_id = release.get("release_id")
    if not isinstance(release_id, str) or not _RELEASE_NAME.fullmatch(release_id):
        raise IndexPublisherError("publication_plan_release_invalid")
    expected_relative = f"releases/{slot}/{release_id}"
    if _safe_relative(
        release.get("release_relative"),
        "publication_plan_release_invalid",
    ).as_posix() != expected_relative:
        raise IndexPublisherError("publication_plan_release_invalid")
    expected_remote = f"{remote_package}/kwrag/releases/{release_id}"
    if release.get("remote_release") != expected_remote:
        raise IndexPublisherError("publication_plan_release_invalid")
    spec = SLOT_SPECS[str(slot)]
    if (
        release.get("host_slot_visible_release")
        != f"{spec.host_package_mount}/kwrag/releases/{release_id}"
        or release.get("container_slot_visible_release")
        != f"{spec.container_package_mount}/kwrag/releases/{release_id}"
        or release.get("slot_view_root") != spec.slot_view_root
    ):
        raise IndexPublisherError("publication_plan_slot_paths_invalid")

    upload = _exact_mapping(
        value.get("upload"),
        {
            "files",
            "manifest_last",
            "overwrite_existing_mismatch",
            "unknown_remote_entry",
            "cross_slot_reuse",
            "delete_or_rename",
        },
        "publication_plan_upload_invalid",
    )
    if (
        upload.get("manifest_last") is not True
        or upload.get("overwrite_existing_mismatch") is not False
        or upload.get("unknown_remote_entry") != "fail_closed"
        or upload.get("cross_slot_reuse") is not False
        or upload.get("delete_or_rename") is not False
    ):
        raise IndexPublisherError("publication_plan_upload_invalid")
    files = upload.get("files")
    if not isinstance(files, list) or len(files) != len(PUBLISH_FILES):
        raise IndexPublisherError("publication_plan_files_invalid")
    for order, (expected_name, raw) in enumerate(
        zip(PUBLISH_FILES, files, strict=True),
        1,
    ):
        item = _exact_mapping(
            raw,
            {"relative", "sha256", "bytes", "order"},
            "publication_plan_files_invalid",
        )
        if (
            item.get("relative") != expected_name
            or item.get("order") != order
            or not is_sha256(item.get("sha256"))
            or isinstance(item.get("bytes"), bool)
            or not isinstance(item.get("bytes"), int)
            or item.get("bytes") < 1
        ):
            raise IndexPublisherError("publication_plan_files_invalid")

    postcheck = _exact_mapping(
        value.get("postcheck"),
        {
            "read_back_every_file_sha256",
            "manifest_digest",
            "server_service_identity_observation_required_after_publication",
            "raw_content_in_receipt",
        },
        "publication_plan_postcheck_invalid",
    )
    if (
        postcheck.get("read_back_every_file_sha256") is not True
        or postcheck.get("server_service_identity_observation_required_after_publication")
        is not True
        or postcheck.get("raw_content_in_receipt") is not False
        or postcheck.get("manifest_digest") != files[-1]["sha256"]
    ):
        raise IndexPublisherError("publication_plan_postcheck_invalid")
    return value, digest


def _build_root(path: Path) -> Path:
    supplied = Path(path)
    try:
        metadata = supplied.lstat()
        resolved = supplied.resolve(strict=True)
    except OSError as exc:
        raise IndexPublisherError("build_root_unavailable") from exc
    if supplied.is_symlink() or not supplied.is_dir() or metadata.st_nlink < 1:
        raise IndexPublisherError("build_root_invalid")
    return resolved


def _local_release(
    build_root: Path,
    plan: Mapping[str, Any],
) -> tuple[Path, list[dict[str, Any]]]:
    root = _build_root(build_root)
    relative = _safe_relative(
        plan["release"]["release_relative"],
        "publication_plan_release_invalid",
    )
    release = root.joinpath(*relative.parts)
    try:
        metadata = release.lstat()
        resolved = release.resolve(strict=True)
        resolved.relative_to(root)
    except (OSError, ValueError) as exc:
        raise IndexPublisherError("local_release_unavailable") from exc
    if release.is_symlink() or not release.is_dir() or metadata.st_nlink < 1:
        raise IndexPublisherError("local_release_invalid")
    expected = list(plan["upload"]["files"])
    actual_names = {child.name for child in release.iterdir()}
    if actual_names != set(PUBLISH_FILES):
        raise IndexPublisherError("local_release_file_set_invalid")
    for item in expected:
        path = release / item["relative"]
        payload, digest, _identity = _stable_file(
            path,
            maximum=512 * 1024 * 1024,
        )
        if digest != item["sha256"] or len(payload) != item["bytes"]:
            raise IndexPublisherError("local_release_digest_mismatch")
    try:
        loaded = load_and_verify_manifest(
            release / "index-manifest.json",
            release,
        )
    except ManifestError as exc:
        raise IndexPublisherError("local_manifest_verification_failed") from exc
    if (
        loaded.digest != expected[-1]["sha256"]
        or loaded.release_id != plan["release"]["release_id"]
    ):
        raise IndexPublisherError("local_manifest_identity_invalid")
    return release, expected


def preflight_publication(
    *,
    build_root: Path,
    plan_path: Path,
    expected_plan_digest: str,
) -> tuple[dict[str, Any], str, Path, list[dict[str, Any]]]:
    if not is_sha256(expected_plan_digest):
        raise IndexPublisherError("expected_plan_digest_invalid")
    plan, plan_digest = load_publication_plan(plan_path)
    if plan_digest != expected_plan_digest:
        raise IndexPublisherError("publication_plan_digest_mismatch")
    release, files = _local_release(build_root, plan)
    return plan, plan_digest, release, files


def _entries(
    transport: PublishTransport,
    remote_dir: str,
) -> dict[str, bool]:
    try:
        raw_entries = transport.list_dir(remote_dir, limit=1000, offset=0)
    except Exception as exc:
        raise IndexPublisherError("remote_directory_observation_failed") from exc
    if not isinstance(raw_entries, list) or len(raw_entries) > 1000:
        raise IndexPublisherError("remote_directory_observation_invalid")
    output: dict[str, bool] = {}
    for raw in raw_entries:
        if not isinstance(raw, Mapping):
            raise IndexPublisherError("remote_directory_observation_invalid")
        name = raw.get("name")
        is_directory = raw.get("isdir")
        if (
            not isinstance(name, str)
            or not name
            or "/" in name
            or "\\" in name
            or name in {".", ".."}
            or name in output
            or not isinstance(is_directory, bool)
        ):
            raise IndexPublisherError("remote_directory_observation_invalid")
        output[name] = is_directory
    return output


def _release_remote_state(
    transport: PublishTransport,
    *,
    remote_package: str,
    release_id: str,
) -> tuple[bool, dict[str, bool]]:
    package_entries = _entries(transport, remote_package)
    if "kwrag" not in package_entries:
        return False, {}
    if package_entries["kwrag"] is not True:
        raise IndexPublisherError("remote_kwrag_namespace_conflict")
    kwrag = f"{remote_package}/kwrag"
    kwrag_entries = _entries(transport, kwrag)
    if "releases" not in kwrag_entries:
        return False, {}
    if kwrag_entries["releases"] is not True:
        raise IndexPublisherError("remote_releases_namespace_conflict")
    releases = f"{kwrag}/releases"
    release_entries = _entries(transport, releases)
    if release_id not in release_entries:
        return False, {}
    if release_entries[release_id] is not True:
        raise IndexPublisherError("remote_release_namespace_conflict")
    exact = _entries(transport, f"{releases}/{release_id}")
    unknown = set(exact) - set(PUBLISH_FILES)
    if unknown or any(exact[name] for name in exact):
        raise IndexPublisherError("remote_release_file_set_invalid")
    return True, exact


def _read_remote_digest(
    transport: PublishTransport,
    remote_path: str,
) -> str:
    try:
        payload = transport.read_bytes(remote_path)
    except Exception as exc:
        raise IndexPublisherError("remote_file_read_failed") from exc
    if not isinstance(payload, bytes):
        raise IndexPublisherError("remote_file_read_invalid")
    return _digest_bytes(payload)


def publish_release(
    *,
    transport: PublishTransport,
    build_root: Path,
    plan_path: Path,
    expected_plan_digest: str,
    receipt_path: Path | None = None,
) -> dict[str, Any]:
    """Publish one exact plan and return a content-free event receipt."""

    plan, plan_digest, release, files = preflight_publication(
        build_root=build_root,
        plan_path=plan_path,
        expected_plan_digest=expected_plan_digest,
    )
    remote_package = str(plan["source_package"]["remote_package"])
    release_id = str(plan["release"]["release_id"])
    remote_release = str(plan["release"]["remote_release"])
    exists, remote_entries = _release_remote_state(
        transport,
        remote_package=remote_package,
        release_id=release_id,
    )
    if "index-manifest.json" in remote_entries and set(remote_entries) != set(
        PUBLISH_FILES
    ):
        raise IndexPublisherError("remote_committed_release_incomplete")

    dispositions: list[dict[str, str]] = []
    for item in files:
        name = str(item["relative"])
        remote_path = f"{remote_release}/{name}"
        current_exists = name in remote_entries
        if current_exists:
            if _read_remote_digest(transport, remote_path) != item["sha256"]:
                raise IndexPublisherError("remote_immutable_file_mismatch")
            dispositions.append({"relative": name, "disposition": "reused"})
            continue
        # Manifest is the commit marker and the plan order places it last.
        if name == "index-manifest.json":
            if {entry["relative"] for entry in files[:-1]} - set(remote_entries):
                raise IndexPublisherError("remote_data_files_not_committed")
        try:
            transport.put_file_atomic(release / name, remote_path)
        except Exception as exc:
            raise IndexPublisherError("remote_upload_failed") from exc
        if _read_remote_digest(transport, remote_path) != item["sha256"]:
            raise IndexPublisherError("remote_upload_readback_mismatch")
        remote_entries[name] = False
        dispositions.append({"relative": name, "disposition": "uploaded"})

    final_exists, final_entries = _release_remote_state(
        transport,
        remote_package=remote_package,
        release_id=release_id,
    )
    if not final_exists or set(final_entries) != set(PUBLISH_FILES):
        raise IndexPublisherError("remote_release_postcheck_failed")
    for item in files:
        if (
            _read_remote_digest(
                transport,
                f"{remote_release}/{item['relative']}",
            )
            != item["sha256"]
        ):
            raise IndexPublisherError("remote_release_postcheck_failed")

    receipt = {
        "schema_version": "kwrag-index-publication-receipt-v1",
        "event_id": str(uuid.uuid4()),
        "occurred_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "SUCCEEDED",
        "effect": "created_or_verified_one_inactive_immutable_slot_release",
        "slot": plan["slot"],
        "plan_sha256": plan_digest,
        "release_id": release_id,
        "remote_release": remote_release,
        "files": [
            {
                "relative": item["relative"],
                "sha256": item["sha256"],
                "bytes": item["bytes"],
                "disposition": dispositions[index]["disposition"],
            }
            for index, item in enumerate(files)
        ],
        "manifest_last": True,
        "active_reference_changed": False,
        "runtime_changed": False,
        "rollback_required": False,
        "failure_state": plan["failure_state"],
        "next_observer": (
            "ji svcops typed service-identity read-only observation for the "
            "exact slot-visible release"
        ),
        "credential_material_in_receipt": False,
        "raw_content_in_receipt": False,
    }
    if receipt_path is not None:
        _write_canonical(Path(receipt_path), receipt)
    return receipt


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Publish one digest-pinned KWRAG release with the authoritative "
            "kw_corpus DSM transport."
        )
    )
    parser.add_argument("--build-root", type=Path, required=True)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--confirm-plan-sha256", required=True)
    parser.add_argument("--receipt", type=Path, required=True)
    return parser


def main() -> int:
    args = _parser().parse_args()
    try:
        # Complete all local checks before any credential is requested.
        preflight_publication(
            build_root=args.build_root,
            plan_path=args.plan,
            expected_plan_digest=args.confirm_plan_sha256,
        )
        from kw_corpus.nas.config import NasPublishConfig
        from kw_corpus.nas.transport import open_transport

        config = NasPublishConfig.from_env()
        if (
            not config.enabled
            or not config.uses_dsm
            or config.remote_root != "/kakao-work"
            or not config.verify_after_upload
            or not config.dsm_user
        ):
            raise IndexPublisherError("authoritative_publisher_config_invalid")
        transport = open_transport(config)
        try:
            receipt = publish_release(
                transport=transport,
                build_root=args.build_root,
                plan_path=args.plan,
                expected_plan_digest=args.confirm_plan_sha256,
                receipt_path=args.receipt,
            )
        finally:
            transport.close()
    except (IndexPublisherError, IndexReleaseError, OSError, ValueError):
        sys.stderr.buffer.write(
            canonical_json_bytes(
                {
                    "schema_version": "kwrag-index-publication-error-v1",
                    "code": "publication_failed_closed",
                }
            )
        )
        sys.stderr.buffer.flush()
        return 4
    sys.stdout.buffer.write(canonical_json_bytes(receipt))
    sys.stdout.buffer.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
