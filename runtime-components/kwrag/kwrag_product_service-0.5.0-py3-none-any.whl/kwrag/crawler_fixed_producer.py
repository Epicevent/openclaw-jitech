"""Fixed, caller-explicit producer over canonical crawler SQLite generations."""

from __future__ import annotations

import hashlib
import os
import sys
from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import Any, Mapping, Sequence

from .crawler_source import (
    CanonicalCrawlerSource,
    CrawlerFtsSearchPipeline,
    CrawlerSourceError,
)
from .fixed_producer import (
    MAX_BINDING_BYTES,
    MAX_CONSUMABLE_CHARACTERS,
    MAX_STDIN_BYTES,
    FixedProducerError,
    FixedProducerExecution,
    _absolute_posix,
    _exact_mapping,
    _integer,
    _read_stable_file,
    _sha256_bytes,
    load_fixed_producer_request,
    verify_fixed_producer_output,
)
from .jsonutil import canonical_json_bytes, loads_canonical_json_bytes
from .operation import OperationError, ReceiptWriter
from .slot_api import SlotSearchApplication
from .slot_consumer import SlotConsumptionError, verify_slot_search_exchange
from .slot_mount import SlotMountError


DEFAULT_BINDING_PATH = Path("/run/kwrag/fixed-producer-binding.json")
_BINDING_FIELDS = frozenset(
    {
        "schema_version",
        "enabled",
        "mount_root",
        "operation_receipt_path",
        "producer_receipt_path",
        "max_concurrent",
        "expected_uid",
        "expected_gid",
        "pipeline_fingerprint",
    }
)


CRAWLER_F_PIPELINE_FINGERPRINT = "sha256:" + hashlib.sha256(
    canonical_json_bytes(
        {
            "schema_version": "kwrag-crawler-direct-fts-pipeline-v1",
            "source": "canonical-crawler-messages.sqlite-generation",
            "preferred_table": "messages_fts_trigram",
            "compatibility_table": "messages_fts",
            "compatibility_tokenizer": "unicode61",
            "query": "literal",
            "fallback": None,
        }
    )
).hexdigest()


@dataclass(frozen=True)
class CrawlerFixedBinding:
    enabled: bool
    mount_root: Path
    operation_receipt_path: Path
    producer_receipt_path: Path
    max_concurrent: int
    expected_uid: int
    expected_gid: int
    digest: str


class _CrawlerScope:
    """Duck-typed slot scope whose manifest is the selected source generation."""

    def __init__(self, source: CanonicalCrawlerSource):
        self.source = source
        self.mount_root = source.mount_root
        self.readonly_required = True
        generation = source.generation
        self._generation_id = generation.generation_id
        self._manifest_digest = generation.manifest_digest
        self.manifest = SimpleNamespace(digest=generation.manifest_digest)
        self.available_rooms = generation.rooms

    def assert_current(self) -> None:
        self.source.refresh()
        generation = self.source.generation
        if (
            generation.generation_id != self._generation_id
            or generation.manifest_digest != self._manifest_digest
        ):
            raise SlotMountError("crawler generation changed during operation")

    def select_rooms(self, requested: Sequence[str] | None = None) -> list[str]:
        available = set(self.available_rooms)
        if requested is None:
            return sorted(available)
        if isinstance(requested, (str, bytes)) or not requested:
            raise SlotMountError("requested rooms are invalid")
        rooms = [str(room) for room in requested]
        if len(rooms) != len(set(rooms)) or set(rooms) - available:
            raise SlotMountError("requested room is outside source generation")
        return rooms


def load_crawler_fixed_binding(
    path: Path = DEFAULT_BINDING_PATH,
) -> CrawlerFixedBinding:
    payload = _read_stable_file(
        path,
        maximum=MAX_BINDING_BYTES,
        binding_trust=True,
    )
    try:
        raw = loads_canonical_json_bytes(payload)
    except (UnicodeDecodeError, ValueError) as exc:
        raise FixedProducerError("binding_not_canonical") from exc
    value = _exact_mapping(raw, _BINDING_FIELDS, "binding_fields_invalid")
    if value.get("schema_version") != "kwrag-crawler-fixed-producer-binding-v1":
        raise FixedProducerError("binding_schema_invalid")
    enabled = value.get("enabled")
    if not isinstance(enabled, bool):
        raise FixedProducerError("binding_enabled_invalid")
    if value.get("pipeline_fingerprint") != CRAWLER_F_PIPELINE_FINGERPRINT:
        raise FixedProducerError("binding_pipeline_identity_invalid")
    mount_root = _absolute_posix(value.get("mount_root"))
    operation_receipt_path = _absolute_posix(value.get("operation_receipt_path"))
    producer_receipt_path = _absolute_posix(value.get("producer_receipt_path"))
    if operation_receipt_path == producer_receipt_path:
        raise FixedProducerError("binding_receipt_paths_invalid")
    for receipt_path in (operation_receipt_path, producer_receipt_path):
        try:
            receipt_path.relative_to(mount_root)
        except ValueError:
            pass
        else:
            raise FixedProducerError("binding_receipt_inside_mount")
    expected_uid = _integer(value.get("expected_uid"), minimum=0, maximum=2**31 - 1)
    expected_gid = _integer(value.get("expected_gid"), minimum=0, maximum=2**31 - 1)
    if os.geteuid() != expected_uid or os.getegid() != expected_gid:
        raise FixedProducerError("binding_principal_mismatch")
    return CrawlerFixedBinding(
        enabled=enabled,
        mount_root=mount_root,
        operation_receipt_path=operation_receipt_path,
        producer_receipt_path=producer_receipt_path,
        max_concurrent=_integer(
            value.get("max_concurrent"), minimum=1, maximum=64
        ),
        expected_uid=expected_uid,
        expected_gid=expected_gid,
        digest=_sha256_bytes(payload),
    )


def execute_crawler_fixed_producer(
    request_payload: bytes,
    *,
    binding_path: Path = DEFAULT_BINDING_PATH,
) -> FixedProducerExecution:
    request = load_fixed_producer_request(request_payload)
    binding = load_crawler_fixed_binding(binding_path)
    if binding.enabled is not True:
        raise FixedProducerError("producer_disabled", exit_status=3)
    source = CanonicalCrawlerSource(binding.mount_root)
    try:
        scope = _CrawlerScope(source)
        pipeline = CrawlerFtsSearchPipeline(source)
        application = SlotSearchApplication(
            pipeline=pipeline,
            scope=scope,  # type: ignore[arg-type]
            pipeline_fingerprint=CRAWLER_F_PIPELINE_FINGERPRINT,
            receipt_writer=ReceiptWriter(binding.operation_receipt_path),
            max_concurrent=binding.max_concurrent,
        )
        exchange = application.search_exchange(request)
        generation = source.generation
        verified = verify_slot_search_exchange(
            request,
            exchange.response,
            exchange.operation_receipt,
            expected_index_manifest=generation.manifest_digest,
            expected_pipeline_fingerprint=CRAWLER_F_PIPELINE_FINGERPRINT,
            max_result_characters=MAX_CONSUMABLE_CHARACTERS,
        )
        source_exchange = {
            "schema_version": "kwrag-crawler-source-exchange-v1",
            "binding_digest": binding.digest,
            "generation_manifest_sha256": generation.manifest_digest,
            "membership_sha256": generation.membership_digest,
            "database_sha256": generation.database_digest,
            "profile_sha256": generation.profile_digest,
            "operation_receipt_digest": verified.operation_receipt_digest,
            "result_digest": verified.result_digest,
            "raw_content_present": False,
        }
        source_digest = _sha256_bytes(canonical_json_bytes(source_exchange))
        consumable = {
            "schema_version": "kwrag-fixed-consumable-v1",
            "request_id": verified.request_id,
            "operation_id": verified.operation_id,
            "run_id": verified.run_id,
            "attempt": verified.attempt,
            "index_manifest": verified.index_manifest,
            "pipeline_fingerprint": verified.pipeline_fingerprint,
            "result_status": verified.result_status,
            "results": verified.results(),
        }
        consumable_digest = _sha256_bytes(canonical_json_bytes(consumable))
        placeholder = {
            "schema_version": "kwrag-fixed-producer-output-v1",
            "consumable": consumable,
            "linkage": {
                "operation_receipt_digest": verified.operation_receipt_digest,
                "result_digest": verified.result_digest,
                "source_exchange_digest": source_digest,
                "producer_receipt_digest": "sha256:" + "0" * 64,
            },
        }
        output_characters = len(canonical_json_bytes(placeholder).decode("utf-8"))
        if output_characters > MAX_CONSUMABLE_CHARACTERS:
            raise FixedProducerError("payload_budget_exceeded")
        producer_receipt = {
            "schema_version": "kwrag-fixed-producer-receipt-v1",
            "status": "verified",
            "binding_digest": binding.digest,
            "index_manifest": verified.index_manifest,
            "pipeline_fingerprint": verified.pipeline_fingerprint,
            "operation_receipt_digest": verified.operation_receipt_digest,
            "result_digest": verified.result_digest,
            "source_exchange_digest": source_digest,
            "consumable_payload_digest": consumable_digest,
            "result_status": verified.result_status,
            "result_count": verified.result_count,
            "output_characters": output_characters,
        }
        receipt_result = ReceiptWriter(binding.producer_receipt_path).write(
            producer_receipt
        )
        if receipt_result.status != "written" or receipt_result.digest is None:
            raise FixedProducerError("producer_receipt_unavailable")
        output = dict(placeholder)
        output["linkage"] = dict(placeholder["linkage"])
        output["linkage"]["producer_receipt_digest"] = receipt_result.digest
        output_bytes = canonical_json_bytes(output)
        if len(output_bytes.decode("utf-8")) != output_characters:
            raise FixedProducerError("payload_budget_identity_changed")
        verify_fixed_producer_output(
            output_bytes,
            producer_receipt,
            request=request,
            expected_binding_digest=binding.digest,
        )
        return FixedProducerExecution(
            output_bytes=output_bytes,
            operation_receipt=exchange.operation_receipt,
            producer_receipt=producer_receipt,
            binding_digest=binding.digest,
        )
    finally:
        source.close()


def _read_stdin() -> bytes:
    payload = sys.stdin.buffer.read(MAX_STDIN_BYTES + 1)
    if len(payload) > MAX_STDIN_BYTES:
        raise FixedProducerError("request_size_invalid", exit_status=2)
    return payload


def _write_error(code: str) -> None:
    sys.stderr.buffer.write(
        canonical_json_bytes(
            {
                "schema_version": "kwrag-fixed-producer-error-v1",
                "code": code,
            }
        )
    )
    sys.stderr.buffer.flush()


def main() -> int:
    if len(sys.argv) != 1:
        _write_error("arbitrary_argv_forbidden")
        return 2
    try:
        execution = execute_crawler_fixed_producer(_read_stdin())
    except FixedProducerError as exc:
        _write_error(exc.code)
        return exc.exit_status
    except OperationError as exc:
        _write_error(exc.code)
        return 4
    except (CrawlerSourceError, SlotConsumptionError, SlotMountError):
        _write_error("verified_exchange_unavailable")
        return 4
    except (OSError, TypeError, ValueError):
        _write_error("producer_not_ready")
        return 4
    sys.stdout.buffer.write(execution.output_bytes)
    sys.stdout.buffer.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
